
# Programme d’anonymisation des flux fichiers 



- [Programme d’anonymisation des flux fichiers](#programme-d-anonymisation-des-flux-fichiers)
  * [1. Prérequis](#1-pr-requis)
  * [2 . Logique](#2--logique)
  * [3 . Structure du fichier de MASKING d'un flux CSV](#3--structure-du-fichier-de-masking-d-un-flux-csv)
  * [4 . Structure du fichier de MASKING d'un flux Plat à structure fix](#4--structure-du-fichier-de-masking-d-un-flux-plat---structure-fix)
  * [5 . Structure du fichier de Mapping](#5--structure-du-fichier-de-mapping)
  * [6 . Exécution](#6--ex-cution)



Ce script a pour but d’anonymiser des données sous formats fichier (csv/plat).

Langage de programmation : `python - version 3.6.8`

## 1. Prérequis

- Python : `version 3.6`
- Librairies :  Pandas 
- Répertoire  IN : le répertoire d'entrée contenant les fichiers **à anonymiser** 
- Répertoire OUT : le répertoire de sortie contenantles fichiers  **anonymisés**
- Fichier de masking : un csv contenant les colonnes à anonymiser + la fonction d'anonymisation à appliquer 
- Fichier de mapping : un csv contenant le format (csv/plat) et  préfix des nom des fichiers à anonymiser et leurs fichiers de masking 




## 2 . Logique 

1.	Lecture des paramètres à l'appel du programme

        - Répertoire IN contenant les flux en entrée
        - Fichiers de masking
        - Fichier de mapping
        - Niveau de trace : par défaut : ouvertures, créations et fermetures des fichiers
2.	Lecture du fichier de paramétrage externe déclarant les noms des attributs (champs) à masquer ainsi que leur typage. 

3.	Lecture de la première ligne du fichier CSV déclarant le nom de chaque attributs (champs) du fichier de données. 
4.	Pour chaque ligne de données :

- chaque attribut, selon son nom 
- Si l'attribut est référencé comme devant être masqué 
    - appel à une fonction de masquage spécifique au type de donnée définie dans le fichier de paramétrage
    - Si l'attribut n'est PAS référencé  appel à une fonction de recopie 
- Ecriture dans le fichier de sortie du résultat
- Selon le niveau de trace, écrire sur le canal de sortie l'information de trace.

Exception sur ouverture ou création de fichier : Message d'erreur dans la trace (si fichier trace en erreur sur 'stderr' obligatoirement)

Sur anomalie traitement (quelque soit) : Message d'erreur dans la trace indiquant le nom du fichier en question.

Si anomalie : Le programme se termine avec un returncode système de "-1".


## 3 . Structure du fichier de MASKING d'un flux CSV

:warning: Seules les champs/colonnes à traiter doivent être déclarés.
Les déclarations des champs à anonymiser sont faites dans un fichier csv.



- La colonne `COLUMN_NAME` correspond nom du champ/attribut du fichier de donnée à traiter (masquage ou autre fonction d'anonymisation)
- La colonne `MASKING` correspond au nom de la fonction de masquage à appliquer.
- La colonne `args` correspond au arguments de la fonction de masking.

**A noter** : Vous avez la possibilité de déclarer un champ/colonne d'une donnée "sensible" mais sans exigence d'anonymisation, vous définirez la fonction de MASKING = COPY 


**Exemple :**

|COLUMN_NAME        |MASKING            | MASK_VALUE|
|-------------------|-------------------|------|
|Prénom                   |agregation_1   |  valeur    |
|Nom                |agregation_N       |    2, *    |
|Date de naissance     |brouillage         |  720, +        |
|SIRN                  |COPY         |  -        |


- ***Exemple 1*** : `agregation_1` Remplace la valeur par une même et unique valeur
  
      Exemple : bpce => valeur
      



- ***Exemple 2***  : `agregation_N` prend en argument `2, *`   les 2 derniers caractères seront remplacés par * 
      
       Exemple BPCE => BP**

       
- ***Exemple 3*** : `brouillage` prend en argument `720, +`   => on ajoute 720 jours a une date donnée |

Si la fonction ne prends pas d'arguments (COPY par exemple), ajoutez `-` comme valeur de la colonne `args`

**Remarque** :
> Le fichier de config peut avoir d'autre colonnes supplémentaires , cela ne va pas impacter l'exécution de la moulinette.

les valeurs possibles pour la colonne `MASKING` :

- `agregation_N`
- `agregation_1`
- `TransformeSubt`
- `TransformeFill`
- `TransformeCrypt`
- `Suppression`
- `Brouillage`


## 4 . Structure du fichier de MASKING d'un flux Plat à structure fix

Le fichier de masking d'un fichier plat à structure fix contient une colonne de plus, c'est la colonne WIDTH, qui permet de definir la taille de chaque colonne.

:warning: TOUS les champs/colonnes à traiter doivent être déclarés, dans l'ordre d'apparition physique.

**Exemple :**


|COLUMN_NAME        |MASKING            | MASK_VALUE| WIDTH |
|-------------------|-------------------|------| ------|
|Prénom                   |agregation_1   |  valeur    |10 |
|Nom                |agregation_N       |    2, *    |10 |
|Date de naissance     |brouillage         |  720, +        | 15|
|SIRN                  |COPY         |  -        | 30|


## 5 . Structure du fichier de Mapping 
Ce fichier à pour objectif d'associer chaque fichier (plat ou csv) à son fichier de masking.

 - `Prefix` : le prefix (unique) d'un fichier
 - `Format`: csv/plat/zip/tar
 - `Mask` : chemain de fichier de masking
 - `Entete` : si le fichier ne contient pas d'entête, le scripte génère un entête en automatique pour identifier les noms des colonnes à anonymiser. l'entête sera enlevé des la fin de traitement 
 

**Exemple :**

|prefix |format| mask| entete|
|-------------------|-------------------|------| ------|
|Exemple_1                   |csv   |  \mask\mask_Exemple_1    |oui|
|Exemple_2                |plat       |    \mask\mask_Exemple_1    |non|
|Exemple_3     |zip         |         | |
|Exemple_4                  |tar         |          | |

## 6 . Exécution

```
usage: Main.py [-h] --indir INDIR --outdir OUTDIR

Anonymisation des données

optional arguments:
  -h, --help       show this help message and exit
  --indir INDIR    répertoire d’entrée contenant des fichiers à anonymiser
  --outdir OUTDIR  répertoire de sortie contenant des fichiers anonymisés

```

**Exemple :** 
 > python Main.py --indir path/repertoire/in  --outdir  path/repertoire/in  



**Remarque :** :warning:
>le programme d'anonymisation supprime automatiquement les données de prod au niveau du répertoire IN


> Il faut penser à vider le répertoire out une fois l'exécution terminée