#
#   Execution d'une liste de script sql.
#     La liste est contenue dans un fichier dont le nom est le premier parametre
#    Paremetres
#        1) nom du fichier contenant les script a executer
#        2) Alias de connexion ( SID)
#        3) username de connexion
#        4) mot de passe de connexio
#

 
export RET=0

#
# recuperarion des parametres
#
lecture_params () {

commande="$1"
echo $commande

param_exist=`expr index "$commande" "&"`
echo param exist = $param_exist

if [ "${param_exist}" != 0 ]
then
  les_params=${commande#*&}
  param_1=${les_params%%&*}
  les_params=${les_params#*&}
  param_exist=`expr index "$les_params" "&"`
  if [ "${param_exist}" != 0 ]
  then
     param_2=${les_params%%&*}
     les_params=${les_params#*&}
     param_exist=`expr index "$les_params" "&"`
     if [ "${param_exist}" != 0 ]
     then
        param_3=${les_params%%&*}
       les_params=${les_params#*&}
        param_exist=`expr index "$les_params" "&"`
        if [ "${param_exist}" != 0 ]
        then
           param_4=${les_params%%&*}
        else
           param_4=${les_params}
        fi
     else
        param_3=${les_params}
        param_4=""
     fi
  else
     param_2=${les_params}
     param_3=""
     param_4=""
  fi
else
   param_1=""
   param_2=""
   param_3=""
   param_4=""
fi

echo param 1 = $param_1
echo param 2 = $param_2
echo param 3 = $param_3
echo param 4 = $param_4


}

#
#  fichier de reprise
#
fic_ss_ext=$(basename $1 .${1##*.})

exec 2>&1 >> "${fic_ss_ext}_`date +%Y%m%d_%m%s`".log

echo $fic_ss_ext
fic_reprise=${fic_ss_ext}_$2_$3_exe_ok.txt
echo fichier de reprise : $fic_reprise
touch $fic_reprise
echo ....
echo ....

while read ligne  
do 

prem_car=${ligne:0:1}

# echo **** $prem_car

if [ "${ligne:0:1}" == "#" ] 
then 
  echo on a un # donc on est censé contiuer 
  continue 
fi

lecture_params "${ligne}"

scr_ss_e=${ligne%.*}
#
#   on enleve les parametres eventuels
#
if [ $(expr index "$scr_ss_e" "&") -ne 0 ]
then
   scr_ss_e=${scr_ss_e:1:$(expr index "$scr_ss_e" "&")-2}
fi   

echo Execution script $ligne 
echo verification si script déjà execute
deja_lance=`grep -c $scr_ss_e $fic_reprise`
echo $scr_ss_e
echo ......
echo deja_lance = $deja_lance
echo ......
if [ $deja_lance -ne 0 ]
then 
    echo script $ligne deja lance : donc pas de relance
else	
    echo ./lance_sql_client.sh $2 $3 $4 $scr_ss_e $param_1 $param_2 $param_3 $param_4
    source ./lance_sql_client.sh $2 $3 $4 $scr_ss_e $param_1 $param_2 $param_3 $param_4
    echo .....
    echo Fin Execution script $ligne 
	echo code retour = $RET
    echo ....
fi
if [ $RET -ne 0 ]
then
  exit 1
fi
## si le sctipt s'est bien passé on le met dans un fichier $1_exe_ok
#if [ $deja_lance -eq 0 ]
#then
   echo $ligne >> $fic_reprise
#fi   

done < $1
