spool exe_anonym_NDOD.log
select 'DEBUT ANONYMISATION du SCHEMA NDOD '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual
/
set feedback on
set feedback off
Select 'DEBUT Anonymisation table :'||'COMPLEMENT_EVENEMENT'||' : '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
set feedback on
UPDATE COMPLEMENT_EVENEMENT SET COMMENTAIRE = rpad('-',200,'-');
commit;
set feedback off
Select 'DEBUT Anonymisation table :'||'IDENTITE_TIERS'||' : '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
set feedback on
UPDATE IDENTITE_TIERS SET SIREN = '123456789';
commit;
set feedback off
Select 'DEBUT Anonymisation table :'||'RFT_ADMIN'||' : '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
set feedback on
UPDATE RFT_ADMIN SET CODE_POSTAL = rpad(substr(CODE_POSTAL,1,length(CODE_POSTAL)-3),length(CODE_POSTAL),'X');
commit;
set feedback off
Select 'DEBUT Anonymisation table :'||'TIERS_RFT'||' : '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
set feedback on
UPDATE TIERS_RFT SET SIREN = '123456789';
commit;
set feedback off
Select 'DEBUT Anonymisation table :'||'TIERS_RFT_IMPORT'||' : '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
set feedback on
UPDATE TIERS_RFT_IMPORT SET IDENTIFIANT_EXTERNE = '123456789';
commit;
set feedback off
select 'FIN ANONYMISATION du SCHEMA NDOD '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual
/
spool off
