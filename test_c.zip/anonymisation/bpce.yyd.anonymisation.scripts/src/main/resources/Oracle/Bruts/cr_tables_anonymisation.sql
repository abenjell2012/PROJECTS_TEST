create table param_anonym_table
(table_owner varchar2(30),
table_name  varchar2(30),
column_name varchar2(30),
categorie_dcp varchar2(20),
format        varchar2(20),
fn_mask       varchar2(20),
def_val       varchar2(100)
);

