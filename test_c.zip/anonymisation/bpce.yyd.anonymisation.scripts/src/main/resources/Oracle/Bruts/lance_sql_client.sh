#!/bin/bash
#------------------------------------------------------------------------
# Nom de la procedure   : @lance_sql_client.sh
# Date de creation          : 19/01/2011
# Objet                         : lancement du fichier sql � partir d'un client : 
# Auteur                        : BDI
#  Parametre 			: 1) le SID de la base sur laquelle on execute le SQL
#						  2) Le user de connexion
#						  3) le password du user de connexion
#                         4) le nom du script sql a lancer, sans l'extention 
#
#   Le shell va exicuter le script sql, va generer un log du m�me nom que le script
#     � l'ecran on aura le resultat de l'execution.
#------------------------------------------------------------------------



# export ORACLE_SID=$1
CONNECT_SID=$1
CONNECT_USER=$2
CONNECT_PWD=$3

export NLS_LANG=French_France.WE8ISO8859P1


$ORACLE_HOME/bin/sqlplus -s /nolog <<!
WHENEVER OSERROR EXIT FAILURE
WHENEVER SQLERROR EXIT SQL.SQLCODE

connect ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID}

WHENEVER OSERROR EXIT FAILURE
WHENEVER SQLERROR EXIT SQL.SQLCODE
spool $4_$1_$2.log
select 'Debut $4.sql a '||to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
@$4.sql $5 $6 $7 $8
select 'Fin $4.sql a '||to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
spool off
exit
!

export RET=$?
echo "Code Retour du traitement $4.sql : $RET"

if [ $RET -ne 0 ]
then
        echo "==> FIN ANORMALE pour $4.sql"
else
        echo "==> FIN NORMALE pour $4.sql"
fi



