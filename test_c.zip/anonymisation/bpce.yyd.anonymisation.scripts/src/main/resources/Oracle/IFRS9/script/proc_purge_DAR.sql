
spool proc_purge_DAR_pre_charge.log

create or replace procedure purge_DAR_pre_charge (par_dar varchar) is
--
--   procedure de purge des tables partitionnées sur une DAR
--   Parametre : DAR au format YYYYMM  ex : '201603'
--
lig_cmde   VARCHAR2 (300);
begin
  for c1 in (select 'alter table '||table_name||' truncate partition P_'||par_dar as cmde from user_tab_partitions where partition_name='P_'||par_dar )
  LOOP
   lig_cmde:=c1.cmde;
   execute immediate c1.cmde;
  END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (
            -20001,
               'err dans la procedure purge_DAR_pre_charge : DAR :'||par_dar||' cmde : '||lig_cmde|| SQLERRM);
end;
/

exec purge_DAR_pre_charge ('&&1');

drop procedure purge_DAR_pre_charge;

spool off

exit;

