
#
#   execution : 
#
#  ./expdp_DAR.sh 201603 YNSBXBF1_APPLI IFRS9ASS a
#
DAR_ANO=$1
CONNECT_SID=$2
CONNECT_USER=$3
CONNECT_PWD=$4


cp Modele_par_Partition.par exp_Partition_$1.par
echo sed -i \'s/XXXXXX/$1/g\'  exp_Partition_$1.par > subst_part.sh

chmod +x subst_part.sh

./subst_part.sh



expdp ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} parfile=exp_Partition_${DAR_ANO}.par


expdp ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} parfile=expdp_NON_PART.par

