
#
#   execution : 
#
#  ./anonymisation_IFRS9_DAR.sh 201603 YNSBXBF1_APPLI IFRS9ASS a
#
DAR_ANO=$1
CONNECT_SID=$2
CONNECT_USER=$3
CONNECT_PWD=$4


sqlplus ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} @anonymisation_DAR.sql ${DAR_ANO} > anonymisation_DAR_${DAR_ANO}.log

nohup sqlplus ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} @ANO_IFRS9_THREAD_1.sql &

nohup sqlplus ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} @ANO_IFRS9_THREAD_2.sql &


