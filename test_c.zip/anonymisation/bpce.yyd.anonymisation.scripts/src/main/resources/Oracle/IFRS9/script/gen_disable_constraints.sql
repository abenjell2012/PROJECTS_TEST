set heading off feedback off pagesize 0 linesize 150 echo off

spool disable_references.sql
select 'alter table "' ||  table_name || '" disable constraint ' || constraint_name || ';' stmt from user_constraints where  constraint_type = 'R' and status = 'ENABLED' order by owner, table_name;
spool off

spool enable_references.sql
select 'alter table "' ||  table_name || '" enable constraint ' || constraint_name || ';' stmt from user_constraints where  constraint_type = 'R' and status = 'ENABLED' order by owner, table_name;
spool off

spool disable_references.log

@disable_references.sql

spool off

exit
