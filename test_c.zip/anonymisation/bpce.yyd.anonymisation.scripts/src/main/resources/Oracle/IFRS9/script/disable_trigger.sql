
spool disable_trigger.log

alter trigger TRI_IFRS9_AJUSTEMENT disable;

spool off

exit
