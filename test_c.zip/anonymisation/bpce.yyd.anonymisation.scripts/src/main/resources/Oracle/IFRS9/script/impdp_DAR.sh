
#
#
#   procedure d'import des donnees anonymisees
#   execution : 
#
#  ./impdp_DAR.sh 201603 YNSBXBF1_APPLI IFRS9ASS a
#
DAR_ANO=$1
CONNECT_SID=$2
CONNECT_USER=$3
CONNECT_PWD=$4
SCHEMA_ORI=$5
SCHEMA_ANO=$6


cp Modele_par_Partition_imp.par imp_Partition_$1.par
echo sed -i \'s/XXXXXX/$1/g\'  imp_Partition_$1.par > subst_part.sh

chmod +x subst_part.sh

subst_part.sh

sqlplus  ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} @gen_disable_constraints.sql

sqlplus  ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} @disable_trigger.sql

--
--   purge de la DAR a importer
--
sqlplus  ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} @proc_purge_DAR.sql ${DAR_ANO}


impdp ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} parfile=imp_Partition_${DAR_ANO}.par REMAP_SCHEMA=${SCHEMA_ORI}:${SCHEMA_ANO}


impdp ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} parfile=impdp_NON_PART.par REMAP_SCHEMA=${SCHEMA_ORI}:${SCHEMA_ANO}



sqlplus  ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} <<!

spool enable_references.log

@enable_references.sql

spool off

!

sqlplus  ${CONNECT_USER}/${CONNECT_PWD}@${CONNECT_SID} @enable_trigger.sql



