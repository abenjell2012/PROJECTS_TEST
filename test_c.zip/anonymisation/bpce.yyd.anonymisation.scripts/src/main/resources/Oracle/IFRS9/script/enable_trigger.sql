
spool enable_trigger.log

alter trigger TRI_IFRS9_AJUSTEMENT enable;

spool off

exit
