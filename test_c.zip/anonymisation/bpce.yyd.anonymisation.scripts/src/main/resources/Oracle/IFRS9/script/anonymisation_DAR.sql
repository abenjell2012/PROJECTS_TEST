/* Anonymisation BDD
Tables audits
•	Tables à anonymiser (noms des personnes en clair) : IFRS9_AUDIT_SESSION / IFRS9_AUDIT_AJUST / IFRS9_AUDIT_ARRET_JOB / IFRS9_AUDIT_HABILITATION / IFRS9_AUDIT_PARAM
•	Faire un truncate des tables

Table habilitation
•	Table H_UTILISATEUR
•	Garder 0 les lignes avec établissement = « * - TOUS ETABLISSEMENTS » pour ne garder que les utilisateurs en central 

Table IFRS9_IMPORT
•	Table IFRS9_IMPORT
•	Colonnes (libellé des entrepreneurs) : ENTITY_DESC_NEW et ENTITY_DESC_ORIGINAL
•	Remplacer par « XXX »


Réalisation technique
•	2 scripts d'exports (un pour les tables partitionnées, et pour les tables non partitionées)  
•	2 scripts d'import (append pour les tables partitionées et truncate pour les tables non partitionnées) 
•	1 script d'ouverture de DAR sur la cible (pour créer les nouvelles partitions)
Tables à lister ?

*/

-- set timing on

truncate table IFRS9_AUDIT_SESSION ;
--truncate table  IFRS9_AUDIT_AJUST;
--truncate table  IFRS9_AUDIT_ARRET_JOB ;
truncate table  IFRS9_AUDIT_HABILITATION ;
truncate table  IFRS9_AUDIT_PARAM;

delete from H_UTILISATEUR where COD_BQ !='*';

-- update /*+ PARALLEL (IFRS9_IMPORT,4) */ IFRS9_IMPORT set ENTITY_DESC_NEW='XXX' , ENTITY_DESC_ORIGINAL='XXX' where COD_PRD_REF='&&1';

commit;

-- update /*+ PARALLEL (IFRS9_ANALYSE,4) */ IFRS9_ANALYSE  set ENTITY_DESC_NEW='XXX' , ENTITY_DESC_ORIGINAL='XXX' where COD_PRD_REF='&&1';

set pages 0
set feed off
set heading off
set verify off
set term off
set feedback off
set linesize 150
set pagesize 0

spool ANO_IFRS9_THREAD_1.sql

prompt set timin on

select cmd||chr(10)||'commit;' from (
select  'update /*+ PARALLEL ('||table_name||',8) */ '||table_name||' subpartition ('||subpartition_name||') '|| q'< set ENTITY_DESC_NEW='XXX' , ENTITY_DESC_ORIGINAL='XXX';  >' as cmd
, rownum as num_lig, row_number() over ( order by table_name,subpartition_name) as number_lig
from user_tab_subpartitions where table_name in ('IFRS9_ANALYSE','IFRS9_IMPORT') and partition_name='P_&&1' order by table_name,subpartition_name
) where  MOD(number_lig, 2) = 0;

spool off

spool ANO_IFRS9_THREAD_2.sql

prompt set timin on

select cmd||chr(10)||'commit;'  from (
select  'update /*+ PARALLEL ('||table_name||',8) */ '||table_name||' subpartition ('||subpartition_name||') '|| q'< set ENTITY_DESC_NEW='XXX' , ENTITY_DESC_ORIGINAL='XXX';  >' as cmd
, rownum as num_lig, row_number() over ( order by table_name,subpartition_name) as number_lig
from user_tab_subpartitions where table_name in ('IFRS9_ANALYSE','IFRS9_IMPORT') and partition_name='P_&&1' order by table_name,subpartition_name
) where  MOD(number_lig, 2) = 1;

spool off



exit;

