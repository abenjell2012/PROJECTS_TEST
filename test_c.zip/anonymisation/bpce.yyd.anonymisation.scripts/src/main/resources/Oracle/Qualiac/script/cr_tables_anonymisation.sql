
spool cr_tables_anonymisation.log

create table param_anonym_table
(table_owner varchar2(30),
table_name  varchar2(30),
column_name varchar2(30),
categorie_dcp varchar2(20),
format        varchar2(20),
fn_mask       varchar2(20),
def_val       varchar2(100)
);

--Table OETIE
 
--NOMOETIE         : nom
--NOROETIE          : prénom
--COLOETIE='S'

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OETIE' ,'NOMOETIE','CHAR','','ano_agreg_1','XXXXXX');

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OETIE' ,'NOROETIE','CHAR','','ano_agreg_1','XXXXXX');


--Table OETIA   => comment reconnait-on les personnes physiques et morales ? 
-- Le champs Statut (Paramètre JUR) : oetia.juroetia, permet de différencier en standard cet élément.
--NOMOETIA         : nom
--NOROETIA          : prénom
--AD1OETIA           : Adresse 1
--AD2OETIA           : Adresse 2
--AD3OETIA           : Adresse 3
--PTTOETIA            : Code postal
--VILOETIA             : Ville
--PAYOETIA           : Pays    ?
--INSOETIA            : Langue ?
--EMLOETIA          : Mail


insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OETIA' ,'NOMOETIA','CHAR','','ano_agreg_1','XXXXXX');

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OETIA' ,'NOROETIA','CHAR','','ano_agreg_1','XXXXXX');

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OETIA' ,'AD1OETIA','CHAR','','ano_agreg_1','XXXXXX');

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OETIA' ,'AD2OETIA','CHAR','','ano_agreg_1','XXXXXX');

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OETIA' ,'AD3OETIA','CHAR','','ano_agreg_1','XXXXXX');

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OETIA' ,'EMLOETIA','CHAR','','ano_agreg_1','mail@monmail.com');


--Table OEGES
--NOMOEGES
--PRNOEGES
--EMLOEGES
 
insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OEGES' ,'NOMOEGES','CHAR','','ano_agreg_1','XXXXXX');

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OEGES' ,'PRNOEGES','CHAR','','ano_agreg_1','XXXXXX');

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OEGES' ,'EMLOEGES','CHAR','','ano_agreg_1','mail@monmail.com');

--Table OETID
--Je ne vois pas de données personnelles dans cette table. 
-- On peut y trouver les RIB des salariés si ces informations sont stockées dans cette table pour votre contexte
--Mais Iban de la société :
--IBAOETID

insert into param_anonym_table 
(table_owner ,
table_name  ,
column_name ,
categorie_dcp ,
format        ,
fn_mask       ,
def_val       )
VALUES ('OPS$DBO','OETID' ,'IBAOETID','CHAR','','ano_agreg_1','FR7616188000057000000099979');

commit;

spool off

 