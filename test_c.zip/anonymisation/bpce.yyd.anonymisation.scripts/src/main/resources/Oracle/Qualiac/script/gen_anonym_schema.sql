--
--  procedure d'anonymisation d'un schema
--   parametre : 1) Nom du schema a anonymiser
--
set long 20000 longchunksize 20000 pagesize 0 linesize 1000 feedback off verify off trimspool on

DEFINE SCHEMA=&&1

spool exe_anonym_&&SCHEMA..sql

prompt spool exe_anonym_&&SCHEMA..log
prompt
prompt select 'DEBUT ANONYMISATION du SCHEMA &&SCHEMA '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual
prompt /
prompt
promp set feedback on
prompt

select decode (num_lig,1,'set feedback off'||chr(10)||'Select ''DEBUT Anonymisation table :''||'''||table_name||'''||'' : ''|| to_char(sysdate,''DD/MM/YYYY HH24:MI:SS'') from dual;'||chr(10)||'set feedback on'||chr(10)||'UPDATE '||table_name||' SET ',',')||column_name||' = '||
 case upper(fn_mask) 
      when 'ANO_AGREG_1' THEN ano_agreg_1 (categorie_dcp,format,  def_val)
      when 'BROUILLE_DATE' then 'Brouille_date ( '||column_name||', '''||format||''')'
      when 'INTERVALLE_DATE' then 'intervalle_date ('||column_name||', '''||format||''')'
      when 'ANO_AGREG_N' THEN ano_agreg_N (column_name, format,def_val)
	  when 'TRANSFORME' THEN  transforme (column_name, def_val,table_name)
 end     
      ||
 case num_lig
 when nb_lig  then ';'||chr(10)||'commit; '||chr(10)
 end CMDE_UPDATE
from (
select table_owner,table_name,column_name,categorie_dcp,format,fn_mask,def_val,
row_number () over (partition by table_owner,table_name order by column_name) num_lig,
count (*) over (partition by table_owner,table_name ) nb_lig
from param_anonym_table where table_owner = '&&SCHEMA'
);

prompt set feedback off
prompt
prompt select 'FIN ANONYMISATION du SCHEMA &&SCHEMA '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual
prompt /
prompt
prompt spool off

spool off 

! sed -i '/^$/d' exe_anonym_&&SCHEMA..sql

-- @exe_anonym_&&SCHEMA..sql

exit


