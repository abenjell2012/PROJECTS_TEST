-- spool exe_anonym_ANOQUALIAC.log
select 'DEBUT ANONYMISATION du SCHEMA ANOQUALIAC '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual
/
set feedback on
set feedback off
Select 'DEBUT Anonymisation table :'||'SVCLI'||' : '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
set feedback on

UPDATE SVCLI SET INXSVCLI  = ' BPCE.referentiel@bpce.fr'
;

commit;

set feedback off
Select 'DEBUT Anonymisation table :'||'OETIA'||' : '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
set feedback on

UPDATE OETIA SET EMLOETIA = ' BPCE.referentiel@bpce.fr'
,INXOETIA = ' BPCE.referentiel@bpce.fr'
;

commit;

UPDATE OETIA SET AD1OETIA = 'XXXXXX'
,AD2OETIA = 'XXXXXX'
,AD3OETIA = 'XXXXXX'
,NOMOETIA = 'XXXXXX'
,NOROETIA = 'XXXXXX'
where TIEOETIA in (select NUMOETIE  from OETIE where  COLOETIE in ('S','M'));

commit;

set feedback off
Select 'DEBUT Anonymisation table :'||'OETID'||' : '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
set feedback on
UPDATE OETID SET IBAOETID = 'FR7616188000057000000099979'
 where TIEOETID in (select NUMOETIE  from OETIE where  COLOETIE in ('S','M'));
 
commit;

set feedback off
Select 'DEBUT Anonymisation table :'||'OETIE'||' : '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual;
set feedback on
UPDATE OETIE SET NOMOETIE = 'XXXXXX'
,NOROETIE = 'XXXXXX'
where  COLOETIE in ('S','M');
commit;
set feedback off
select 'FIN ANONYMISATION du SCHEMA ANOQUALIAC '|| to_char(sysdate,'DD/MM/YYYY HH24:MI:SS') from dual
/
-- spool off
