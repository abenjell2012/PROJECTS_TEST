CREATE OR REPLACE procedure p_intervalle_date (  champ_ano date, mask varchar)
 AS
--
-- 
-- format du mask : '12 16 18 65'
--
--  recup mask
--
-- exec p_intervalle_date (to_date('15/03/1962','DD/MM/YYYY'),'12 16 18 65') ;
--
type tableinter is record ( inter_min number, inter_max number);
type tabledentiers is table of tableinter index by binary_integer;
ti tabledentiers;
i number;
nb_intervalles number; -- nombre d'intervalles
age_reel number;
age_calcul number;
date_naiss_calc date;
intervalle_recherche number;
begin
DBMS_OUTPUT.enable (1000000);
SELECT REGEXP_COUNT(mask, ' ', 1, 'i') into nb_intervalles
   FROM DUAL;
dbms_output.put_line ('nb_intervalles = '||nb_intervalles );   
--
--  chargement des intervalles
--
for i in 1..nb_intervalles+1 loop
select trim(substr(mask,decode(i,1,0,instr(mask,' ',1,i-1))+1,decode(i,nb_intervalles+1,length(mask),instr(mask,' ',1,i))-decode(i,1,0,instr(mask,' ',1,i-1)))) 
into ti(i).inter_min from dual;
dbms_output.put_line ('t('||i||')='||ti(i).inter_min );
end loop;

--
--
--
select floor(months_between( sysdate,  champ_ano) /12) into age_reel from dual;

dbms_output.put_line ('age_reel = '||age_reel );

--
--  identification de l'intervalle
--
-- si on est en dessous de l'age minimum 
if age_reel <= ti(1).inter_min 
then 
   intervalle_recherche := 0;
   age_calcul:= ti(1).inter_min;
else
--  si on est au dessus de l'age maxi
   if age_reel > ti(nb_intervalles+1).inter_min 
   then 
      intervalle_recherche := 999;
	  age_calcul:= ti(intervalle_recherche+1).inter_min;
   else
      for i in 1..nb_intervalles loop
        if age_reel > ti(i).inter_min and age_reel <= ti(i+1).inter_min 
         then
          intervalle_recherche:=i;
		  dbms_output.put_line ('intervalle recherche = '||intervalle_recherche );

          age_calcul:= (ti(intervalle_recherche).inter_min + ti(intervalle_recherche+1).inter_min )/2;

        end if;
      end loop;
   end if;
end if;   


dbms_output.put_line ('age_calcul = '||age_calcul );

date_naiss_calc := sysdate - age_calcul*365;
dbms_output.put_line ('date_naiss_calc = '||to_char(date_naiss_calc,'DD/MM/YYYY') );

end;
/


CREATE OR REPLACE function ano_agreg_1 (data_type varchar,format varchar, def_val varchar)
return varchar AS
-- renvoi  DEF_VAL au format défini par format et le type data_type
--
--  exemple :
--              data_type : DATE; format 'DD/YY/YYYY' ; def_val '15/03/1962' retour 'to_date('15/03/1962','DD/YY/YYYY')'
--
--    data_type autorisés : DATE; NUMBER; TIMESTAMP; CHAR
--    format autorisés    : tou format compatible avec le data_type et la val_def.
--
Valeur_retour varchar2(1000);
BEGIN
              CASE data_type 
			     WHEN 'CHAR' THEN
				   begin
                   Valeur_retour := ''''||def_val||'''';
				   end;
			     WHEN  'DATE'  THEN
				   begin
                   Valeur_retour := 'to_date('''||def_val||''','''||format||''')';
				   end;
			     WHEN 'NUMBER' THEN
				   begin
                   Valeur_retour := 'to_number('''||def_val||''','''||format||''')';
				   end;
			     WHEN 'TIMESTAMP' THEN
				   begin
                   Valeur_retour := 'to_timestamp('''||def_val||''','''||format||''')';
				   end;
				
              END CASE; -- Case type_part 

			  return Valeur_retour;
EXCEPTION
	WHEN OTHERS 
	        THEN
         raise_application_error (
            -20001,
               'err dans la procedure ano_agreg_1 : data_type : '
            || data_type
            || ' format : '||format||' def_val : '||def_val||' Sql err : '
            || SQLERRM
);
END;
/

CREATE OR REPLACE function ano_agreg_N (nom_champ varchar, data_type varchar,format varchar)
return varchar AS
-- renvoi  D
--  Si  data_type  = STRING : le champ en entrée avec les format derniers caracteres a X
--  Si DATATYPE = DATE 
--                  Si format=2 retourne la date avec 01 pour le jour
--                  Si format=4 retourne la date avec 1900 pour l'année
--  exemple :
--
Valeur_retour varchar2(1000);
BEGIN
              CASE data_type 
			     WHEN 'CHAR' THEN
				   begin
                   Valeur_retour := 'rpad(substr('||nom_champ||',1,length('||nom_champ||')-'||format||'),length('||nom_champ||'),''X'')';
				   end;
			     WHEN  'DATE'  THEN
				   begin
				    CASE format
				      WHEN '2' THEN
					      Valeur_retour := 'trunc('||nom_champ||',''MM'')';
--					      Valeur_retour := 'to_char(trunc('||nom_champ||',''MM''),''YYYYMMDD'')';
--                        Valeur_retour := 'to_char(trunc(to_date('||nom_champ||',''YYYYMMDD''),''MM''),''YYYYMMDD'')';
					  WHEN '4' THEN
					      Valeur_retour := 'trunc('||nom_champ||',''YYYY'')';
--					      Valeur_retour := 'to_char(trunc('||nom_champ||',''YYYY''),''YYYYMMDD'')';
--                        Valeur_retour := 'to_char(trunc(to_date('||nom_champ||',''YYYYMMDD''),''YYYY''),''YYYYMMDD'')';
				    END CASE;
				   end;
				
              END CASE; -- Case type_part 

			  return Valeur_retour;
EXCEPTION
	WHEN OTHERS 
	        THEN
         raise_application_error (
            -20001,
               'err dans la procedure ano_agreg_N : data_type : '
            || data_type
            || ' format : '||format||' nom_champ : '||nom_champ||' Sql err : '
            || SQLERRM
);
END;
/

CREATE OR REPLACE function Brouille_date (  champ_ano date, mask varchar)
return date AS
-- format du mask : +/- ou + ou -  suivi d''un nombre suivi de J M ou A
--
--  recup mask
--
interval varchar2(10);
unite varchar2(5);
nbre  number;
date_deb_interval date;
date_fin_interval date;
date_envoi date;
BEGIN
select     CASE when instr(mask,'+/-') != 0 then 'INTER' 
                when instr(mask,'+') != 0 then 'PLUS'
                when instr(mask,'-') != 0 then 'MOINS'
           end as interval,
           CASE when instr(mask,'J') != 0 then 'JOUR' 
                when instr(mask,'M') != 0 then 'MOIS'
                when instr(mask,'A') != 0 then 'ANNEE'
           end as unite,
           substr(mask,instr(mask,'+/-')+instr(mask,'+')+instr(mask,'-')+1,length(mask)-(instr(mask,'+/-')+instr(mask,'+')+instr(mask,'-'))-1) nbre
		   into interval,unite,nbre
from (                
 select ' +/- 720 j ',  replace(upper(rtrim(ltrim(' - 720 j '))),' ','') as mask from dual
 );
 

--INTERVAL	UNITE	NBRE
--	MOINS	JOUR	720
--
--   recherche de la date dans l'interval
--
CASE UNITE
  WHEN   'JOUR' then
	 CASE interval
	    WHEN   'INTER' THEN begin  date_deb_interval := champ_ano - nbre; date_fin_interval := champ_ano + nbre; end;
	    WHEN  'PLUS' THEN begin  date_deb_interval := champ_ano ; date_fin_interval := champ_ano + nbre; end;
	    WHEN  'MOINS' THEN begin  date_deb_interval := champ_ano - nbre; date_fin_interval := champ_ano ; end;
	 END CASE;
  WHEN  'MOIS' then     	 
	 CASE interval
	    WHEN  'INTER' THEN begin  date_deb_interval := add_months(champ_ano, - nbre); date_fin_interval := add_months(champ_ano , nbre); end;
	    WHEN  'PLUS' THEN begin  date_deb_interval := champ_ano ; date_fin_interval := add_months(champ_ano ,+ nbre); end;
	    WHEN  'MOINS' THEN begin  date_deb_interval := add_months(champ_ano ,- nbre); date_fin_interval := champ_ano ; end;
	 END CASE;
END CASE;
		
select champ_ano +
             trunc(dbms_random.value(0,(date_deb_interval-date_fin_interval+1))) into date_envoi
    from dual;

return 	date_envoi;

EXCEPTION
	WHEN OTHERS 
	        THEN
         raise_application_error (
            -20001,
               'err dans la procedure Brouille_date : champ_ano : '
            || to_char(champ_ano,'DD/MM/YYYY')
            || ' mask : '||mask||' Sql err : '
            || SQLERRM
);
END;
/

CREATE OR REPLACE function intervalle_date (  champ_ano date, mask varchar)
return date AS
--
-- 
-- format du mask : '12 16 18 65'
--
--  recup mask
--
-- select intervalle_date (to_date('15/03/1962','DD/MM/YYYY'),'12 16 18 65') from dual;
--
type tableinter is record ( inter_min number, inter_max number);
type tabledentiers is table of tableinter index by binary_integer;
ti tabledentiers;
i number;
nb_intervalles number; -- nombre d'intervalles
age_reel number;
age_calcul number;
date_naiss_calc date;
intervalle_recherche number;
begin
DBMS_OUTPUT.enable (1000000);
if champ_ano is null then return null; end if;
SELECT REGEXP_COUNT(mask, ' ', 1, 'i') into nb_intervalles
   FROM DUAL;
dbms_output.put_line ('nb_intervalles = '||nb_intervalles );   
--
--  chargement des intervalles
--
for i in 1..nb_intervalles+1 loop
select trim(substr(mask,decode(i,1,0,instr(mask,' ',1,i-1))+1,decode(i,nb_intervalles+1,length(mask),instr(mask,' ',1,i))-decode(i,1,0,instr(mask,' ',1,i-1)))) 
into ti(i).inter_min from dual;
dbms_output.put_line ('t('||i||')='||ti(i).inter_min );
end loop;

--
--
--
select floor(months_between( sysdate,  champ_ano) /12) into age_reel from dual;

dbms_output.put_line ('age_reel = '||age_reel );

--
--  identification de l'intervalle
--
-- si on est en dessous de l'age minimum 
if age_reel <= ti(1).inter_min 
then 
   intervalle_recherche := 0;
   age_calcul:= ti(1).inter_min;
else
--  si on est au dessus de l'age maxi
   if age_reel > ti(nb_intervalles+1).inter_min 
   then 
      intervalle_recherche := 999;
	  age_calcul:= ti(intervalle_recherche+1).inter_min;
   else
      for i in 1..nb_intervalles loop
        if age_reel > ti(i).inter_min and age_reel <= ti(i+1).inter_min 
         then
          intervalle_recherche:=i;
		  dbms_output.put_line ('intervalle recherche = '||intervalle_recherche );

          age_calcul:= (ti(intervalle_recherche).inter_min + ti(intervalle_recherche+1).inter_min )/2;

        end if;
      end loop;
   end if;
end if;   


dbms_output.put_line ('age_calcul = '||age_calcul );

date_naiss_calc := sysdate - age_calcul*365;
dbms_output.put_line ('date_naiss_calc = '||to_char(date_naiss_calc,'DD/MM/YYYY') );
 return date_naiss_calc;
end;
/

CREATE OR REPLACE function transforme (nom_champ varchar, format varchar, nom_table varchar)
return varchar AS
-- renvoi  
--  Si  data_type  = STRING : le champ en entrée avec les format derniers caracteres a X
--  Si DATATYPE = DATE 
--                  Si format=2 retourne la date avec 01 pour le jour
--                  Si format=4 retourne la date avec 1900 pour l'année
--  exemple :
--
--   FILL("X") remplit le champ de X sur tout sa longueur
--   SUBST("X") remplace les caracteres par des X
--
-- select rpad('X',length('toto'),'X') from dual;
--select 'FILL("X")',substr('FILL("X")',1,instr('FILL("X")','(')-1),
-- replace(substr('FILL("X")',instr('FILL("X")','(')+1,instr('FILL("X")',')')-instr('FILL("X")','(')-1),'"','')
-- from dual;
Valeur_retour varchar2(1000);
function_trans varchar2(20);
value_trans  varchar2(5);
longueur_champ number;
step varchar2(30);
BEGIN
--
-- recup de la longueur du champ
--
step := 'recup longueur';
select CHAR_LENGTH into longueur_champ 
from user_tab_columns where table_name=nom_table and column_name=nom_champ; 
--
-- recup de la fonction
--
step := 'recup fonction';
select substr(format,1,instr(format,'(')-1),
 replace(substr(format,instr(format,'(')+1,instr(format,')')-instr(format,'(')-1),'"','')
 into function_trans,value_trans
 from dual;
step := 'le case';
              CASE function_trans 
			     WHEN 'SUBST' THEN
				   begin
                   Valeur_retour := 'rpad('''||value_trans||''',length('||nom_champ||'),'''||value_trans||''')';
				   end;
			     WHEN 'FILL' THEN
				   begin
                   Valeur_retour := 'rpad('''||value_trans||''','||longueur_champ||','''||value_trans||''')';
				   end;
				
              END CASE; -- Case function_trans 

			  return Valeur_retour;
EXCEPTION
	WHEN OTHERS 
	        THEN
         raise_application_error (
            -20001,
               'err dans la procedure transforme :  '
            || ' format : '||format||' nom_champ : '||nom_champ||'Table : '||nom_table||' Step : '||step||' Sql err : '
            || SQLERRM
);
END;
/


CREATE OR REPLACE function SHA2 (p_value varchar,def_val varchar)
return varchar AS
--
-- renvoi  un valeur anonymisée avec la fonction STANDARD_HASH
--
--
Valeur_retour varchar2(1000);
BEGIN
 select substr(RawToHex(standard_hash(p_value,'SHA256')),1,def_val) into Valeur_retour from dual;

return Valeur_retour;
EXCEPTION
	WHEN OTHERS 
	        THEN
         raise_application_error (
            -20001,
               'err dans la procedure SHA2 : p_value : '
            || p_value
            ||' def_val : '||def_val||' Sql err : '
            || SQLERRM
);
END;
/


