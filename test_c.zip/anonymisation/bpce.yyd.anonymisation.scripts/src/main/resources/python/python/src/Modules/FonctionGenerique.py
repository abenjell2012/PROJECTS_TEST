import re
import random
import hashlib
import datetime
from pathlib import Path
import pandas as pd
import math
import sys


class FonctionGenerique:

    def args_as_str(args):
        if isinstance(args, list):
            args = args[0]
        return str(args)

    def COPY(text, args=None):
        return str(text)

    def Agregation_1(text, args):
        """
        Remplace la valeur par une même et unique valeur
        Exemle : bpce => valeur
        :param args: tableau des arguments (valeur de remplacement)
        :return:
        """
        if str(text) != 'nan':
            return str(args[0])
        return ""

    def transformeSubst(text, args):
        """
        Remplace la valeur par une même et unique valeur sur la langeur du valeur donnée
        Exemple bpce => ****
        :param args: valeur de remplacement
        :return:
        """
        if str(text) != 'nan':
            return re.sub(r'[^ ]', str(args[0]), str(text))
        return ""

    def transformeFill(text, args):
        """
        Remplace la valeur par une même et unique valeur sur la langeur du champs
        Exemple : bpce => ********** (langeur x *)
        :param args: tableau des arguments
        :return:
        """
        if str(text) != 'nan':
            return args[1] * args[0]
        return str(text)

    def TransformeCrypt(text, args=None):
        """
        Crypter une chaine de characters  avec un hachage cryptographiques de type sha256
        :param args:tableau des arguments
        :return: les 9 premiers characters
        """
        if str(text) != 'nan':
            text = str(text)
            sha_signature = hashlib.sha256(text.encode()).hexdigest()
            return str(sha_signature[0:9])

    def Agregation_N(text, args):
        """
        Diminue la précision de l'information
        Exemple : bpce => bp** (2 derniers characters )
        :param args:tableau des arguments
        :return:
        """
        if str(text) != 'nan':
            text = str(text)
            debut = len(text) - int(args[0])
            n = int(args[0])
            replaceWith = str(args[1])
            header = text[slice(debut)]
            rest = text[-n:]
            masqueRest = re.sub(r'[^ ]', replaceWith, rest)
            return header + masqueRest
        return ""

    def read_lines(path):
        """
        lire un fichier opendata
        :return:
        """
        path = Path(path)
        lines = []
        with open(path, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    lines.append(line)
        return lines

    def substitution(path, args=None):
        """
        Remplace la valeur par une autre valeur puisée (aléatoirement de préférence) dans une liste  de valeurs
        fictives (sources Opendata par exemple)
        :param args: tableau des arguments
        :return:
        """
        lines = FonctionGenerique.read_lines(path)
        name = random.choice(lines)
        return name.replace(',', ' ')

    def brouillage(text, args):
        """
        applique un "bruit" aléatoire sur une valeur, dont la largeur du spectre est défini par les amplitudes inf et
        sup autour de la valeur réelle.
        Exemple : 1992/09/01 => 1992/09/04 (+ 3jours)
        :param args: tableau des arguments
        :return:
        """
        datetime_object = datetime.datetime.strptime(text, '%Y-%m-%d')
        days = int(args[0])
        randomN = random.randrange(days)
        if args[1].strip() == "+":
            res = datetime_object + datetime.timedelta(days=randomN)
        else:
            res = datetime_object - datetime.timedelta(days=randomN)
        return res.strftime('%Y-%m-%d')

    def getConfigLine(configFile, column, mapingValue):
        df = pd.read_csv(configFile, sep=';')
        line = df.loc[df.COLUMN_NAME == column]
        return line[mapingValue].values

    def mapping(configFile, fileIn):
        dfConfig = pd.read_csv(configFile, sep=';')
        # line = dfConfig.loc[dfConfig.COLUMN_NAME == 'COLUMN_NAME']
        headerConfig = list(dfConfig.columns)

        dfCsv = pd.read_csv(fileIn, sep=',')
        # lineCsv = dfCsv.loc[dfCsv.COLUMN_NAME == 'COLUMN_NAME']
        headerCsv = list(dfCsv.columns)
        liste = []
        for x in headerCsv:
            print("Nom de la colonne :", x)
            columnMasking = FonctionGenerique.getConfigLine(configFile, x, 'COLUMN_NAME')
            maskingFunction = FonctionGenerique.getConfigLine(configFile, x, 'MASKING')
            paramsofMasking = FonctionGenerique.getConfigLine(configFile, x, 'PARAMS')
            liste.append([columnMasking, maskingFunction, paramsofMasking])

        return liste

    def masker(fichier, column, maskingFunction, params):

        with open(fichier, 'r') as file:
            lines = [l.strip().split(';') for l in file.readlines()]
            indexNom = lines[0].index(column)
            # print(indexNom)

        modifiedlines = []

        if maskingFunction == 'agregation_N':
            for i in lines[1:]:
                i[indexNom] = FonctionGenerique.agregation_N(i[indexNom], int(params[0]), params[2])
                modifiedlines.append(';'.join(i) + '\n')
        elif maskingFunction == 'agregation_1':
            for i in lines[1:]:
                i[indexNom] = FonctionGenerique.agregation_1(i[indexNom], params[0])
                modifiedlines.append(';'.join(i) + '\n')
        elif maskingFunction == 'brouillage':
            for i in lines[1:]:
                i[indexNom] = FonctionGenerique.brouillage(i[indexNom], params[0], params[2])
                modifiedlines.append(';'.join(i) + '\n')

        return modifiedlines
