import unittest
from Modules.FonctionGenerique import FonctionGenerique


class MyTestCase(unittest.TestCase):

    def test_copy(self):
        value = '0000002750'
        expected = '0000002750'
        actual = FonctionGenerique.COPY(value)
        message = "la valeur attendue : ", expected, " est différente de la valeur actuelle : ", actual
        self.assertEqual(actual, expected, message)

    def test_agregation_1(self):
        value = '0034'
        replaceValue = ['Ceci est le Libellé']
        expected = 'Ceci est le Libellé'
        actual = FonctionGenerique.agregation_1(value, replaceValue)
        message = "la valeur attendue : ", expected, " est différente de la valeur actuelle : ", actual
        self.assertEqual(actual, expected, message)

    def test_transformeSubst(self):
        value = '0034BPCE'
        replaceValue = '*'
        expected = '********'
        actual = FonctionGenerique.transformeSubst(value, replaceValue)
        message = "la valeur attendue : ", expected, " est différente de la valeur actuelle : ", actual
        self.assertEqual(actual, expected, message)

    def test_transformeFill(self):
        value = '0034BPCE'
        replaceValue = [10, '*']
        expected = '**********'
        actual = FonctionGenerique.transformeFill(value, replaceValue)
        message = "la valeur attendue : ", expected, " est différente de la valeur actuelle : ", actual
        self.assertEqual(actual, expected, message)

    def test_transformeCrypt(self):
        value = '0034BPCE'
        expected = 'f3dc73dc2'
        actual = FonctionGenerique.transformeCrypt(value)
        message = "la valeur attendue : ", expected, " est différente de la valeur actuelle : ", actual
        self.assertEqual(actual, expected, message)

    def test_Agregation_N(self):
        value = '0034BPCE'
        replaceValue = [2, '*']
        expected = '0034BP**'
        actual = FonctionGenerique.agregation_N(value, replaceValue)
        message = "la valeur attendue : ", expected, " est différente de la valeur actuelle : ", actual
        self.assertEqual(actual, expected, message)


'''
    def test_brouillage(self):
        value = '1993-01-27'
        replaceValue = [2, '+']
        expected = '1993-01-29'
        actual = FonctionGenerique.brouillage(value, replaceValue)
        self.assertEqual(actual, expected)
'''

if __name__ == '__main__':
    unittest.main()
