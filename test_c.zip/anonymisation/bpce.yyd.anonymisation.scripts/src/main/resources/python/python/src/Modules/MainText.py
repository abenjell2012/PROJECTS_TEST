from FonctionGenerique import FonctionGenerique
import pandas as pd
import time
import os
import argparse
import sys

parser = argparse.ArgumentParser(description='Anonymisation des données')
parser.add_argument("--filein", required=True, help="fichier csv à anonymiser",
                    )
parser.add_argument("--fileout", required=True, help="fichier anonymisé")
parser.add_argument("--filemask", required=True, help="fichier de configuration des champs à anonymiser")

args = parser.parse_args()
Filein = args.filein
Fileout = args.fileout
filemask = args.filemask

start_time = time.time()


def detect_encoding(path):
    cmd = f"file -i '{path}' "
    cmd += "| awk '{print $3}'"
    text = os.popen(cmd).read().split("=")
    if len(text) == 2:
        return text[1].strip()
    return "utf-8"


def slices(text, sizes):
    position = 0
    for size in sizes:
        yield text[position:position + size]
        position += size


def read_config(path=filemask):
    df = pd.read_csv(path, delimiter=";", encoding='ISO-8859-5')
    return df


def get_width(path=filemask):
    df = pd.read_csv(path, delimiter=";", encoding='ISO-8859-5')
    return df["VAR_LENGTH"].dropna().tolist()


def write_output(df, width, fout, line):
    new_line = ""
    line = line.strip('\n')
    line = list(slices(line, width))

    index = 0
    for _, d in df.iterrows():
        if isinstance(d['MASK_VALUE'], str):
            args = d['MASK_VALUE'].split(", ")
        elif not isinstance(d['MASK_VALUE'], list):
            args = [""]
        func = eval(f"FonctionGenerique.{d['MASKING']}")
        new_line += func(line[index], args)
        index += 1
    fout.write(new_line)
    fout.write("\n")


def main():
    print("Traitement en cours ..")
    df = read_config()
    width = get_width()
    with open(Filein, 'r', encoding='ISO-8859-5') as fin:
        # next(fin)
        with open(Fileout, 'w') as fout:
            for line in fin:
                if line.strip():
                    write_output(df, width, fout, line)
    print("Done!")


if __name__ == "__main__":
    main()

print("--- Temps de traitement : %s seconds ---" % (time.time() - start_time))
