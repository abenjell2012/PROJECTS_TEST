from FonctionGenerique import FonctionGenerique
import time
import csv
from functools import partial
import argparse
import sys
import os.path
import pandas as pd

start_time = time.time()


def detect_encoding(path):
    cmd = f"file -i '{path}' "
    cmd += "| awk '{print $3}'"
    text = os.popen(cmd).read().split("=")
    if len(text) == 2:
        return text[1].strip()
    return "utf-8"


def anonymiser(fichierIn, fichierOut, fichierConfig):
    print("Traitement en cours ...")
    fns = {
        'agregation_1': FonctionGenerique.Agregation_1,
        'agregation_N': FonctionGenerique.Agregation_N,
        'COPY': FonctionGenerique.COPY,
        'Transforme': FonctionGenerique.transformeSubst,
        'TransformeCrypt': FonctionGenerique.TransformeCrypt,
    }
    df_config = pd.read_csv(fichierConfig, sep=';', encoding='utf8')
    df_config.apply(lambda x: pd.api.types.infer_dtype(x.values))

    col_fns = {r['COLUMN_NAME']: partial(fns[r['MASKING']], args=str(r['MASK_VALUE']).split(', ')) for _, r in
               df_config.iterrows()}
    chunkSize = 10000
    df = pd.read_csv(
        fichierIn, dtype=str, sep=';', low_memory=True, chunksize=chunkSize, error_bad_lines=False
        , encoding="ISO-8859-1")
    for i, chunk in enumerate(df):
        columbToUpdate = list(col_fns)
        chunk[columbToUpdate] = chunk[columbToUpdate].apply(col_fns)  # appliquer les functions
        chunk.to_csv(
            fichierOut, encoding="ISO-8859-1", index=False, header=(i == 0), sep=';',
            mode='w' if i == 0 else 'a')


parser = argparse.ArgumentParser(description='Anonymisation des données')
parser.add_argument("--filein", required=True, help="fichier csv à anonymiser",
                    )
parser.add_argument("--fileout", required=True, help="fichier anonymisé")
parser.add_argument("--filemask", required=True, help="fichier de configuration des champs à anonymiser")

args = parser.parse_args()
Filein = args.filein
Fileout = args.fileout
filemask = args.filemask

try:
    print("Traitement en cours ..")
    anonymiser(Filein, Fileout, filemask)
    os.remove(Filein)
    print("--- le fichier a été bien anonymisé ---")

    print("--- Temps de traitement : %s seconds ---" % (time.time() - start_time))


except Exception as ex:
    print("Error:" + str(ex))
    sys.exit(1)
