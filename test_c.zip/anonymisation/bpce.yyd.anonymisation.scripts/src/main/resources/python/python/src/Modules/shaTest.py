import Crypto.Random
from Crypto.Cipher import AES
import hashlib, uuid

# salt size in bytes
SALT_SIZE ='d568fc812c4c4c34a40ddb40616f245d'

# number of iterations in the key generation
NUMBER_OF_ITERATIONS = 20

# the size multiple required for AES
AES_MULTIPLE = 16

password = 'test_password'
salt = uuid.uuid4().hex
print(salt)
hashed_password = hashlib.sha512(password.encode('utf-8') + SALT_SIZE.encode('utf-8')).hexdigest()

print(hashed_password)