package fr.bpce.yyd.batch.task;

import java.time.LocalDate;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.commun.messages.ProducteurMessages;
import fr.bpce.yyd.batch.commun.messages.Topic;
import fr.bpce.yyd.batch.commun.repositories.ParMdcRepository;
import fr.bpce.yyd.batch.messages.dto.LotIdTiersDTO;

public class EnvoiTiersACalculerTask implements Tasklet {

	private static Logger logger = Logger.getLogger(EnvoiTiersACalculerTask.class);

	@Autowired
	private ParMdcRepository parMdcRepo;

	private NdodFile ndodFile;
	private Long guid;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
			throws UnknownPropertyException, InvalidInitialisationException {

		if (ndodFile != null && ndodFile.isaEnvoyer()) {

			String nbTiersParLot = ConfigManager.getProperty("nb.tiers.liste.batch.trt.evenements");
			int nbTiersPaquet = Integer.parseInt(nbTiersParLot);
			String topicNameCalculListe = ConfigManager.getProperty("kafka.topic.calcul_liste");
			String topicNameClotureListe = ConfigManager.getProperty("kafka.topic.cloture_liste");

			// récupérer parametre DATE_CALCUL_COURANTE
			LocalDate dateCalcul = parMdcRepo.findDateCalculCourante();

			logger.info("Début d'envoi des messages kafka");
			LotIdTiersDTO lotIds = new LotIdTiersDTO();
			// Date calcul trt-evt égale date calcul compteur + 1
			lotIds.setDateCalcul(dateCalcul.plusDays(1));
			lotIds.setGuid(guid);
			int i = 0;
			i = envoiTiersACalculer(topicNameCalculListe, lotIds, i, nbTiersPaquet);
			envoiTiersACloturer(topicNameClotureListe, lotIds, i, nbTiersPaquet);
			logger.info("Fin d'envoi des messages kafka");
		} else {
			logger.info("L'envoi kafka est désactivé");
		}

		return RepeatStatus.FINISHED;
	}

	private void envoiTiersACloturer(String topicNameClotureListe, LotIdTiersDTO lotIds, int i, int taillePaquet) {
		logger.info("Début d'envoi des Tiers a cloturer");
		for (Long idTiers : ndodFile.getIdsTiersACloturer()) {
			lotIds.addIdTiers(idTiers);
			if (++i % taillePaquet == 0) {
				envoieLotIds(lotIds, Topic.CLOTURE_LISTE, topicNameClotureListe);
			}
		}
		envoieLotIds(lotIds, Topic.CLOTURE_LISTE, topicNameClotureListe);
		logger.info("Fin d'envoi des Tiers a cloturer");
	}

	private int envoiTiersACalculer(String topicNameCalculListe, LotIdTiersDTO lotIds, int i, int taillePaquet) {
		logger.info("Début d'envoi des Tiers a calculer");
		for (Long idTiers : ndodFile.getIdsTiersATraiter()) {
			if (!ndodFile.getIdsTiersACloturer().contains(idTiers)) {
				lotIds.addIdTiers(idTiers);
				if (++i % taillePaquet == 0) {
					envoieLotIds(lotIds, Topic.CALCUL_LISTE, topicNameCalculListe);
				}
			}
		}
		envoieLotIds(lotIds, Topic.CALCUL_LISTE, topicNameCalculListe);
		logger.info("Fin d'envoi des Tiers a calculer");
		return i;
	}

	private void envoieLotIds(LotIdTiersDTO lotIds, Topic topic, String name) {

		if (!lotIds.getIdsTiers().isEmpty()) {
			ProducteurMessages producteur = MessagesFactory.getProducteur();
			producteur.envoieMessage(topic, name, lotIds);
			// Réinitialisation
			lotIds.getIdsTiers().clear();
		}
	}

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}

	public void setGuid(Long guid) {
		this.guid = guid;
	}

	public void setParMdcRepo(ParMdcRepository parMdcRepo) {
		this.parMdcRepo = parMdcRepo;
	}

}
