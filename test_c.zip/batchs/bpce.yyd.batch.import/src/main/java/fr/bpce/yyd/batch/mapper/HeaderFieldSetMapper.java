package fr.bpce.yyd.batch.mapper;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.beans.LigneImport;

@Service
public class HeaderFieldSetMapper implements FieldSetMapper <LigneImport>{

	@Override
	public LigneImport mapFieldSet(FieldSet fieldSet) {
		LigneImport data = new LigneImport();
		data.setIsDetail(false);

		return data;
	}
}

