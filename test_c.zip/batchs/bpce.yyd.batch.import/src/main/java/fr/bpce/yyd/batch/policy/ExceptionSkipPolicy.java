package fr.bpce.yyd.batch.policy;

import java.io.FileNotFoundException;

import org.apache.log4j.Logger;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.transform.IncorrectLineLengthException;
import org.springframework.beans.factory.annotation.Autowired;

import fr.bpce.yyd.batch.beans.LigneImport;
import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.repositories.ImportRepository;
import fr.bpce.yyd.batch.util.ControleTechniqueUtil;
import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditLignesImport;

public class ExceptionSkipPolicy implements SkipPolicy {

	private static final Logger logger = Logger.getLogger(ExceptionSkipPolicy.class);
	private NdodFile ndodFile;

	@Autowired
	ImportRepository importRepo;

	public void setIdentiteRepos(ImportRepository identiteRepos) {
		this.importRepo = identiteRepos;
	}

	public ExceptionSkipPolicy(Class<? extends Exception> exceptionClassToSkip) {
	}

	@Override
	public boolean shouldSkip(Throwable exception, int skipCount) {

		if (exception instanceof FileNotFoundException) {
			return false;
		} else if (exception instanceof FlatFileParseException) {
			FlatFileParseException ffpe = (FlatFileParseException) exception;

			// element de l'erreur
			Throwable cause = ffpe.getCause();

			if (cause instanceof IncorrectLineLengthException) {
				IncorrectLineLengthException ille = (IncorrectLineLengthException) cause;
				String line = ille.getInput();
				int numLine = ffpe.getLineNumber();
				int expectedLineLength = ille.getExpectedLength();
				int actualLineLength = ille.getActualLength();
				boolean isDetail;
				Controles erreur;
				// code à revoir , car le controle sur les longueurs d'entete et
				// d'enqueue est fait en amont
				// à l'étape de validation du fichier
				if (line.startsWith(Constant.TYPE_LIGNE_ENTETE)) {
					isDetail = false;
					erreur = Controles.CT039;
				} else if (line.startsWith(Constant.TYPE_LIGNE_ENQUEUE)) {
					isDetail = false;
					erreur = Controles.CT040;
				} else {
					isDetail = true;
					erreur = Controles.CT030;
				}
				String messageErreur = erreur.getMessage(actualLineLength, expectedLineLength);

				if (isDetail) {
					// persist rejet
					controleLongueurEtRejet(line, numLine, erreur, actualLineLength, expectedLineLength, messageErreur);
					return true;
				} else {
					ndodFile.getAuditFichier().setCodAudit(erreur);
					ndodFile.getAuditFichier().setLibCodAudit(messageErreur);
				}
			}
			return false;
		}
		// Caused by:
		// org.springframework.batch.item.file.transform.IncorrectLineLengthException:
		// Line is shorter than max range 400
		else {
			return false;
		}
	}

	private void controleLongueurEtRejet(String line, int numLine, Controles erreur, int actualLineLength,
			int expectedLineLength, String messageErreur) {
		if (!line.trim().isEmpty()) {
			LigneImport ligneImport = new LigneImport();
			ControleTechniqueUtil controle = new ControleTechniqueUtil(ligneImport, ndodFile.getAuditFichier(), line,
					numLine, ndodFile.isInitFile(), ndodFile.isMensuelFile());
			controle.controleLongeureLigne(erreur, actualLineLength, expectedLineLength);
			String message = messageErreur + " ligne : [" + line + "]";

			for (AuditLignesImport ligneAudit : ligneImport.getAuditLigne()) {
				importRepo.persist(ligneAudit);
			}
			ndodFile.incrementeNbLinesRejet();

			logger.error(message);
		}
	}

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}

}
