package fr.bpce.yyd.batch.task;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.commun.enums.Controles;

public class StopJobDecider implements JobExecutionDecider {

	private NdodFile ndodFile;

	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {
		if (!Controles.FICENCOURS.equals(ndodFile.getAuditFichier().getCodAudit())) {
			return new FlowExecutionStatus("STOP");
		}

		if (ndodFile.isContagionFile()) {
			return new FlowExecutionStatus("CON");
		}
		return new FlowExecutionStatus(jobExecution.getExitStatus().toString());
	}

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}

}
