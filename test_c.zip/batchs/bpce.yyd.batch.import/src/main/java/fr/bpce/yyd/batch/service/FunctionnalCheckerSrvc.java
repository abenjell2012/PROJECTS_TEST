package fr.bpce.yyd.batch.service;

import java.time.LocalDate;
import java.util.Optional;

import fr.bpce.yyd.batch.beans.ImportEvtCloBean;

public interface FunctionnalCheckerSrvc {

	boolean isCodeBanqueValide(String codBq);

	boolean isCodeEvementValide(String codEvt, LocalDate dateDemande);

	boolean isCodeEvementContagionValide(String codEvt, LocalDate dateDemande);

	boolean isCodeSegmentValide(String codCliSeg);

	Optional<String> getLibelleSegment(String codCliSeg);

	boolean isSousCodeEvtValide(String ssCodeEvt, String codeEvt, LocalDate dateDemande);

	String findCategorieSegment(String segment);

	String findImpactEvenement(String codEvt, String catSegment, LocalDate dateDemande);

	boolean isEvementAnnule(String codEvt, String idLocalTiers, String idLocalEvenement, String codeBanque,
			LocalDate dateDebut);

	ImportEvtCloBean chercheEvenementCloture(String codeBanque, String idLocalTiers, String codEvt,
			String idLocalEvenement, LocalDate dateDebut);

	Boolean chercheTiersOrigContagion(String idRft);

	Boolean tiersHasDefautActif(String idRft);
}
