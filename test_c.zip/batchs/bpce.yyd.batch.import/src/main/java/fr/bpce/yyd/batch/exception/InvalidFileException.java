package fr.bpce.yyd.batch.exception;

public class InvalidFileException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public InvalidFileException (String libelle) {
		super(libelle);
	}

	
}
