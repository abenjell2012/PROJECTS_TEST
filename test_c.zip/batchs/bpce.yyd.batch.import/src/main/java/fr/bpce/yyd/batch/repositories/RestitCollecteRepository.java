package fr.bpce.yyd.batch.repositories;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.batch.beans.RestitDtSgmEvt;
import fr.bpce.yyd.batch.beans.RestitDtStEvt;
import fr.bpce.yyd.commun.model.AuditFichiers;

@Repository
public class RestitCollecteRepository {

	private static final String RESTIT_DETAIL_STATUT_EVT_QUERY = "select  evt.CODE, complevt.STATUT_EVENEMENT, sum (complevt.MONTANT_ARRIERE), count(evt.CODE) "
			+ "from EVENEMENT evt inner join COMPLEMENT_EVENEMENT complEvt on complEvt.EVENEMENT_ID = evt.ID "
			+ "where complevt.audit_fichier_id = :auditFicId group by evt.code, complevt.statut_evenement "
			+ "order by evt.code, complevt.statut_evenement asc";

	private static final String RESTIT_DETAIL_SEGMENT_EVT_QUERY = "SELECT  identite.CODE_SEGMENT, count(evt.CODE) from IDENTITE_TIERS identite "
			+ "inner join EVENEMENT evt on evt.identite_initiale_id = identite.id "
			+ "inner join COMPLEMENT_EVENEMENT compl on  compl.EVENEMENT_ID = evt.ID and compl.identite_initiale_id = identite.id "
			+ "where compl.audit_fichier_id = :auditFicId group by identite.CODE_SEGMENT "
			+ "order by identite.CODE_SEGMENT asc";

	@Autowired
	private EntityManager entityManager;

	public AuditFichiers findAuditFichierByJobId(Long jobId) {
		TypedQuery<AuditFichiers> query = entityManager.createNamedQuery("auditFichier.par.jobId", AuditFichiers.class);
		query.setParameter("jobId", jobId);
		return query.getSingleResult();
	}

	public List<RestitDtStEvt> findRestitDetailStatutEvt(long auditFichierId) {

		Query query = entityManager.createNativeQuery(RESTIT_DETAIL_STATUT_EVT_QUERY);
		query.setParameter("auditFicId", auditFichierId);
		List<RestitDtStEvt> ret = new ArrayList<>();

		for (Object lineAsObject : query.getResultList()) {
			Object[] lineAsArray = (Object[]) lineAsObject;
			RestitDtStEvt restitDtStEvt = new RestitDtStEvt();
			restitDtStEvt.setCodeEvt((String) lineAsArray[0]);
			restitDtStEvt.setStatutEvt((String) lineAsArray[1]);
			restitDtStEvt.setSommeMntArriere((BigDecimal) lineAsArray[2]);
			restitDtStEvt.setNombreEvt(((Number) lineAsArray[3]).longValue());
			ret.add(restitDtStEvt);
		}
		return ret;
	}

	public List<RestitDtSgmEvt> findRestitDetailSegEvt(long auditFichierId) {

		Query query = entityManager.createNativeQuery(RESTIT_DETAIL_SEGMENT_EVT_QUERY);
		query.setParameter("auditFicId", auditFichierId);
		List<RestitDtSgmEvt> ret = new ArrayList<>();

		for (Object lineAsObject : query.getResultList()) {
			Object[] lineAsArray = (Object[]) lineAsObject;
			RestitDtSgmEvt restitDtSgmEvt = new RestitDtSgmEvt();
			restitDtSgmEvt.setCodeSeg((String) lineAsArray[0]);
			restitDtSgmEvt.setNombreEvt(((Number) lineAsArray[1]).longValue());
			ret.add(restitDtSgmEvt);
		}
		return ret;
	}

}
