package fr.bpce.yyd.batch.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

@Service
public class SpringBeanUtil implements ApplicationContextAware {

	private static ApplicationContext context;

	@Override
	public synchronized void setApplicationContext(ApplicationContext applicationContext) {
		SpringBeanUtil.context = applicationContext;

	}

	public static <T> T getBean(Class<T> beanClass) {
		if (context == null) {
			return null;
		}
		return context.getBean(beanClass);

	}

}
