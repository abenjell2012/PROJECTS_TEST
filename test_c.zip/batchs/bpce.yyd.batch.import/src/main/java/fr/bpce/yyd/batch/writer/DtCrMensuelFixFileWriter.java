package fr.bpce.yyd.batch.writer;

import static fr.bpce.yyd.batch.enums.TypeFichierRestit.DTCRMENSUELFIX;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.core.io.FileSystemResource;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import fr.bpce.yyd.batch.beans.ImportBean;
import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.util.RestitImportUtil;

public class DtCrMensuelFixFileWriter extends FlatFileItemWriter<ImportBean> implements FlatFileHeaderCallback {

	public static final String NOM_FIC_CR_MENSUEL = "NOM_FIC_CR_MENSUEL";
	public static final String NB_LIGNES_FIC_CR_MENSUEL = "NB_LIGNES_FIC_CR_MENSUEL";
	private static final String NB_LIGNES_INS = "NB_LIGNES_INS";
	private NdodFile ndodeFile;
	private String repCrsMensuels;
	private StepExecution stepExecution;
	private String cheminFichierGen;

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(ndodeFile, "ndodeFile must not be null");
		Assert.notNull(repCrsMensuels, "repCrsMensuels must not be null");
		String nomFichierGenere = DTCRMENSUELFIX.getNomFichier(ndodeFile.getFile().getName(), ndodeFile.getCodBq(),
				ndodeFile.getEnvironnement(),
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")));
		cheminFichierGen = repCrsMensuels + nomFichierGenere;
		super.setResource(new FileSystemResource(new File(cheminFichierGen)));
		super.setLineAggregator(e -> e.toRestitFixedLine(false));
		super.afterPropertiesSet();

	}

	@Override
	public void write(List<? extends ImportBean> items) throws Exception {
		if (!CollectionUtils.isEmpty(items)) {
			List<ImportBean> filtreditems = items.stream()
					.filter(bean -> !ImportBean.IGNORE.equals(bean.toRestitFixedLine(false)))
					.collect(Collectors.toList());
			super.write(filtreditems);
			Long nbLignesCourant = (Long) this.stepExecution.getExecutionContext().get(NB_LIGNES_INS);
			this.stepExecution.getExecutionContext().put(NB_LIGNES_INS, nbLignesCourant + filtreditems.size());
		}

	}

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		stepExecution.getExecutionContext().put(NB_LIGNES_INS, 0L);
		this.stepExecution = stepExecution;

	}

	@AfterStep
	public ExitStatus afterStep(StepExecution stepExecution) {
		stepExecution.getJobExecution().getExecutionContext().put(NOM_FIC_CR_MENSUEL, cheminFichierGen);
		Long nbLignesInseres = (Long) this.stepExecution.getExecutionContext().get(NB_LIGNES_INS);
		stepExecution.getJobExecution().getExecutionContext().put(NB_LIGNES_FIC_CR_MENSUEL, nbLignesInseres);
		return stepExecution.getExitStatus();
	}

	@Override
	public void writeHeader(Writer writer) throws IOException {
		writer.write(RestitImportUtil.generateEnteteFic(ndodeFile.getAuditFichier().getNomFichier(),
				ndodeFile.getAuditFichier().getDateAudit(), ndodeFile.getJobExecutionId()));
	}

	public void setNdodeFile(NdodFile ndodeFile) {
		this.ndodeFile = ndodeFile;
	}

	public void setRepCrsMensuels(String repCrsMensuels) {
		this.repCrsMensuels = repCrsMensuels;
	}

}
