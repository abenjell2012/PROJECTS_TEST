package fr.bpce.yyd.batch.beans;

import static fr.bpce.yyd.batch.util.RestitImportUtil.convertToFixedLength;
import static fr.bpce.yyd.commun.constantes.Constant.SEP_POINT_VIRGULE;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils;
import fr.bpce.yyd.commun.enums.StatutEvenement;

public class ImportBean {

	public static final String IGNORE = "IGNORE";
	// donnes flux
	private LocalDate datePhoto;
	private String codeBanque;
	private String idTiersLocal;
	private String siren;
	private String segmentRisque;
	private String idEvenementLocal;
	private String codeEvenement;
	private String ssCodeEvenement;
	private LocalDate dateDebEvenement;
	private LocalDate dateMajEvenement;
	private StatutEvenement statutEvenement;
	private BigDecimal montantArriere;
	private String numContrat;
	private String commentaire;
	private Boolean arriereTechnique;
	private Boolean arriereLitige;
	private Long nombreOccurenceIdentite;
	private Long nombreOccurenceEvenement;
	private Long nombreOccurenceComplement;

	// donnees identite existante
	private Long idIdentiteCourante;
	private String codeSegCourant;
	private String sirenCourant;

	// donnees evnement existant
	private Long idEvenementCourant;
	private Long idIdentiteInitiale;

	// donnees complement courant
	private Long idComplCourant;

	// donnees complement precedent
	private Long idComplPrecedent;

	// donnees complement suivant
	private Long idComplSuivant;

	// donnes id tiers de identite courant
	private Long idTiersCourant;

	private boolean isNouveauEvenememt = false;
	private boolean complementDejaExistant = false;
	private boolean isMajIdentite = false;

	private String origContagion;

	public LocalDate getDatePhoto() {
		return datePhoto;
	}

	public void setDatePhoto(LocalDate datePhoto) {
		this.datePhoto = datePhoto;
	}

	public String getCodeBanque() {
		return codeBanque;
	}

	public void setCodeBanque(String codeBanque) {
		this.codeBanque = codeBanque;
	}

	public String getIdTiersLocal() {
		return idTiersLocal;
	}

	public void setIdTiersLocal(String idTiersLocal) {
		this.idTiersLocal = idTiersLocal;
	}

	public String getSiren() {
		return siren;
	}

	public void setSiren(String siren) {
		this.siren = siren;
	}

	public String getSegmentRisque() {
		return segmentRisque;
	}

	public void setSegmentRisque(String segmentRisque) {
		this.segmentRisque = segmentRisque;
	}

	public String getIdEvenementLocal() {
		return idEvenementLocal;
	}

	public void setIdEvenementLocal(String idEvenementLocal) {
		this.idEvenementLocal = idEvenementLocal;
	}

	public String getCodeEvenement() {
		return codeEvenement;
	}

	public void setCodeEvenement(String codeEvenement) {
		this.codeEvenement = codeEvenement;
	}

	public String getSsCodeEvenement() {
		return ssCodeEvenement;
	}

	public void setSsCodeEvenement(String ssCodeEvenement) {
		this.ssCodeEvenement = ssCodeEvenement;
	}

	public LocalDate getDateDebEvenement() {
		return dateDebEvenement;
	}

	public void setDateDebEvenement(LocalDate dateDebEvenement) {
		this.dateDebEvenement = dateDebEvenement;
	}

	public LocalDate getDateMajEvenement() {
		return dateMajEvenement;
	}

	public void setDateMajEvenement(LocalDate dateMajEvenement) {
		this.dateMajEvenement = dateMajEvenement;
	}

	public StatutEvenement getStatutEvenement() {
		return statutEvenement;
	}

	public void setStatutEvenement(StatutEvenement statutEvenement) {
		this.statutEvenement = statutEvenement;
	}

	public BigDecimal getMontantArriere() {
		return montantArriere;
	}

	public void setMontantArriere(BigDecimal montantArriere) {
		this.montantArriere = montantArriere;
	}

	public String getNumContrat() {
		return numContrat;
	}

	public void setNumContrat(String numContrat) {
		this.numContrat = numContrat;
	}

	public String getCommentaire() {
		return commentaire;
	}

	public void setCommentaire(String commentaire) {
		this.commentaire = commentaire;
	}

	public Boolean getArriereTechnique() {
		return arriereTechnique;
	}

	public void setArriereTechnique(Boolean arriereTechnique) {
		this.arriereTechnique = arriereTechnique;
	}

	public Boolean getArriereLitige() {
		return arriereLitige;
	}

	public void setArriereLitige(Boolean arriereLitige) {
		this.arriereLitige = arriereLitige;
	}

	public Long getIdIdentiteCourante() {
		return idIdentiteCourante;
	}

	public void setIdIdentiteCourante(Long idIdentiteCourante) {
		this.idIdentiteCourante = idIdentiteCourante;
	}

	public String getCodeSegCourant() {
		return codeSegCourant;
	}

	public void setCodeSegCourant(String codeSegCourant) {
		this.codeSegCourant = codeSegCourant;
	}

	public String getSirenCourant() {
		return sirenCourant;
	}

	public void setSirenCourant(String sirenCourant) {
		this.sirenCourant = sirenCourant;
	}

	public Long getIdEvenementCourant() {
		return idEvenementCourant;
	}

	public void setIdEvenementCourant(Long idEvenementCourant) {
		this.idEvenementCourant = idEvenementCourant;
	}

	public Long getIdComplCourant() {
		return idComplCourant;
	}

	public void setIdComplCourant(Long idComplCourant) {
		this.idComplCourant = idComplCourant;
	}

	public Long getIdComplPrecedent() {
		return idComplPrecedent;
	}

	public void setIdComplPrecedent(Long idComplPrecedent) {
		this.idComplPrecedent = idComplPrecedent;
	}

	public Long getIdComplSuivant() {
		return idComplSuivant;
	}

	public void setIdComplSuivant(Long idComplSuivant) {
		this.idComplSuivant = idComplSuivant;
	}

	public boolean isNouveauEvenememt() {
		return isNouveauEvenememt;
	}

	public void setNouveauEvenememt(boolean isNouveauEvenememt) {
		this.isNouveauEvenememt = isNouveauEvenememt;
	}

	public void setIdTiersCourant(Long idTiersIdentiteCourant) {
		this.idTiersCourant = idTiersIdentiteCourant;
	}

	public Long getIdTiersCourant() {
		return idTiersCourant;
	}

	public Long getNombreOccurenceIdentite() {
		return nombreOccurenceIdentite;
	}

	public void setNombreOccurenceIdentite(Long nombreOccurenceIdentite) {
		this.nombreOccurenceIdentite = nombreOccurenceIdentite;
	}

	public Long getNombreOccurenceEvenement() {
		return nombreOccurenceEvenement;
	}

	public void setNombreOccurenceEvenement(Long nombreOccurenceEvenement) {
		this.nombreOccurenceEvenement = nombreOccurenceEvenement;
	}

	public boolean isComplementDejaExistant() {
		return complementDejaExistant;
	}

	public void setComplementDejaExistant(boolean complementDejaExistant) {
		this.complementDejaExistant = complementDejaExistant;
	}

	public Long getNombreOccurenceComplement() {
		return nombreOccurenceComplement;
	}

	public void setNombreOccurenceComplement(Long nombreOccurenceComplement) {
		this.nombreOccurenceComplement = nombreOccurenceComplement;
	}

	public String toRestitCsvLine() {
		StringBuilder lineCsvBuilder = new StringBuilder(codeBanque);
		lineCsvBuilder.append(SEP_POINT_VIRGULE).append(idTiersLocal).append(SEP_POINT_VIRGULE).append(idEvenementLocal)
				.append(SEP_POINT_VIRGULE).append(codeEvenement).append(SEP_POINT_VIRGULE)
				.append(statutEvenement.name()).append(SEP_POINT_VIRGULE).append(numContrat);
		return lineCsvBuilder.toString();

	}

	public String toRestitFixedLine(boolean evtActNotFull) {

		String typeLigne = "";
		if (evtActNotFull) {
			typeLigne = "ACTIVE";
		} else if (isNouveauEvenememt()) {
			typeLigne = "INSERT";
		} else if ((!isNouveauEvenememt() //
				&& (isMajIdentite() || !isComplementDejaExistant()))) {
			typeLigne = "UPDATE";
		} else {
			return IGNORE;
		}

		String dateVide = "        ";
		String flagTech = Boolean.TRUE.equals(arriereTechnique) ? "O" : "N";
		String flagLit = Boolean.TRUE.equals(arriereLitige) ? "O" : "N";
		String dateMaj = dateMajEvenement != null ? dateMajEvenement.format(DateTimeFormatter.BASIC_ISO_DATE)
				: dateVide;
		String commentaireStr = convertToFixedLength(commentaire, 200);
		String mttArr = "+" + RestitSyntheseUtils.convertToFixedLength(montantArriere, 17);
		String statutEvt = convertToFixedLength(statutEvenement.name(), 3);
		String datePhotoStr = datePhoto != null ? datePhoto.format(DateTimeFormatter.BASIC_ISO_DATE) : dateVide;
		String codeBq = codeBanque;
		String dateDebutEvt = dateDebEvenement != null ? dateDebEvenement.format(DateTimeFormatter.BASIC_ISO_DATE)
				: dateVide;
		String codeEvt = convertToFixedLength(codeEvenement, 3);
		String typeEvt = convertToFixedLength(ssCodeEvenement, 4);
		String sirStr = convertToFixedLength(siren, 9);
		String idTiersLoc = convertToFixedLength(idTiersLocal, 50);
		String codeSeg = convertToFixedLength(segmentRisque, 4);
		String idContrat = convertToFixedLength(numContrat, 50);
		String idEvtLoc = convertToFixedLength(idEvenementLocal, 30);

		StringBuilder line = new StringBuilder(typeLigne + datePhotoStr);
		line.append(codeBq).append(idTiersLoc).append(sirStr).append(codeSeg).append(idEvtLoc).append(codeEvt)
				.append(typeEvt).append(dateDebutEvt).append(dateMaj).append(statutEvt).append(mttArr).append(idContrat)
				.append(commentaireStr).append(flagTech).append(flagLit);
		return line.toString();

	}

	public Long getIdIdentiteInitiale() {
		return idIdentiteInitiale;
	}

	public void setIdIdentiteInitiale(Long idIdentiteInitiale) {
		this.idIdentiteInitiale = idIdentiteInitiale;
	}

	public boolean isMajIdentite() {
		return isMajIdentite;
	}

	public void setMajIdentite(boolean isMajIdentite) {
		this.isMajIdentite = isMajIdentite;
	}

	public String getOrigContagion() {
		return origContagion;
	}

	public void setOrigContagion(String origContagion) {
		this.origContagion = origContagion;
	}
}
