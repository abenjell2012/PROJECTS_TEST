package fr.bpce.yyd.batch.task;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

import fr.bpce.yyd.batch.beans.NdodFile;

public class FileTypeDecider implements JobExecutionDecider {

	private NdodFile ndodFile;

	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {
		if (ndodFile.isMensuelFile()) {
			return new FlowExecutionStatus("MENSUEL");
		}
		return new FlowExecutionStatus(jobExecution.getExitStatus().toString());
	}

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}

}
