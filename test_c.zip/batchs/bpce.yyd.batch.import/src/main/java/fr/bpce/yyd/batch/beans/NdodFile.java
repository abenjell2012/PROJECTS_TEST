package fr.bpce.yyd.batch.beans;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.commun.model.AuditFichiers;

public class NdodFile {

	public static final Integer FICHIER_VIDE = -2;
	public static final Integer ERREUR_LECTURE = -3;

	private static final String DATE_HEURE_FICHIER = "ddMMyyyy-HHmmss";
	private static final Pattern PATTERN_EVT_FILE = Pattern.compile(Constant.REG_NDOD_EVT_FILE);
	private static final Pattern PATTERN_INIT_EVT_FILE = Pattern.compile(Constant.REG_NDOD_EVT_INIT_FILE);
	private static final Pattern PATTERN_MENSUEL_EVT_FILE = Pattern.compile(Constant.REG_NDOD_EVT_MENSUEL_FILE);
	private static final Pattern PATTERN_CONTAGION_EVT_FILE = Pattern.compile(Constant.REG_NDOD_EVT_CONTAGION_FILE);

	private static final Logger LOGGER = Logger.getLogger(NdodFile.class);

	private File file = null;
	private String codBq = null;
	private Date dateAudit = null;
	private boolean isValid;
	private Integer nbLines = null;
	private int nbLinesRejet = 0;
	private String ligneEntete = null;
	private String ligneEnqueue = null;
	private LocalDate dateConstitFlux;
	private AuditFichiers auditFichier;
	private Long jobExecutionId;
	private Set<Long> idsTiersATraiter = new HashSet<>();
	private Set<Long> idsTiersACloturer = new HashSet<>();
	private boolean aEnvoyer;
	private boolean isInitFile = false;
	private boolean isMensuelFile = false;
	private boolean isContagionFile = false;
	private Long idAuditFile;
	private String environnement;
	private LocalDate dateCalculCourante;
	private Set<String> codeBqsList = new HashSet<>();
	private Set<String> detailCodeBqsList = new HashSet<>();

	public void setFile(File file) {
		this.file = file;
		nbLines = null;
		nbLinesRejet = 0;
		auditFichier = null;
		dateConstitFlux = null;
		idsTiersATraiter.clear();

		Matcher matcherRegExpEvt = PATTERN_EVT_FILE.matcher(file.getName());
		Matcher matcherRegExpEvtInit = PATTERN_INIT_EVT_FILE.matcher(file.getName());
		Matcher matcherRegExpEvtMensuel = PATTERN_MENSUEL_EVT_FILE.matcher(file.getName());
		Matcher matcherRegExpEvtContagion = PATTERN_CONTAGION_EVT_FILE.matcher(file.getName());

		dateAudit = new Date();

		if (!matcherRegExpEvt.matches() && !matcherRegExpEvtInit.matches() && !matcherRegExpEvtMensuel.matches()
				&& !matcherRegExpEvtContagion.matches()) {
			codBq = Constant.CHAMP_EMPTY;
			environnement = Constant.CHAMP_EMPTY;
			isValid = false;

		} else {
			if (matcherRegExpEvtInit.matches()) {
				isInitFile = true;
				isMensuelFile = false;
				isContagionFile = false;
				calcInfoFromFileName(matcherRegExpEvtInit);

			} else if (matcherRegExpEvt.matches()) {
				isInitFile = false;
				isMensuelFile = false;
				isContagionFile = false;
				calcInfoFromFileName(matcherRegExpEvt);

			} else if (matcherRegExpEvtMensuel.matches()) {
				isInitFile = false;
				isMensuelFile = true;
				isContagionFile = false;
				calcInfoFromFileName(matcherRegExpEvtMensuel);
			} else if (matcherRegExpEvtContagion.matches()) {
				isInitFile = false;
				isMensuelFile = false;
				isContagionFile = true;
				calcInfoFromFileName(matcherRegExpEvtContagion);
			}

		}
	}

	private void calcInfoFromFileName(Matcher matcher) {
		codBq = matcher.group(2);
		environnement = matcher.group(3);
		isValid = isDateFormatValide(matcher.group(4));
	}

	private static boolean isDateFormatValide(String dateFichier) {
		try {
			new SimpleDateFormat("yyMMdd-HHmmss").parse(dateFichier);
		} catch (ParseException e) {
			return false;
		}
		return true;
	}

	private void initNbLigneEnteteEnqueue(File fichier) throws IOException {
		int nb = 0;
		FileReader fR = new FileReader(fichier);
		BufferedReader bR = new BufferedReader(fR);
		int nbLignesVide = 0;

		try {
			String line = bR.readLine();
			if (line != null) {
				nb++;
				String lastLine = null;
				setLigneEntete(line);

				// Nombre total des lignes trouvées inclut entete et footer.
				while ((line = bR.readLine()) != null) {
					if (!line.trim().isEmpty()) {
						nb++;
						lastLine = line;
						if (line.length() > 36) {
							codeBqsList.add(line.substring(8, 13));
						}
					} else {
						nbLignesVide++;
						LOGGER.info("Ligne vide trouvée à la ligne " + (nb + nbLignesVide));
					}
				}
				setLigneEnqueue(lastLine);
			}
		} finally {
			bR.close();
		}
		// on enleve l'entete et l'enqueue dans le count
		nbLines = nb - 2;
	}

	@Override
	public String toString() {
		return file.getName();
	}

	public File getFile() {
		return file;
	}

	public String getCodBq() {
		return codBq;
	}

	public void setCodBq(String codBq) {
		this.codBq = codBq;
	}

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	public static String getDateHeureFichier() {
		return DATE_HEURE_FICHIER;
	}

	/**
	 * Retourne true si la lecture du fichier a provoqué une erreur.
	 *
	 * @return
	 */
	public boolean erreurDeLecture() {
		return ERREUR_LECTURE.equals(getNbLines());
	}

	/**
	 * Retourne true si le fichier ne contient aucune ligne.
	 *
	 * @return
	 */
	public boolean isFichierVide() {
		return FICHIER_VIDE.equals(getNbLines());
	}

	/**
	 * @return the nbLines
	 */
	public Integer getNbLines() {
		if (nbLines == null) {
			try {
				initNbLigneEnteteEnqueue(file);
			} catch (IOException e) {
				nbLines = ERREUR_LECTURE;
			}
		}
		return nbLines;
	}

	/**
	 * @return le nombre de lignes détail du fichier
	 */
	public Integer getNbLinesAudit() {
		return getNbLines() < 0 ? 0 : getNbLines();
	}

	/**
	 * @return the nbLinesRejet
	 */
	public Integer getNbLinesRejet() {
		return nbLinesRejet;
	}

	/**
	 * @return the nbLinesRejet incrémenté de 1.
	 */
	public Integer incrementeNbLinesRejet() {
		return ++nbLinesRejet;
	}

	/**
	 * @param nbLinesRejet the nbLinesRejet to set
	 */
	public void setNbLinesRejet(Integer nbLinesRejet) {
		this.nbLinesRejet = nbLinesRejet;
	}

	/**
	 * @return the ligneEntete
	 */
	public String getLigneEntete() {
		return ligneEntete;
	}

	/**
	 * @param ligneEntete the ligneEntete to set
	 */
	public void setLigneEntete(String ligneEntete) {
		this.ligneEntete = ligneEntete;
	}

	/**
	 * @return the ligneEnqueue
	 */
	public String getLigneEnqueue() {
		return ligneEnqueue;
	}

	/**
	 * @param ligneEnqueue the ligneEnqueue to set
	 */
	public void setLigneEnqueue(String ligneEnqueue) {
		this.ligneEnqueue = ligneEnqueue;
	}

	public LocalDate getDateConstitFlux() {
		return dateConstitFlux;
	}

	public void setDateConstitFlux(LocalDate dateConstitFlux) {
		this.dateConstitFlux = dateConstitFlux;
	}

	public AuditFichiers getAuditFichier() {
		return auditFichier;
	}

	public void setAuditFichier(AuditFichiers auditFichier) {
		this.auditFichier = auditFichier;
	}

	/**
	 * @return the dateAudit
	 */
	public Date getDateAudit() {
		return dateAudit;
	}

	/**
	 * @param dateAudit the dateAudit to set
	 */
	public void setDateAudit(Date dateAudit) {
		this.dateAudit = dateAudit;
	}

	public Long getJobExecutionId() {
		return jobExecutionId;
	}

	public void setJobExecutionId(Long jobExecutionId) {
		this.jobExecutionId = jobExecutionId;
	}

	/**
	 * Retourne l'ensemble des ID Tiers sur lesquels un événement aura été importé
	 * dans le fichier.
	 *
	 * @return
	 */
	public Set<Long> getIdsTiersATraiter() {
		return idsTiersATraiter;
	}

	public Set<Long> getIdsTiersACloturer() {
		return idsTiersACloturer;
	}

	/**
	 * Ajout d'un ID tiers à traiter.
	 *
	 * @param idTiers
	 * @return
	 */
	public boolean addIdTiersATraiter(Long idTiers) {
		return idTiers != null && idsTiersATraiter.add(idTiers);
	}

	public boolean addIdTiersACloturer(Long idTiers) {
		return idsTiersACloturer.add(idTiers);
	}

	public boolean isaEnvoyer() {
		return aEnvoyer;
	}

	public void setaEnvoyer(boolean aEnvoyer) {
		this.aEnvoyer = aEnvoyer;
	}

	public boolean isInitFile() {
		return isInitFile;
	}

	public void setInitFile(boolean isInitFile) {
		this.isInitFile = isInitFile;
	}

	public Long getIdAuditFile() {
		return idAuditFile;
	}

	public void setIdAuditFile(Long idAuditFile) {
		this.idAuditFile = idAuditFile;
	}

	public String getEnvironnement() {
		return environnement;
	}

	public boolean isMensuelFile() {
		return isMensuelFile;
	}

	public void setMensuelFile(boolean isMensuelFile) {
		this.isMensuelFile = isMensuelFile;
	}

	public boolean isContagionFile() {
		return isContagionFile;
	}

	public void setContagionFile(boolean isContagionFile) {
		this.isContagionFile = isContagionFile;
	}

	public LocalDate getDatePhoto() {
		return getDateCalculCourante().plusDays(1);
	}

	/**
	 * @return the codeBqsList
	 */
	public Set<String> getCodeBqsList() {
		return codeBqsList;
	}

	public LocalDate getDateCalculCourante() {
		return dateCalculCourante;
	}

	public void setDateCalculCourante(LocalDate dateCalculCourante) {
		this.dateCalculCourante = dateCalculCourante;
	}

	public Set<String> getDetailCodeBqsList() {
		return detailCodeBqsList;
	}

	public void setDetailCodeBqsList(Set<String> detailCodeBqsList) {
		this.detailCodeBqsList = detailCodeBqsList;
	}

	public boolean addCodeBqDetail(String codeBanque) {
		return codeBanque != null && detailCodeBqsList.add(codeBanque);
	}
}
