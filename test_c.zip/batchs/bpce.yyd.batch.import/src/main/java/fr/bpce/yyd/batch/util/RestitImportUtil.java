package fr.bpce.yyd.batch.util;

import static fr.bpce.yyd.batch.commun.constantes.Constant.CHAR_ESPACE;
import static fr.bpce.yyd.batch.commun.constantes.Constant.CHAR_ZERO;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class RestitImportUtil {

	private RestitImportUtil() {
		// empty constructor
	}

	public static String convertToFixedLength(String str, int taille) {
		if (str == null) {
			return StringUtils.rightPad("", taille, CHAR_ESPACE);
		}
		return StringUtils.rightPad(str, taille, CHAR_ESPACE);
	}

	public static String convertIntToFixedLength(int value, int taille) {
		return StringUtils.leftPad(Integer.toString(value), taille, CHAR_ZERO);
	}

	public static String convertLongToFixedLength(Long value, int taille) {
		return StringUtils.leftPad(String.valueOf(value), taille, CHAR_ZERO);
	}

	public static String generateEnqueueFic(String codeBanque, Date dateAudit, Long nbLignes) {

		StringBuilder enqueueBuilder = new StringBuilder();
		enqueueBuilder.append("*9");
		enqueueBuilder.append(new SimpleDateFormat("yyyyMMdd").format(dateAudit));
		enqueueBuilder.append(codeBanque);
		enqueueBuilder.append("MDC");
		enqueueBuilder.append("001+");
		enqueueBuilder.append(convertLongToFixedLength(nbLignes, 14));
		return enqueueBuilder.toString();
	}

	public static String generateEnteteFic(String nomFichier, Date dateAudit, Long jobId) {

		StringBuilder enteteBuilder = new StringBuilder();
		enteteBuilder.append("*1");
		enteteBuilder.append(convertToFixedLength(nomFichier, 50));
		enteteBuilder.append(new SimpleDateFormat("yyyyMMdd").format(dateAudit));
		enteteBuilder.append("+" + convertLongToFixedLength(jobId, 18));
		enteteBuilder.append("MDC");
		enteteBuilder.append("001");

		return enteteBuilder.toString();
	}

}
