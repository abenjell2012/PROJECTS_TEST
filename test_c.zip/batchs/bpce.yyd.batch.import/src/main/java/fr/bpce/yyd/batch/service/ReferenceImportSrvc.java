package fr.bpce.yyd.batch.service;

import java.util.List;
import java.util.Map;

import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.reference.RefEvtNdod;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.model.reference.RefSsCodEvt;

public interface ReferenceImportSrvc {

	List<String> getCodBqReferenceList();

	List<RefEvtNdod> getCodEvtSirReferenceList();

	Map<String, List<RefSsCodEvt>> getSousCodeEvtReferenceMap();

	List<RefCliSeg> getCodSegReferenceList();

	List<RefCliSsClass> getRefCliSousClassList();

	List<RefImpactEvtMdc> getRefImpactEvtMdcList();

	List<RefEvtNdod> getCodEvtRmnReferenceList();

}
