package fr.bpce.yyd.batch.beans;

import static fr.bpce.yyd.batch.commun.constantes.Constant.SEP_POINT_VIRGULE;

import java.math.BigDecimal;

import org.apache.commons.text.StringEscapeUtils;

public class RestitDtStEvt {

	private String codeEvt;
	private String statutEvt;
	private Long nombreEvt;
	private BigDecimal sommeMntArriere;

	public String getCodeEvt() {
		return codeEvt;
	}

	public void setCodeEvt(String codeEvt) {
		this.codeEvt = codeEvt;
	}

	public String getStatutEvt() {
		return statutEvt;
	}

	public void setStatutEvt(String statutEvt) {
		this.statutEvt = statutEvt;
	}

	public Long getNombreEvt() {
		return nombreEvt;
	}

	public void setNombreEvt(Long nombreEvt) {
		this.nombreEvt = nombreEvt;
	}

	public BigDecimal getSommeMntArriere() {
		return sommeMntArriere;
	}

	public void setSommeMntArriere(BigDecimal sommeMntArriere) {
		this.sommeMntArriere = sommeMntArriere;
	}

	public String toRestitCsvLine() {
		StringBuilder lineCsvBuilder = new StringBuilder(codeEvt);
		lineCsvBuilder.append(SEP_POINT_VIRGULE).append(statutEvt).append(SEP_POINT_VIRGULE)
				.append(nombreEvt.toString()).append(SEP_POINT_VIRGULE).append(sommeMntArriere.toPlainString());
		return StringEscapeUtils.escapeHtml4(lineCsvBuilder.toString());
	}

}
