package fr.bpce.yyd.batch.task;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;

public class DecompressionFichierTask implements Tasklet {

	public static final String FICHIER_DEZIPE = "fichierDezipe";
	private static final Logger LOGGER = Logger.getLogger(DecompressionFichierTask.class);

	private String fichier;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
		String extension = FileCommunUtils.getExtension(fichier);
		String fichierDezipe;
		if (Constant.EXT_GZ.equalsIgnoreCase(extension)) {
			LOGGER.info("Début décompression du fichier .gz/.GZ: " + fichier);
			fichierDezipe = uncompressFile(fichier, extension);

		} else if (Constant.EXT_ZIP.equalsIgnoreCase(extension)) {
			LOGGER.info("Début décompression du fichier .zip: " + fichier);
			fichierDezipe = unZIPFile(fichier);

		} else {
			fichierDezipe = fichier;
		}

		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(FICHIER_DEZIPE,
				fichierDezipe);

		return RepeatStatus.FINISHED;
	}

	protected String uncompressFile(String filename, String extension) {
		String filePath = filename.replace("." + extension, "");
		unGZFile(filename, filePath);
		return filePath;
	}

	protected void unGZFile(String zip, String file) {
		byte[] buffer = new byte[2048];
		try (GZIPInputStream gzis = new GZIPInputStream(new FileInputStream(zip));
				FileOutputStream out = new FileOutputStream(file)) {
			int len;
			while ((len = gzis.read(buffer)) > 0) {
				out.write(buffer, 0, len);
			}

		} catch (IOException ex) {
			LOGGER.warn(ex.getMessage(), ex);
		}
	}

	protected String unZIPFile(String filename) {
		byte[] buffer = new byte[2048];
		String outputFileName = null;

		try (ZipFile zipFile = new ZipFile(filename)) {
			Enumeration<? extends ZipEntry> entries = zipFile.entries();

			if (entries.hasMoreElements()) {
				ZipEntry entry = entries.nextElement();
				InputStream stream = zipFile.getInputStream(entry);
				outputFileName = buildOutputFilename(filename, entry.getName());
				try (FileOutputStream csvOut = new FileOutputStream(outputFileName)) {

					int sizeRead;
					while ((sizeRead = stream.read(buffer, 0, buffer.length)) > 0) {
						csvOut.write(buffer, 0, sizeRead);
					}
					stream.close();
				}
			}

			if (outputFileName != null) {
				return outputFileName;
			}
		} catch (IOException ex) {
			throw new IllegalArgumentException("Erreur en décompression du fichier " + filename, ex);
		}

		throw new IllegalArgumentException("Le fichier " + filename + " est vide.");
	}

	protected String buildOutputFilename(String zipFilename, String entryName) {
		Path path = Paths.get(new File(zipFilename).toURI());
		return path.getParent().toString() + File.separatorChar + entryName;
	}

	public void setFichier(String fichier) {
		this.fichier = fichier;
	}

}
