package fr.bpce.yyd.batch.mapper;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

import fr.bpce.yyd.batch.beans.NdodFile;

public class ParameterSetter implements PreparedStatementSetter {

	private NdodFile ndodeFile;

	public void setNdodeFile(NdodFile ndodeFile) {
		this.ndodeFile = ndodeFile;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		for (int i = 1; i < 5; i++) {
			ps.setString(i, ndodeFile.getCodBq());
		}
	}
}
