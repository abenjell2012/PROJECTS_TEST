package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.BeforeClass;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.service.impl.FunctionnalCheckerSrvcImpl;
import fr.bpce.yyd.batch.service.impl.ReferenceImportSrvcImpl;
import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.EvtExistMdcNotFull;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ImportEvenementSir;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefEvtNdod;
import fr.bpce.yyd.commun.model.reference.RefSsCodEvt;

public abstract class AbstractIntegrationTest {

	public static final String TEST_FILES_FOLDER_NAME = "./src/test/resources/ti/fichiers/";

	public static final String TEST_RESTIT_FOLDER_NAME = "./src/test/resources/ti/out/COLLECTE/";

	@FunctionalInterface
	public interface TransactionCallback {
		void doInTransaction();
	}

	private static ApplicationContext context = null;
	private static TransactionTemplate transactionTemplate = null;

	@BeforeClass
	public static void initSpring() {
		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		transactionTemplate = new TransactionTemplate(getTransactionManager());
		initDataReference();
	}

	private static void initDataReference() {
		// initialiser les données statiques
		ReferenceImportSrvcImpl referenceSrvc = context.getBean(ReferenceImportSrvcImpl.class);
		referenceSrvc.setCodbqList(Arrays.asList("10107", "10807", "12128", "17515", "11138", "30007", "99999","11315"));

		RefEvtNdod refEvt1 = new RefEvtNdod();
		refEvt1.setCodEvt("DAX");
		refEvt1.setDateDebut(LocalDate.of(2018, 06, 01));

		RefEvtNdod refEvt2 = new RefEvtNdod();
		refEvt2.setCodEvt("IMX");
		refEvt2.setDateDebut(LocalDate.of(2018, 06, 01));

		RefEvtNdod refEvt3 = new RefEvtNdod();
		refEvt3.setCodEvt("F");
		refEvt3.setDateDebut(LocalDate.of(2018, 06, 01));

		RefEvtNdod refEvt4 = new RefEvtNdod();
		refEvt4.setCodEvt("CAD");
		refEvt4.setDateDebut(LocalDate.of(2018, 06, 01));

		RefEvtNdod refEvt5 = new RefEvtNdod();
		refEvt5.setCodEvt("CMA");
		refEvt5.setDateDebut(LocalDate.of(2018, 06, 01));

		RefEvtNdod refEvt6 = new RefEvtNdod();
		refEvt6.setCodEvt("CMD");
		refEvt6.setDateDebut(LocalDate.of(2018, 06, 01));

		RefEvtNdod refEvt7 = new RefEvtNdod();
		refEvt7.setCodEvt("DM");
		refEvt7.setDateDebut(LocalDate.of(2018, 06, 01));

		RefEvtNdod refEvt8 = new RefEvtNdod();
		refEvt8.setCodEvt("AM");
		refEvt8.setDateDebut(LocalDate.of(2018, 06, 01));

		RefEvtNdod refEvt9 = new RefEvtNdod();
		refEvt9.setCodEvt("PCO");
		refEvt9.setDateDebut(LocalDate.of(2018, 06, 01));

		referenceSrvc.setCodEvtList(Arrays.asList(refEvt1, refEvt2, refEvt3, refEvt4, refEvt5, refEvt6, refEvt7,refEvt8,refEvt9));

		Map<String, List<RefSsCodEvt>> ssCodEvtMap = new HashMap<String, List<RefSsCodEvt>>();
		RefSsCodEvt refSs1 = new RefSsCodEvt("DM", "DM00", "autres UTP", LocalDate.of(2018, 06, 01));
		RefSsCodEvt refSs2 = new RefSsCodEvt("DM", "DM01", "Procédure amiable", LocalDate.of(2018, 06, 01));
		RefSsCodEvt refSs3 = new RefSsCodEvt("DM", "DM02", "Information externe préoccupante",
				LocalDate.of(2018, 06, 01));
		RefSsCodEvt refSs4 = new RefSsCodEvt("DM", "DM03", "Cas de Fraude", LocalDate.of(2018, 06, 01));
		RefSsCodEvt refSs5 = new RefSsCodEvt("DM", "DM04", "Contagion", LocalDate.of(2018, 06, 01));
		RefSsCodEvt refSs6 = new RefSsCodEvt("DM", "DM05", "Mise en jeu d'une garantie reçue",
				LocalDate.of(2018, 06, 01));
		RefSsCodEvt refSs7 = new RefSsCodEvt("DM", "DM06", "Difficultés financières et/ou  perspectives préoccupantes",
				LocalDate.of(2018, 06, 01));
		ssCodEvtMap.put("DM", Arrays.asList(refSs1, refSs2, refSs3, refSs4, refSs5, refSs6, refSs7));
		referenceSrvc.setSsCodEvtMap(ssCodEvtMap);
		RefCliSeg ref1 = new RefCliSeg("1234", "libelle1", "");
		RefCliSeg ref2 = new RefCliSeg("1010", "libelle2", "CO1010");
		RefCliSeg ref3 = new RefCliSeg("3210", "libelle3", "");
		RefCliSeg ref4 = new RefCliSeg("2030", "libelle4", "");
		RefCliSeg ref5 = new RefCliSeg("3130", "libelle5", "");
		RefCliSeg ref6 = new RefCliSeg("1100", "libelle6", "COR010");
		RefCliSeg ref7 = new RefCliSeg("3110", "libelle7", "");
		RefCliSeg ref8 = new RefCliSeg("2010", "libelle8", "");
		RefCliSeg ref9 = new RefCliSeg("2030", "libelle9", "");
		RefCliSeg ref10 = new RefCliSeg("1020", "libelle10", "");
		RefCliSeg ref11 = new RefCliSeg("3120", "libelle11", "RETPRO");
		RefCliSeg ref12 = new RefCliSeg("3200", "libelle11", "RETCFF");
		referenceSrvc
				.setRefSegmentList(Arrays.asList(ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, ref10, ref11,ref12));

	}

	protected void insertDateCalculCourante(LocalDate dateParam) {

		ParMdcSeg paramDateCalculCourante = new ParMdcSeg();
		paramDateCalculCourante.setCodeParam(CodeParamMdc.DATE_CALCUL_COURANTE);
		paramDateCalculCourante.setCodeSegment("*");
		paramDateCalculCourante.setDateDebut(LocalDate.of(2019, 01, 01));
		paramDateCalculCourante.setValeurParam(dateParam.format(DateTimeFormatter.BASIC_ISO_DATE));
		getEntityManager().persist(paramDateCalculCourante);
	}

	public static ApplicationContext getContext() {
		return context;
	}

	/**
	 * Import d'un fichier dans le dossier par défaut des TI
	 *
	 * @param filename
	 */
	public BatchStatus importFile(String filename) {
		return importFile(TEST_FILES_FOLDER_NAME, filename);
	}

	/**
	 * Import d'un fichier se situant dans un dossier précisé.
	 *
	 * @param folder
	 * @param filename
	 */
	public BatchStatus importFile(String folder, String filename) {
		Job job = (Job) context.getBean(Constant.JOB_IMPORT_EVT);
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		JobParameters jobParameters = new JobParametersBuilder().addString("file", folder + filename)
				.addString("date", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
				.addString("repRestitOut", TEST_RESTIT_FOLDER_NAME).addString("repRejets", TEST_RESTIT_FOLDER_NAME)
				.addString("repCrsMensuels", TEST_RESTIT_FOLDER_NAME).addString("kafka", "disable")
				.addLong("guid", guid).toJobParameters();

		try {
			JobExecution execution = jobLauncher.run(job, jobParameters);
			FunctionnalCheckerSrvcImpl FCServ = (FunctionnalCheckerSrvcImpl) context
					.getBean("functionnalCheckerSrvcImpl");
			FCServ.setListEvenementAnnule(null);
			return execution.getStatus();
		} catch (Exception e) {
			e.printStackTrace();
			return BatchStatus.UNKNOWN;
		}
	}

	public EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	public static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	/**
	 * Exécute la méthode check() du paramètre checker au sein d'une transaction.
	 * Utilisée pour les assertions d'après import. Elles doivent effectivement être
	 * exécutées au sein d'une transaction pour pouvoir parcourir les relations
	 * ayant un chargement à la demande (LAZY).
	 *
	 * @param checker
	 */
	public void doInTransaction(final TransactionCallback checker) {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				checker.doInTransaction();
			}
		});
	}

	private void deleteEntityData(Class<?> entityClass) {
		EntityManager entityManager = getEntityManager();
		Query delQuery = entityManager.createQuery("delete from " + entityClass.getSimpleName());
		delQuery.executeUpdate();
	}

	/**
	 * Entre chaque test, la base est entièrement vidée.
	 */
	@After
	public void resetData() {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				deleteEntityData(AuditLignesImport.class);
				deleteEntityData(ComplementEvenement.class);
				deleteEntityData(Evenement.class);
				deleteEntityData(IdentiteTiers.class);
				deleteEntityData(StatutHistorise.class);
				deleteEntityData(Tiers.class);
				deleteEntityData(AuditFichiers.class);
				deleteEntityData(TiersRFT.class);
				deleteEntityData(ImportEvenementSir.class);
				deleteEntityData(EvtExistMdcNotFull.class);
			}
		});
	}

	/**
	 * Utilitaire pour assertions : retourne l'instance d'AuditFichiers
	 * correspondant au nom de fichier paramètre.
	 *
	 * @param nomFichier
	 * @return
	 */
	public AuditFichiers findAuditFichierByNomFichier(String nomFichier) {
		EntityManager entityManager = getEntityManager();
		TypedQuery<AuditFichiers> query = entityManager
				.createQuery("select af from AuditFichiers af where af.nomFichier = :nomFichier", AuditFichiers.class);
		query.setParameter("nomFichier", nomFichier);
		return query.getSingleResult();
	}

	/**
	 * Utilitaire pour assertions : retourne l'ensemble des Tiers en base.
	 *
	 * @return
	 */
	public List<Tiers> findAllTiers() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<Tiers> query = entityManager.createQuery("select t from Tiers t", Tiers.class);
		return query.getResultList();
	}

	/**
	 * Utilitaire pour assertions : retourne l'ensemble des identite en base.
	 *
	 * @return
	 */
	public List<IdentiteTiers> findAllIdentites() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<IdentiteTiers> query = entityManager.createQuery("select t from IdentiteTiers t",
				IdentiteTiers.class);
		return query.getResultList();
	}

	/**
	 * Utilitaire pour assertions : retourne l'ensemble des evenements en base.
	 *
	 * @return
	 */
	public List<Evenement> findAllEvenements() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<Evenement> query = entityManager.createQuery("select t from Evenement t", Evenement.class);
		return query.getResultList();
	}

	/**
	 * Utilitaire pour assertions : retourne l'ensemble des ComplementEvenement en
	 * base.
	 *
	 * @return
	 */
	public List<ComplementEvenement> findAllComplementsEvenements() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<ComplementEvenement> query = entityManager.createQuery("select t from ComplementEvenement t",
				ComplementEvenement.class);
		return query.getResultList();
	}

	public List<Evenement> findEvenementByIdentiteTiers(Long idIdentiteTiers) {
		EntityManager entityManager = getEntityManager();
		TypedQuery<Evenement> query = entityManager.createQuery(
				"select t from Evenement t where t.identiteInitiale.id = :idIdentiteTiers", Evenement.class);
		query.setParameter("idIdentiteTiers", idIdentiteTiers);
		return query.getResultList();

	}

	/**
	 * Utilitaire pour assertions : retourne l'ensemble des lignes
	 * importEvenementSir en base.
	 *
	 * @return
	 */
	public List<ImportEvenementSir> findAllLignesImport() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<ImportEvenementSir> query = entityManager.createQuery("select t from ImportEvenementSir t",
				ImportEvenementSir.class);
		return query.getResultList();
	}
}
