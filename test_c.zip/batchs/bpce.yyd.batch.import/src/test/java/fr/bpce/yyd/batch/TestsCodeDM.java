package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;

public class TestsCodeDM extends AbstractIntegrationTest {

	@Before
	public void setUp() {
		doInTransaction(() -> {
			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
	}

	@Test
	public void testCodeEvenementDMSousCodeVide() {
		// code DM et sous code vide : on s'attend à un code rejet CT019
		String repertoire = "CODE_DM/";
		String nomFichier = "NDOD_EVT_DELTA_11138_PROD_210428-190000.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());

			// La ligne est rejeté
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT019, rejet.getCodeAudit());

			}
		});

	}

	@Test
	public void testCodeEvenementDMSousCodeDM10AbsentReferentiel() {
		// code DM et sous code DM10 absent du référentiel on s'attend à un code rejet
		// CT019
		String repertoire = "CODE_DM/";
		String nomFichier = "NDOD_EVT_DELTA_11138_PROD_210430-190000.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());

			// La ligne est rejeté
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT019, rejet.getCodeAudit());

			}
		});

	}

	@Test
	public void testCodeEvenementDMSousCodeValideDM04() {
		// code DM et sous code non vide DM04 dans le fichier on s'attend à aucun rejet
		// car présent
		// dans la liste des sous codes possibles
		String repertoire = "CODE_DM/";
		String nomFichier = "NDOD_EVT_DELTA_11138_PROD_210429-190000.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());

			// aucun rejet
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});

	}

}