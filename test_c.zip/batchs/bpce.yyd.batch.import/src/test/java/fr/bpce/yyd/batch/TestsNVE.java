package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;

public class TestsNVE extends AbstractIntegrationTest {

	@Before
	public void setUp() {
		doInTransaction(() -> {
			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
	}

	@Test
	public void testImportLigneOK() {
		// Act
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180000.txt";
		importFile(repertoire + nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Collection<IdentiteTiers> identites = tousTiers.get(0).getIdentites();
			for (IdentiteTiers identite : identites) {
				List<Evenement> listEvt = findEvenementByIdentiteTiers(identite.getId());
				Assert.assertEquals(1, listEvt.size());
				Assert.assertEquals("ID-TIERS-LOCAL-0001", identite.getIdLocal());
				for (Evenement evt : listEvt) {
					Collection<ComplementEvenement> complements = evt.getComplements();
					Assert.assertEquals(1, complements.size());
				}
			}

		});
	}

	@Test
	public void testCodeBanqueFormatInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180043.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT015, rejet.getCodeAudit());
			}
		});

	}

	@Test
	public void testDateEvenementInitialSupDatePhoto() {
		List<Controles> LIST_CONTROLE_CT036_CT038 = Arrays.asList(Controles.CT036, Controles.CT038);
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180010.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertTrue(LIST_CONTROLE_CT036_CT038.contains(rejet.getCodeAudit()));

			}
		});

	}

	@Test
	public void testSousCodeEvenementDMInvalideDansReferentiel() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180015.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT019, rejet.getCodeAudit());

			}
		});

	}

	@Test
	public void testCodeBanqueInvalideLigneDetailDansReferentiel() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180042.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CF001, rejet.getCodeAudit());
			}
		});
	}

	@Test
	public void testCodeEvenementStatutInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180013.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT020, rejet.getCodeAudit());

			}
		});

	}

	@Test
	public void testFichierVide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180016.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT003, fichier.getCodAudit());
			Assert.assertEquals(0, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testChampVide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180040.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT043, rejet.getCodeAudit());
			}
		});
	}

	@Test
	public void testNbLigneEnQueuNonEntier() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180019.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT011, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testNbLigneEnQueuNonConformeAuDetail() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180038.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT012, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testFichierNonReconnu() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180017.tx,";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT002, fichier.getCodAudit());
			Assert.assertEquals(0, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

//erreur
	@Test
	public void testEnTeteFichierFormatInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180018.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT005, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testFormatDateEnTeteInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180020.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT006, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testFormatEnTeteInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180021.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT039, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testFormatEnQueuInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180022.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT008, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testFormatDateEnQueuInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180023.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT009, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testLongueurEnQueuInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180024.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT040, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testFormatDatePhotoInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180025.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT013, rejet.getCodeAudit());
			}
		});
	}

	@Test
	public void testDatePhotoAnterieurDtEntCsttFlx() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180026.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT014, rejet.getCodeAudit());
			}
		});
	}

	@Test
	public void testSirenInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180027.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT017, rejet.getCodeAudit());
			}
		});
	}

	@Test
	public void testCodeEvenementInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180028.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT018, rejet.getCodeAudit());
			}

		});
	}

	@Test
	public void testFormatMontantArriereInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180029.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT022, rejet.getCodeAudit());
			}

		});
	}

	@Test
	public void testNumeroVersionInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180032.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT028, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

		});
	}

	// ?????????????????????????????????
	@Test
	public void testCodeApplicatifInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180033.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT029, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

		});
	}

	@Test
	public void testLongueurLigneInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180034.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT030, rejet.getCodeAudit());
			}

		});
	}

	@Test
	public void testIdentifiantContratVide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180030.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT023, rejet.getCodeAudit());
			}

		});
	}

	@Test
	public void testFormatArriereInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180035.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT033, rejet.getCodeAudit());
			}

		});
	}

	@Test
	public void testFlagArriereInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180036.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT034, rejet.getCodeAudit());

			}

		});
	}

	@Test
	public void testFlagLitigeInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180037.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT035, rejet.getCodeAudit());

			}

		});
	}

	// CODES BANQUES
	@Test
	public void testCodeBanqueNomFichierInvalideDansReferentiel() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_77777_RCT_190224-180001.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CF004, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});

	}

	@Test
	public void testCodeBanqueEnTeteInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180001.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT031, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	// probleme
	@Test
	public void testCodeBanqueEnQueuInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180002.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT032, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	// SEGMENTS

	@Test
	public void testCodeSegmentInvalideDansReferentiel() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180003.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CF005, rejet.getCodeAudit());
			}
		});

	}

	// erreur
	public void testCodeSegmentFormatInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180004.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT021, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());
		});
	}

	// EVENEMENTS

	@Test
	public void testCodeEvenementDateDebutInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180008.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT025, rejet.getCodeAudit());

			}
		});
	}

	@Test
	public void testCodeEvenementDateFormatInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180009.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT027, rejet.getCodeAudit());

			}
		});

	}

	@Test
	public void testDateEvenementMajSuperieurDatePhoto() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180007.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT037, rejet.getCodeAudit());

			}
		});
	}

	@Test
	public void testDateEvenementMajInferieurDateInitiale() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180011.txt";
		importFile(repertoire + nomFichier);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT038, rejet.getCodeAudit());

			}
		});
	}

	@Test
	public void testFormatDateDebutEvenementInvalide() {
		String repertoire = "NVE/";
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180006.txt";
		try {
			importFile(repertoire + nomFichier);
		} catch (Exception e) {
		}
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT025, rejet.getCodeAudit());
			}
		});
	}

}