package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ImportEvenementSir;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;

public class TestsIntegrationContagion extends AbstractIntegrationTest {

	// fichier avec un CAD CLO
	String nomFichierCADClo = "NDOD_EVT_CON_99999_RCT_190224-180002.txt";

	@Test
	public void fichier1LigneContagionCadOK() {

		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.DEFAUT);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<ImportEvenementSir> lignesImport = findAllLignesImport();
			Assert.assertEquals(1, lignesImport.size());

			List<Tiers> allTiers = findAllTiers();
			Assert.assertEquals(2, allTiers.size());

			List<IdentiteTiers> allIdentites = findAllIdentites();
			Assert.assertEquals(2, allIdentites.size());

			List<Evenement> allEvenements = findAllEvenements();
			Assert.assertEquals(1, allEvenements.size());
			Assert.assertEquals("CAD", allEvenements.get(0).getCode());

			List<ComplementEvenement> allComplementsEvenements = findAllComplementsEvenements();
			Assert.assertEquals(1, allComplementsEvenements.size());

		});
	}

	@Test
	public void fichier1LigneContagionCmdOK() {

		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.DEFAUT);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180004.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<ImportEvenementSir> lignesImport = findAllLignesImport();
			Assert.assertEquals(1, lignesImport.size());

			List<Tiers> allTiers = findAllTiers();
			Assert.assertEquals(2, allTiers.size());

			List<IdentiteTiers> allIdentites = findAllIdentites();
			Assert.assertEquals(2, allIdentites.size());

			List<Evenement> allEvenements = findAllEvenements();
			Assert.assertEquals(1, allEvenements.size());
			Assert.assertEquals("CMD", allEvenements.get(0).getCode());

			List<ComplementEvenement> allComplementsEvenements = findAllComplementsEvenements();
			Assert.assertEquals(1, allComplementsEvenements.size());

		});
	}

	@Test
	public void fichier1LigneContagionCmaOK() {

		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.DEFAUT);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180016.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<ImportEvenementSir> lignesImport = findAllLignesImport();
			Assert.assertEquals(1, lignesImport.size());

			List<Tiers> allTiers = findAllTiers();
			Assert.assertEquals(2, allTiers.size());

			List<IdentiteTiers> allIdentites = findAllIdentites();
			Assert.assertEquals(2, allIdentites.size());

			List<Evenement> allEvenements = findAllEvenements();
			Assert.assertEquals(1, allEvenements.size());
			Assert.assertEquals("CMA", allEvenements.get(0).getCode());

			List<ComplementEvenement> allComplementsEvenements = findAllComplementsEvenements();
			Assert.assertEquals(1, allComplementsEvenements.size());

		});
	}

	@Test
	public void testRejetCF012() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> lignesRejets = fichier.getLignes();
			Assert.assertEquals(1, lignesRejets.size());
			Assert.assertEquals(Controles.CF012, lignesRejets.iterator().next().getCodeAudit());
		});
	}

	@Test
	public void testRejetCF013() {

		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.SAIN);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> lignesRejets = fichier.getLignes();
			Assert.assertEquals(1, lignesRejets.size());
			Assert.assertEquals(Controles.CF013, lignesRejets.iterator().next().getCodeAudit());
		});
	}

	@Test
	public void testPassantCADCloSurTiersEnDefaut() {
		// chargement par fichier d'un evt CAD Clot sur un tiers en DEFAUT
		// la ligne se charge correctement aucun rejet attendu
		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.DEFAUT);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});

		// Act
		importFile(nomFichierCADClo);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichierCADClo);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<ImportEvenementSir> lignesImport = findAllLignesImport();
			Assert.assertEquals(1, lignesImport.size());

			List<Tiers> allTiers = findAllTiers();
			Assert.assertEquals(2, allTiers.size());

			List<IdentiteTiers> allIdentites = findAllIdentites();
			Assert.assertEquals(2, allIdentites.size());

			List<Evenement> allEvenements = findAllEvenements();
			Assert.assertEquals(1, allEvenements.size());
			Assert.assertEquals("CAD", allEvenements.get(0).getCode());

			List<ComplementEvenement> allComplementsEvenements = findAllComplementsEvenements();
			Assert.assertEquals(1, allComplementsEvenements.size());

		});
	}

	@Test
	public void testPassantCADCloSurTiersEnSain() {
		// chargement par fichier d'un evt CAD Clot sur un tiers en DEFAUT
		// la ligne se charge correctement aucun rejet attendu
		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			StatutHistorise statutSain = new StatutHistorise();
			statutSain.setTiers(tiersOrig);
			statutSain.setStatut(StatutTiers.SAIN);
			statutSain.setAnnule(false);
			statutSain.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutSain);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});

		// Act
		importFile(nomFichierCADClo);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichierCADClo);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<ImportEvenementSir> lignesImport = findAllLignesImport();
			Assert.assertEquals(1, lignesImport.size());

			List<Tiers> allTiers = findAllTiers();
			Assert.assertEquals(2, allTiers.size());

			List<IdentiteTiers> allIdentites = findAllIdentites();
			Assert.assertEquals(2, allIdentites.size());

			List<Evenement> allEvenements = findAllEvenements();
			Assert.assertEquals(1, allEvenements.size());
			Assert.assertEquals("CAD", allEvenements.get(0).getCode());

			List<ComplementEvenement> allComplementsEvenements = findAllComplementsEvenements();
			Assert.assertEquals(1, allComplementsEvenements.size());

		});
	}

	@Test
	public void testRejetValeurNonPassante() {

		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			TiersRFT tiersR1 = new TiersRFT();
			tiersR1.setIdFederal("idFederal");
			tiersR1.setIdLocal("idLocal");
			tiersR1.setCodeBanque("30007");
			tiersR1.setDate(LocalDate.now());
			getEntityManager().persist(tiersR1);

			TiersRFT tiersR2 = new TiersRFT();
			tiersR2.setIdFederal("idFederal");
			tiersR2.setIdLocal("idLocal2");
			tiersR2.setCodeBanque("30007");
			tiersR2.setDate(LocalDate.now());
			getEntityManager().persist(tiersR2);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.SAIN);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180001.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> lignesRejets = fichier.getLignes();
			Assert.assertEquals(1, lignesRejets.size());
			Assert.assertEquals(Controles.CF013, lignesRejets.iterator().next().getCodeAudit());
		});
	}

	@Test
	public void testOKMajStatut() {

		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			TiersRFT tiersR1 = new TiersRFT();
			tiersR1.setIdFederal("idFederal");
			tiersR1.setIdLocal("idLocal");
			tiersR1.setCodeBanque("30007");
			tiersR1.setDate(LocalDate.now());
			getEntityManager().persist(tiersR1);

			TiersRFT tiersR2 = new TiersRFT();
			tiersR2.setIdFederal("idFederal");
			tiersR2.setIdLocal("idLocal2");
			tiersR2.setCodeBanque("30007");
			tiersR2.setDate(LocalDate.now());
			getEntityManager().persist(tiersR2);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.SAIN);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});

		// Act
		importFile(nomFichierCADClo);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichierCADClo);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testKOSiren() {

		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setSiren("123456789");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			TiersRFT tiersR1 = new TiersRFT();
			tiersR1.setIdFederal("idFederal");
			tiersR1.setIdLocal("idLocal");
			tiersR1.setCodeBanque("30007");
			tiersR1.setSiren("123456789");
			tiersR1.setDate(LocalDate.now());
			getEntityManager().persist(tiersR1);

			TiersRFT tiersR2 = new TiersRFT();
			tiersR2.setIdFederal("idFederal");
			tiersR2.setIdLocal("idLocal2");
			tiersR2.setCodeBanque("30007");
			tiersR2.setSiren("123456789");
			tiersR2.setDate(LocalDate.now());
			getEntityManager().persist(tiersR2);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.DEFAUT);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180005.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testOKSiren() {

		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setSiren("123456700");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			TiersRFT tiersR1 = new TiersRFT();
			tiersR1.setIdFederal("idFederal");
			tiersR1.setIdLocal("idLocal");
			tiersR1.setCodeBanque("30007");
			tiersR1.setSiren("123456700");
			tiersR1.setDate(LocalDate.now());
			getEntityManager().persist(tiersR1);

			TiersRFT tiersR2 = new TiersRFT();
			tiersR2.setIdFederal("idFederal");
			tiersR2.setIdLocal("idLocal2");
			tiersR2.setCodeBanque("30007");
			tiersR2.setSiren("123456700");
			tiersR2.setDate(LocalDate.now());
			getEntityManager().persist(tiersR2);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.DEFAUT);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180005.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testNomFichier() {

		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			TiersRFT tiersR1 = new TiersRFT();
			tiersR1.setIdFederal("idFederal");
			tiersR1.setIdLocal("idLocal");
			tiersR1.setCodeBanque("30007");
			tiersR1.setDate(LocalDate.now());
			getEntityManager().persist(tiersR1);

			TiersRFT tiersR2 = new TiersRFT();
			tiersR2.setIdFederal("idFederal");
			tiersR2.setIdLocal("idLocal2");
			tiersR2.setCodeBanque("30007");
			tiersR2.setDate(LocalDate.now());
			getEntityManager().persist(tiersR2);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.SAIN);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});

		// Act
		String nomFichier = "NDOD_EVT_CAN_99999_RCT_190224-180004.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT002, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testEnteteCourt() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180006.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT039, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testEnteteLong() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180007.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT039, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testEnqueuCourt() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180008.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT040, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testEnqueuLong() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180009.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT040, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testVide() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180010.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT003, fichier.getCodAudit());
			Assert.assertEquals(0, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testCorpsLong() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180011.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> lignesRejets = fichier.getLignes();
			Assert.assertEquals(1, lignesRejets.size());
			Assert.assertEquals(Controles.CT030, lignesRejets.iterator().next().getCodeAudit());
		});
	}

	@Test
	public void testCorpsCourt() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180012.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> lignesRejets = fichier.getLignes();
			Assert.assertEquals(1, lignesRejets.size());
			Assert.assertEquals(Controles.CT030, lignesRejets.iterator().next().getCodeAudit());
		});
	}

	@Test
	public void testEteteVide() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180013.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT039, fichier.getCodAudit());
			Assert.assertEquals(0, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testCorpVide() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180014.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT012, fichier.getCodAudit());
			Assert.assertEquals(0, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}

	@Test
	public void testEnqueuVide() {

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180015.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT040, fichier.getCodAudit());
			Assert.assertEquals(0, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
		});
	}
}