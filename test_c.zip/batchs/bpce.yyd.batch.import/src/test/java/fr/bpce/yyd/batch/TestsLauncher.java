package fr.bpce.yyd.batch;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Permission;
import java.time.LocalDate;
import java.util.List;
import java.util.Properties;

import org.junit.*;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.launch.Launcher;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;

public class TestsLauncher extends AbstractIntegrationTest {

	private static Properties properties = null;

	@BeforeClass
	public static void initProperties() throws Exception {
		// Chargement du fichier de propriétés des TI
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		// Utilisation de ces propriétés pour le ConfigManager
		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);

		// Création des dossiers, s'ils n'existent pas.
		createFolders();
	}

	@Before
	public void cleanFoldersBeforeTest() throws IOException {
		cleanFolders();
		doInTransaction(() -> {
			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
	}

	@AfterClass
	public static void cleanFoldersAfterClass() throws IOException {
		cleanFolders();
	}

	public static void cleanFolders() throws IOException {
		removeAllFilesInFolder(properties.getProperty("rep.in"));
		removeAllFilesInFolder(properties.getProperty("rep.encours"));
		removeAllFilesInFolder(properties.getProperty("rep.ok"));
		removeAllFilesInFolder(properties.getProperty("rep.ko"));
		removeAllFilesInFolder(properties.getProperty("rep.out.collecte"));

	}

	public static void createFolders() throws IOException {
		createFolderIfAbsent(properties.getProperty("rep.in"));
		createFolderIfAbsent(properties.getProperty("rep.encours"));
		createFolderIfAbsent(properties.getProperty("rep.ok"));
		createFolderIfAbsent(properties.getProperty("rep.ko"));
		createFolderIfAbsent(properties.getProperty("rep.out.collecte"));

	}

	@Ignore
	@Test
	public void fichierOK() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();
		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-180000.txt.gz";
		copyFilenameToInFolder(nomFichier);

		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.in") + nomFichier);

		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			Assert.assertTrue(new File(sanitizePathTraversal(properties.getProperty("rep.ok") + nomFichier)).exists());

		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	@Ignore
	@Test
	public void fichierKO() throws IOException {
		// save the initial security manager (probably null)
		SecurityManager initialSecurityManger = System.getSecurityManager();
		// Arrange
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(getContext());
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-170003.txt.zip";
		copyFilenameToInFolder(nomFichier);
		try {
			// set security manager
			System.setSecurityManager(new NoExitSecurityManager());
			// Act
			launcher.runBatch(properties.getProperty("rep.in") + nomFichier);

		} catch (ExitException e) {
			// Assert
			Assert.assertEquals(0, e.status);
			Assert.assertTrue(new File(sanitizePathTraversal(properties.getProperty("rep.ko") + nomFichier)).exists());

		} finally {
			// restore initial security manager (otherwise a new ExitException will be
			// thrown when the JVM will actually exit)
			System.setSecurityManager(initialSecurityManger);
		}
	}

	@Test
	public void collecteDeltaTiersPuiscChangementSiren() {
		// Act
		String nomFichier = "NDOD_EVT_DELTA_99999_RCT_190224-180117.txt";
		importFile(nomFichier);

		// Act 2
		String nomFichier2 = "NDOD_EVT_DELTA_99999_RCT_190224-180118.txt";
		importFile(nomFichier2);

		// Assert
		doInTransaction(() -> {
			List<Tiers> allTiers = findAllTiers();
			Assert.assertEquals(1, allTiers.size());

			List<IdentiteTiers> allIdentites = findAllIdentites();
			Assert.assertEquals(2, allIdentites.size());

			List<Evenement> allEvenements = findAllEvenements();
			Assert.assertEquals(1, allEvenements.size());

			List<ComplementEvenement> allComplementsEvenements = findAllComplementsEvenements();
			Assert.assertEquals(1, allComplementsEvenements.size());

		});
	}

	@Test
	public void collecteContagionTiersPuiscChangementSiren() {
		doInTransaction(() -> {
			Tiers tiersOrig = new Tiers();
			tiersOrig.setIdFederal("idFederal");
			getEntityManager().persist(tiersOrig);

			IdentiteTiers id = new IdentiteTiers();
			id.setIdLocal("idLocal");
			id.setCodeBanque("30007");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.now());
			id.setTiers(tiersOrig);
			getEntityManager().persist(id);

			StatutHistorise statutDefaut = new StatutHistorise();
			statutDefaut.setTiers(tiersOrig);
			statutDefaut.setStatut(StatutTiers.DEFAUT);
			statutDefaut.setAnnule(false);
			statutDefaut.setDateDeb(LocalDate.now());
			getEntityManager().persist(statutDefaut);

			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});

		// Act
		String nomFichier = "NDOD_EVT_CON_99999_RCT_190224-180017.txt";
		importFile(nomFichier);

		// Act 2
		String nomFichier2 = "NDOD_EVT_CON_99999_RCT_190224-180018.txt";
		importFile(nomFichier2);

		// Assert
		doInTransaction(() -> {
			List<Tiers> allTiers = findAllTiers();
			Assert.assertEquals(2, allTiers.size());

			List<IdentiteTiers> allIdentites = findAllIdentites();
			Assert.assertEquals(3, allIdentites.size());

			List<Evenement> allEvenements = findAllEvenements();
			Assert.assertEquals(1, allEvenements.size());

			List<ComplementEvenement> allComplementsEvenements = findAllComplementsEvenements();
			Assert.assertEquals(1, allComplementsEvenements.size());

		});
	}

	// exception to be thrown by security manager when System.exit is called
	public static class ExitException extends SecurityException {
		private static final long serialVersionUID = 1L;
		public final long status;

		public ExitException(long status) {
			this.status = status;
		}
	}

	// custom security manager
	public static class NoExitSecurityManager extends SecurityManager {
		@Override
		public void checkPermission(Permission perm) {
		}

		@Override
		public void checkPermission(Permission perm, Object context) {
		}

		@Override
		public void checkExit(int status) {
			super.checkExit(status);
			throw new ExitException(status);
		}
	}

	private void copyFilenameToInFolder(String nomFichier) throws IOException {
		Path pathFichier = Paths.get(TEST_FILES_FOLDER_NAME, nomFichier);
		Path pathIn = Paths.get(properties.getProperty("rep.in"));
		copyFileToDir(pathFichier, pathIn);
	}

	private Path copyFileToDir(Path filePath, Path destDirPath) throws IOException {
		return Files.copy(filePath, destDirPath.resolve(filePath.getFileName()), StandardCopyOption.REPLACE_EXISTING);
	}

	protected static void removeAllFilesInFolder(String folderName) throws IOException {
		Path folderPath = Paths.get(folderName);

		try {
			DirectoryStream<Path> stream = Files.newDirectoryStream(folderPath);
			for (Path entry : stream) {
				File file = entry.toFile();
				if (file.isFile()) {
					file.delete();
				}
			}
		} catch (NoSuchFileException ignored) {
			// Files was deleted, skip it.
		}

	}

	protected static void createFolderIfAbsent(String folderName) throws IOException {
		String secureFileName = sanitizePathTraversal(folderName);
		File folderAsFile = new File(secureFileName);
		if (folderAsFile.exists()) {
			if (folderAsFile.isDirectory()) {
				return;
			}
			folderAsFile.delete(); // Si un fichier existe avec ce nom.
		}
		folderAsFile.mkdir();
	}

	private static String sanitizePathTraversal(String fileName) {
		Path path = Paths.get(fileName).normalize();
		return path.toString();
	}

}
