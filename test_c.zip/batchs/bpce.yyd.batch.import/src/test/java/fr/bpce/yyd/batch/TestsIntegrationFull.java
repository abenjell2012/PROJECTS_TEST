package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;

public class TestsIntegrationFull extends AbstractIntegrationTest {

	static final List<Controles> LIST_CONTROLE_CT014_CF009 = Arrays.asList(Controles.CT014, Controles.CF009);
	static final List<Controles> LIST_CONTROLE_CT037 = Arrays.asList(Controles.CT037);

	@Before
	public void setUp() {
		doInTransaction(() -> {
			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
	}

	@Test
	public void testFullfichierOk4Lignes() {
		// Act
		String nomFichier = "NDOD_EVT_FULL_12128_RCT_190224-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(4, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

		});
	}

	@Test
	public void testFullfichierKoAvecCodBanqueInvalideDansLeNom() {
		// Act
		String nomFichier = "NDOD_EVT_FULL_00000_RCT_190224-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CF004, fichier.getCodAudit());

		});
	}

	@Test
	public void testFullfichierAvecEnteteKOCasCodBanqueInvalide() {
		// Act
		String nomFichier = "NDOD_EVT_FULL_12128_RCT_190224-180002.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT031, fichier.getCodAudit());
		});
	}

	@Test
	public void testFullfichierAvecEnqueueKoCasNombreLignesIncorrect() {
		// Act
		String nomFichier = "NDOD_EVT_FULL_12128_RCT_190224-180003.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.CT012, fichier.getCodAudit());
		});
	}

	@Test
	public void testFullfichierOkAvecRejetDatePhotoSuperieureDateConstitFlux() {
		// Act
		String nomFichier = "NDOD_EVT_FULL_12128_RCT_190224-180005.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(4, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertTrue(LIST_CONTROLE_CT014_CF009.contains(rejet.getCodeAudit()));
			}
		});
	}

	@Test
	public void testFullfichierOkAvecRejetDateMajInferieureDateDebEvt() {
		// Act
		String nomFichier = "NDOD_EVT_FULL_12128_RCT_190224-180007.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(4, fichier.getNbLignes());
			Assert.assertEquals(4, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertTrue(LIST_CONTROLE_CT037.contains(rejet.getCodeAudit()));
			}
		});
	}

	@Test
	public void testFullfichierOkAvecSirenInvalide() {
		// Act
		String nomFichier = "NDOD_EVT_FULL_12128_RCT_190224-180009.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(4, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CT017, rejet.getCodeAudit());
			}
		});
	}

	@Test
	public void testFullfichierOkAvecCodeSegmentInvalide() {
		// Act
		String nomFichier = "NDOD_EVT_FULL_12128_RCT_190224-180010.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			// Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(4, fichier.getNbLignes());
			Assert.assertEquals(1, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CF005, rejet.getCodeAudit());
			}
		});
	}
}
