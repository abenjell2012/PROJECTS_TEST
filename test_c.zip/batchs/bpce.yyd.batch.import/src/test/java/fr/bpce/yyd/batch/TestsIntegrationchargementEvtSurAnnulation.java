package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import fr.bpce.yyd.batch.service.impl.FunctionnalCheckerSrvcImpl;
import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;

public class TestsIntegrationchargementEvtSurAnnulation extends AbstractIntegrationTest {

	@Mock
	FunctionnalCheckerSrvcImpl functionalCheckMock;

	@Before
	public void setUp() {
		doInTransaction(() -> {
			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
	}

	@Test
	public void receptionEvenementACTsurEvenementDelta() {

		// Arrange - On crée les données en base pour un evenment ANN
		String codCliSeg = "3210";

		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id1 = new IdentiteTiers();

			id1.setCodeBanque("10107");
			id1.setIdLocal("jira790");
			id1.setCodeSegment(codCliSeg);
			id1.setDateDebut(LocalDate.of(2020, 1, 9)); // 09/01/2020
			tiers.addIdentite(id1);

			AuditFichiers fic = new AuditFichiers();

			Evenement evt = new Evenement();
			evt.setCode("DAX");
			evt.setDateDebut(LocalDate.of(2020, 9, 9));
			evt.setIdContrat("0000247699HFI");
			evt.setIdentiteInitiale(id1);
			evt.setIdLocal("ID-EVT-jira790");

			ComplementEvenement cplEvt = new ComplementEvenement();
			cplEvt.setEvenement(evt);
			cplEvt.setDatePhoto(LocalDate.of(2020, 1, 31));
			cplEvt.setDateMaj(LocalDate.of(2020, 1, 31));
			cplEvt.setStatutEvt(StatutEvenement.ANN);
			cplEvt.setIdentiteInitiale(id1);
			cplEvt.setAuditFichier(fic);

			getEntityManager().persist(fic);
			getEntityManager().persist(tiers);
			getEntityManager().persist(evt);
			getEntityManager().persist(cplEvt);
		});

		// Act - Intégration d'un evenement ACT sur l'evenemenet ANN
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_200909-160000.txt";
		importFile(nomFichier);

		// Assert

		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(3, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CF010, rejet.getCodeAudit());
			}

		});

	}

	@Test
	public void receptionEvenementACTsurEvenementFull() {

		// Arrange - On crée les données en base pour un evenment ANN
		String codCliSeg = "3210";

		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id1 = new IdentiteTiers();

			id1.setCodeBanque("10107");
			id1.setIdLocal("jira790");
			id1.setCodeSegment(codCliSeg);
			id1.setDateDebut(LocalDate.of(2020, 1, 9)); // 09/01/2020
			tiers.addIdentite(id1);

			AuditFichiers fic = new AuditFichiers();

			Evenement evt = new Evenement();
			evt.setCode("DAX");
			evt.setDateDebut(LocalDate.of(2020, 9, 9));
			evt.setIdContrat("0000247699HFI");
			evt.setIdentiteInitiale(id1);
			evt.setIdLocal("ID-EVT-jira790");

			ComplementEvenement cplEvt = new ComplementEvenement();
			cplEvt.setEvenement(evt);
			cplEvt.setDatePhoto(LocalDate.of(2020, 1, 31));
			cplEvt.setDateMaj(LocalDate.of(2020, 1, 31));
			cplEvt.setStatutEvt(StatutEvenement.ANN);
			cplEvt.setIdentiteInitiale(id1);
			cplEvt.setAuditFichier(fic);

			getEntityManager().persist(fic);
			getEntityManager().persist(tiers);
			getEntityManager().persist(evt);
			getEntityManager().persist(cplEvt);
		});

		// Act - Intégration d'un evenement ACT sur l'evenemenet ANN
		String nomFichier = "NDOD_EVT_FULL_10107_RCT_200909-160000.txt";
		importFile(nomFichier);

		// Assert

		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(2, fichier.getNbLignesRejet());

			Set<AuditLignesImport> rejets = fichier.getLignes();
			for (AuditLignesImport rejet : rejets) {
				Assert.assertEquals(Controles.CF010, rejet.getCodeAudit());
			}

		});

	}


	@Test
	public void receptionEvenementACTsurEvenementAnnuleClos() {

		// Arrange - On crée les données en base pour un evenment ANN
		String codCliSeg = "3210";

		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id1 = new IdentiteTiers();

			id1.setCodeBanque("10107");
			id1.setIdLocal("jira790");
			id1.setCodeSegment(codCliSeg);
			id1.setDateDebut(LocalDate.of(2020, 1, 9)); // 09/01/2020
			tiers.addIdentite(id1);

			AuditFichiers fic = new AuditFichiers();

			Evenement evt = new Evenement();
			evt.setCode("DAX");
			evt.setDateDebut(LocalDate.of(2020, 9, 9));
			evt.setIdContrat("0000247699HFI");
			evt.setIdentiteInitiale(id1);
			evt.setIdLocal("ID-EVT-jira790");

			ComplementEvenement cplEvt = new ComplementEvenement();
			cplEvt.setEvenement(evt);
			cplEvt.setDatePhoto(LocalDate.of(2020, 1, 31));
			cplEvt.setDateFin(LocalDate.of(2020, 1, 31));
			cplEvt.setDateMaj(LocalDate.of(2020, 1, 31));
			cplEvt.setStatutEvt(StatutEvenement.ANN);
			cplEvt.setIdentiteInitiale(id1);
			cplEvt.setAuditFichier(fic);

			getEntityManager().persist(fic);
			getEntityManager().persist(tiers);
			getEntityManager().persist(evt);
			getEntityManager().persist(cplEvt);
		});

		// Act - Intégration d'un evenement ACT sur l'evenemenet ANN
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_200909-160000.txt";
		importFile(nomFichier);

		// Assert

		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

		});

	}

}