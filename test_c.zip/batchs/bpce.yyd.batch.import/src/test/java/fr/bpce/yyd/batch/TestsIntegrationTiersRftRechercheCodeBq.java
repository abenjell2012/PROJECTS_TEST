package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ParMdcRechercheRft;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;

public class TestsIntegrationTiersRftRechercheCodeBq extends AbstractIntegrationTest {

	@Before
	public void setUp() {
		doInTransaction(() -> {
			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
	}

	@Test
	public void rechercheSurCodeBanqueDuTiers() {
		// Arrange - On crée le tiers unique manuellement.
		doInTransaction(() -> {

			// Tiers RFT 11138
			TiersRFT tiersRft1 = new TiersRFT();
			tiersRft1.setCodeBanque("11138");
			tiersRft1.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersRft1.setSiren("123456789");
			tiersRft1.setIdFederal("100200300");
			tiersRft1.setDate(LocalDate.of(2018, 12, 1));

			// Tiers RFT 30007
			TiersRFT tiersRft2 = new TiersRFT();
			tiersRft2.setCodeBanque("30007");
			tiersRft2.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersRft2.setSiren("987654321");
			tiersRft2.setIdFederal("9876543210");
			tiersRft2.setDate(LocalDate.of(2018, 12, 1));

			// table de passage code banque => code banque de recherche
			ParMdcRechercheRft parMcdRft = new ParMdcRechercheRft();
			parMcdRft.setCodeBqTiers("11138");
			parMcdRft.setCodeBqRechercheRft("30007");

			getEntityManager().persist(tiersRft1);
			getEntityManager().persist(tiersRft2);
			getEntityManager().persist(parMcdRft);
		});

		// Act - Intégration des deux événements de même ID provenant de 2 SI différents
		// Les événements ont des codes différents.
		// La dernière ligne du fichier met à jour l'événement relatif à l'ID 1, banque
		// 10107.
		String nomFichier = "NDOD_EVT_DELTA_11138_RCT_190220-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			for (Evenement evt : evenements) {
				IdentiteTiers identiteInitiale = evt.getIdentiteInitiale();

				Assert.assertEquals("100200300", identiteInitiale.getTiers().getIdFederal());
			}
		});
	}

	@Test
	public void rechercheSurCodeBanqueRechercheDuTiers() {
		// Arrange - On crée le tiers unique manuellement.
		doInTransaction(() -> {

			// Tiers RFT 11139
			TiersRFT tiersRft1 = new TiersRFT();
			tiersRft1.setCodeBanque("11139");
			tiersRft1.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersRft1.setSiren("123456789");
			tiersRft1.setIdFederal("100200300");
			tiersRft1.setDate(LocalDate.of(2018, 12, 1));

			// Tiers RFT 30007
			TiersRFT tiersRft2 = new TiersRFT();
			tiersRft2.setCodeBanque("30007");
			tiersRft2.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersRft2.setSiren("987654321");
			tiersRft2.setIdFederal("900800700");
			tiersRft2.setDate(LocalDate.of(2018, 12, 1));

			// table de passage code banque => code banque de recherche
			ParMdcRechercheRft parMcdRft = new ParMdcRechercheRft();
			parMcdRft.setCodeBqTiers("11138");
			parMcdRft.setCodeBqRechercheRft("30007");

			getEntityManager().persist(tiersRft1);
			getEntityManager().persist(tiersRft2);
			getEntityManager().persist(parMcdRft);
		});

		// Act - Intégration des deux événements de même ID provenant de 2 SI différents
		// Les événements ont des codes différents.
		// La dernière ligne du fichier met à jour l'événement relatif à l'ID 1, banque
		// 10107.
		String nomFichier = "NDOD_EVT_DELTA_11138_RCT_190220-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			for (Evenement evt : evenements) {
				IdentiteTiers identiteInitiale = evt.getIdentiteInitiale();

				Assert.assertEquals("900800700", identiteInitiale.getTiers().getIdFederal());
			}
		});
	}

	@Test
	public void rechercheAbsentedeRFTsurCodeBanque() {
		// Arrange - On crée le tiers unique manuellement.
		doInTransaction(() -> {

			// Tiers RFT 11139
			TiersRFT tiersRft1 = new TiersRFT();
			tiersRft1.setCodeBanque("11139");
			tiersRft1.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersRft1.setSiren("123456789");
			tiersRft1.setIdFederal("100200300");
			tiersRft1.setDate(LocalDate.of(2018, 12, 1));

			// Tiers RFT 11140
			TiersRFT tiersRft2 = new TiersRFT();
			tiersRft2.setCodeBanque("11140");
			tiersRft2.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersRft2.setSiren("987654321");
			tiersRft2.setIdFederal("900800700");
			tiersRft2.setDate(LocalDate.of(2018, 12, 1));

			// table de passage code banque => code banque de recherche
			ParMdcRechercheRft parMcdRft = new ParMdcRechercheRft();
			parMcdRft.setCodeBqTiers("11138");
			parMcdRft.setCodeBqRechercheRft("30007");

			getEntityManager().persist(tiersRft1);
			getEntityManager().persist(tiersRft2);
			getEntityManager().persist(parMcdRft);
		});

		// Act - Intégration des deux événements de même ID provenant de 2 SI différents
		// Les événements ont des codes différents.
		// La dernière ligne du fichier met à jour l'événement relatif à l'ID 1, banque
		// 10107.
		String nomFichier = "NDOD_EVT_DELTA_11138_RCT_190220-180000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(1, identites.size());
			Assert.assertEquals(1, evenements.size());

			for (Evenement evt : evenements) {
				IdentiteTiers identiteInitiale = evt.getIdentiteInitiale();

				Assert.assertEquals(null, identiteInitiale.getTiers().getIdFederal());
			}
		});
	}

}
