package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;

	public class TestsIntegrationJira629 extends AbstractIntegrationTest {

		@Before
		public void setUp() {
			doInTransaction(() -> {
				insertDateCalculCourante(LocalDate.now().minusDays(1));
			});
		}

		@Test
		public void changementSegmentHorsRetailARetail() {

			doInTransaction(() -> {

				TiersRFT tiersRFT1 = new TiersRFT("10107", "22738451", "0000010151", "303164024",
						LocalDate.of(2022, 1, 17));
				TiersRFT tiersRFT2 = new TiersRFT("30007", "4209994", "0000010151", "303164024",
						LocalDate.of(2022, 1, 17));
				TiersRFT tiersRFT3 = new TiersRFT("30007", "7209594", "0000010151", "303164024",
						LocalDate.of(2022, 1, 17));
				TiersRFT tiersRFT4 = new TiersRFT("15007", "303164024", "0000010151", "303164024",
						LocalDate.of(2022, 1, 17));
				TiersRFT tiersRFT5 = new TiersRFT("11315", "500261383", "0000010151", "303164024",
						LocalDate.of(2022, 1, 17));

				getEntityManager().persist(tiersRFT1);
				getEntityManager().persist(tiersRFT2);
				getEntityManager().persist(tiersRFT3);
				getEntityManager().persist(tiersRFT4);
				getEntityManager().persist(tiersRFT5);

				RefCliSsClass refSSclassPROF = new RefCliSsClass();
				refSSclassPROF.setCodTypNot("PROF");
				refSSclassPROF.setTopSuppr("N");
				refSSclassPROF.setLibSsClassCli("PROFESSIONNELS");
				refSSclassPROF.setCodClassCli("RET");
				refSSclassPROF.setCodSsClassCli("RETCFF");
				RefCliSsClass refSSclassCORP = new RefCliSsClass();
				refSSclassCORP.setCodTypNot("CORP");
				refSSclassCORP.setTopSuppr("N");
				refSSclassCORP.setLibSsClassCli("ENTITES DU SECTEUR PUBLIC");
				refSSclassCORP.setCodClassCli("COR");
				refSSclassCORP.setCodSsClassCli("CO1010");

				getEntityManager().persist(refSSclassPROF);
				getEntityManager().persist(refSSclassCORP);


			});

			String nomFichier1 = "NDOD_EVT_DELTA_11315_RCT_220205-000002.txt";
			importFile(nomFichier1);

			doInTransaction(() -> {

				AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier1);
				Assert.assertNotNull(fichier);
				Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
				Assert.assertEquals(1, fichier.getNbLignes());
				Assert.assertEquals(0, fichier.getNbLignesRejet());
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(1, tousTiers.size());


			});

			String nomFichier2 = "NDOD_EVT_DELTA_11315_RCT_220212-000002.txt";
			importFile(nomFichier2);

			doInTransaction(() -> {

				AuditFichiers fichier2 = findAuditFichierByNomFichier(nomFichier2);
				Assert.assertNotNull(fichier2);
				Assert.assertEquals(Controles.FICOK, fichier2.getCodAudit());
				Assert.assertEquals(1, fichier2.getNbLignes());
				Assert.assertEquals(0, fichier2.getNbLignesRejet());
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(2, tousTiers.size());

				for (Tiers tiers : tousTiers) {
					if (tiers.getIdFederal() != null) {
						Assert.assertEquals("0000010151", tiers.getIdFederal());
						Assert.assertEquals(1, tiers.getIdentites().size());

					} else {
						Assert.assertEquals(2, tiers.getIdentites().size());
					}
				}


			});
		}

		@Test
		public void changementSegmentHorsRetailARetailAutreCas() {

			doInTransaction(() -> {

				TiersRFT tiersRFT1 = new TiersRFT("11315", "22738451", "0000010151", "303164024",
						LocalDate.of(2022, 1, 17));
				TiersRFT tiersRFT5 = new TiersRFT("11315", "500261383", "0000010151", "303164024",
						LocalDate.of(2022, 1, 17));

				getEntityManager().persist(tiersRFT1);
				getEntityManager().persist(tiersRFT5);

				RefCliSsClass refSSclassPROF = new RefCliSsClass();
				refSSclassPROF.setCodTypNot("PROF");
				refSSclassPROF.setTopSuppr("N");
				refSSclassPROF.setLibSsClassCli("PROFESSIONNELS");
				refSSclassPROF.setCodClassCli("RET");
				refSSclassPROF.setCodSsClassCli("RETCFF");
				RefCliSsClass refSSclassCORP = new RefCliSsClass();
				refSSclassCORP.setCodTypNot("CORP");
				refSSclassCORP.setTopSuppr("N");
				refSSclassCORP.setLibSsClassCli("ENTITES DU SECTEUR PUBLIC");
				refSSclassCORP.setCodClassCli("COR");
				refSSclassCORP.setCodSsClassCli("CO1010");

				getEntityManager().persist(refSSclassPROF);
				getEntityManager().persist(refSSclassCORP);


			});

			String nomFichier1 = "NDOD_EVT_DELTA_11315_RCT_220205-000002.txt";
			importFile(nomFichier1);

			doInTransaction(() -> {

				AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier1);
				Assert.assertNotNull(fichier);
				Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
				Assert.assertEquals(1, fichier.getNbLignes());
				Assert.assertEquals(0, fichier.getNbLignesRejet());
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(1, tousTiers.size());


			});

			String nomFichier2 = "NDOD_EVT_DELTA_11315_RCT_220212-000002.txt";
			importFile(nomFichier2);

			doInTransaction(() -> {

				AuditFichiers fichier2 = findAuditFichierByNomFichier(nomFichier2);
				Assert.assertNotNull(fichier2);
				Assert.assertEquals(Controles.FICOK, fichier2.getCodAudit());
				Assert.assertEquals(1, fichier2.getNbLignes());
				Assert.assertEquals(0, fichier2.getNbLignesRejet());
				List<Tiers> tousTiers = findAllTiers();
				Assert.assertEquals(2, tousTiers.size());

				for (Tiers tiers : tousTiers) {
					if (tiers.getIdFederal() != null) {
						Assert.assertEquals("0000010151", tiers.getIdFederal());
						Assert.assertEquals(1, tiers.getIdentites().size());

					} else {
						Assert.assertEquals(2, tiers.getIdentites().size());
					}
				}


			});

		}
	}
