package fr.bpce.yyd.batch;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import fr.bpce.yyd.batch.beans.ImportEvtCloBean;
import fr.bpce.yyd.batch.beans.LigneImport;
import fr.bpce.yyd.batch.service.impl.FunctionnalCheckerSrvcImpl;
import fr.bpce.yyd.batch.util.ControleTechniqueUtil;
import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.AuditFichiers;

@RunWith(MockitoJUnitRunner.class)
public class ControleDetailsTest {

	private ControleTechniqueUtil controle;
	private LigneImport ligneImport;

	@Mock
	FunctionnalCheckerSrvcImpl functionalCheckMock;

	@Before
	public void initTest() {
		ligneImport = new LigneImport();
		controle = new ControleTechniqueUtil(ligneImport, new AuditFichiers(), "", 1, false, false);
		// MockitoAnnotations.initMocks(this);
		controle.setFunctionnalCheckerSrvc(functionalCheckMock);

	}

	@Test
	public void testControleIdTiersLocNull() {
		// Inputs
		String idTiersLoc = null;

		// Action
		controle.controlePresence("ID_TIERS_LOC", idTiersLoc);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleIdTiersLocVide() {
		// Inputs
		String idTiersLoc = "";

		// Action
		controle.controlePresence("ID_TIERS_LOC", idTiersLoc);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleIdTiersLocOk() {
		// Inputs
		String idTiersLoc = "12345678";

		// Action
		controle.controlePresence("ID_TIERS_LOC", idTiersLoc);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleCodeBanqueKo() {
		// Inputs
		String codeBanque = "abcd";

		// Action
		controle.controleCodeBanqueDetail(codeBanque);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleSirenKo() {
		// Inputs
		String siren = "abcd";

		// Action
		controle.controleSiren(siren);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleSirenKo2() {
		// Inputs
		String siren = "abcd WXCV";

		// Action
		controle.controleSiren(siren);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleSirenOk() {
		// Inputs
		String siren = "000000000";

		// Action
		controle.controleSiren(siren);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleSirenOk2() {
		// Inputs
		String siren = "0A000n000";

		// Action
		controle.controleSiren(siren);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleCodeSegmentOk() {
		// Inputs
		String codeSeg = "1060";
		Mockito.when(functionalCheckMock.isCodeSegmentValide(codeSeg)).thenReturn(true);

		// Action
		controle.controleCodeSeg(codeSeg);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleCodeSegmentKo() {
		// Inputs
		String codeSeg = "abcd";
		Mockito.when(functionalCheckMock.isCodeSegmentValide(codeSeg)).thenReturn(false);
		// Action
		controle.controleCodeSeg(codeSeg);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleIdEvtLocNull() {
		// Inputs
		String idEvtLoc = null;

		// Action
		controle.controlePresence("ID_EVT_LOC", idEvtLoc);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleIdEvtLocVide() {
		// Inputs
		String idEvtLoc = "";

		// Action
		controle.controlePresence("ID_EVT_LOC", idEvtLoc);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleIdEvtLocOk() {
		// Inputs
		String idEvtLoc = "12345678";

		// Action
		controle.controlePresence("ID_EVT_LOC", idEvtLoc);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleCodeEvtIMX() {
		// Inputs
		String codeEvt = "IMX";
		LocalDate datePhoto = LocalDate.of(2019, 10, 1);

		Mockito.when(functionalCheckMock.isCodeEvementValide(codeEvt, datePhoto)).thenReturn(true);

		// Action
		controle.controleCodeEvt(codeEvt, datePhoto);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleCodeEvtXXX() {
		// Inputs
		String codeEvt = "XXX";
		LocalDate datePhoto = LocalDate.of(2018, 10, 1);
		Mockito.when(functionalCheckMock.isCodeEvementValide(codeEvt, datePhoto)).thenReturn(false);

		// Action
		controle.controleCodeEvt(codeEvt, datePhoto);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleTypeEvtDM01() {
		// Inputs
		String typeEvt = "DM01";
		LocalDate datePhoto = LocalDate.of(2019, 10, 1);
		Mockito.when(functionalCheckMock.isSousCodeEvtValide(typeEvt, "DM", datePhoto)).thenReturn(true);

		// Action
		controle.controleTypeEvt(typeEvt, "DM", datePhoto);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleTypeEvtNonOblig() {
		// Inputs
		String typeEvt = "";
		LocalDate datePhoto = LocalDate.of(2019, 10, 1);
		// Action
		controle.controleTypeEvt(typeEvt, "IMX", datePhoto);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleTypeEvtXXX() {
		// Inputs
		String typeEvt = "XXX";
		LocalDate datePhoto = LocalDate.of(2019, 10, 1);
		Mockito.when(functionalCheckMock.isSousCodeEvtValide(typeEvt, "DM", datePhoto)).thenReturn(false);

		// Action
		controle.controleTypeEvt(typeEvt, "DM", datePhoto);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleDateDebEvtOk() {
		// Inputs
		String dateDebEvt = "20190701";
		LocalDate datePhoto = LocalDate.of(2019, 8, 1);
		LocalDate dateCollecte = LocalDate.of(2019, 8, 1);

		// Action
		controle.controleDateDebEvt(dateDebEvt, datePhoto, dateCollecte);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleDateDebEvtKo() {
		// Inputs
		String dateDebEvt = "200701";
		LocalDate datePhoto = LocalDate.of(2019, 10, 1);
		LocalDate dateCollecte = LocalDate.of(2019, 10, 1);
		// Action
		controle.controleDateDebEvt(dateDebEvt, datePhoto,dateCollecte);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleStatutEvtACT() {
		// Inputs
		String statutEvt = "ACT";
		LocalDate datePhoto = LocalDate.of(2019, 10, 1);

		// Action
		controle.controleStatutEvt(statutEvt, "IMX", "1010", datePhoto, null);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleStatutEvtXXX() {
		// Inputs
		String statutEvt = "XXX";
		LocalDate datePhoto = LocalDate.of(2019, 10, 1);

		// Action
		controle.controleStatutEvt(statutEvt, "DMX", "1010", datePhoto, null);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleDateMajEvtOk() {
		// Inputs
		String dateMajEvt = "20190701";
		LocalDate datePhoto = LocalDate.of(2019, 10, 1);
		LocalDate dateDebutEvt = LocalDate.of(2019, 06, 1);
		LocalDate dateCollecte = LocalDate.of(2019, 10, 1);

		// Action
		controle.controleDateMajEvt(dateMajEvt, datePhoto, dateDebutEvt, dateCollecte, null, null,null);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleDateMajEvtKo() {
		// Inputs
		String dateMajEvt = "200701";
		LocalDate datePhoto = LocalDate.of(2019, 10, 1);
		LocalDate dateDebutEvt = LocalDate.of(2019, 06, 1);
		LocalDate dateCollecte = LocalDate.of(2019, 10, 1);
		// Action
		controle.controleDateMajEvt(dateMajEvt, datePhoto, dateDebutEvt,dateCollecte, null, null, null);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleDatePhotoEvtBeforeDateConstitiFlux() {
		// Inputs
		String datePhotoEvt = "20190701";
		LocalDate dateCnstFlux = LocalDate.parse("2019-06-30");
		LocalDate dateCollecte = LocalDate.parse("2019-06-30");

		// Action
		controle.controleDatePhoto(datePhotoEvt, dateCnstFlux, dateCollecte);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleDatePhotoEvtEgaleDateConstitiFlux() {
		// Inputs
		String datePhotoEvt = "20190701";
		LocalDate dateCnstFlux = LocalDate.parse("2019-07-01");
		LocalDate dateCollecte = LocalDate.parse("2019-07-01");

		// Action
		controle.controleDatePhoto(datePhotoEvt, dateCnstFlux,dateCollecte);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleDatePhotoEvtAfterDateConstitiFlux() {
		// Inputs
		String datePhotoEvt = "20190701";
		LocalDate dateCnstFlux = LocalDate.parse("2019-07-02");
		LocalDate dateCollecte = LocalDate.parse("2019-07-02");

		// Action
		controle.controleDatePhoto(datePhotoEvt, dateCnstFlux,dateCollecte);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleDatePhotoEvtBadFormat() {
		// Inputs
		String datePhotoEvt = "200701";
		LocalDate dateCnstFlux = LocalDate.parse("2019-07-02");
		LocalDate dateCollecte = LocalDate.parse("2019-07-02");

		// Action
		controle.controleDatePhoto(datePhotoEvt, dateCnstFlux,dateCollecte);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleIdContratCasCodeEvtIMX() {
		// Inputs
		String idCtrt = "1234567";
		String codeEvt = "IMX";

		// Action
		controle.controleIdCtrt(idCtrt, codeEvt);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleIdContratVideCasCodeEvtIMX() {
		// Inputs
		String idCtrt = "";
		String codeEvt = "IMX";

		// Action
		controle.controleIdCtrt(idCtrt, codeEvt);

		// Assert
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleIdContratVideCasCodeEvtUTP() {
		// Inputs
		String idCtrt = "";
		String codeEvt = "UTP";

		// Action
		controle.controleIdCtrt(idCtrt, codeEvt);

		// Assert
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleMontantArriereAvec2Decimal() {
		// Inputs
		String mtArriereStr = "+00000000000165032";

		// Action
		BigDecimal mttArriere = controle.controleMontantArriere(mtArriereStr);

		// Assert
		assertEquals(new BigDecimal("1650.32"), mttArriere);
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleMontantArriereSansDecimal() {
		// Inputs
		String mtArriereStr = "+00000000027458700";

		// Action
		BigDecimal mttArriere = controle.controleMontantArriere(mtArriereStr);

		// Assert
		assertEquals(new BigDecimal(new BigInteger("27458700"), 2), mttArriere);
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleMontantArriereNull() {
		// Inputs
		String mtArriereStr = "+00000000000000000";

		// Action
		BigDecimal mttArriere = controle.controleMontantArriere(mtArriereStr);

		// Assert
		assertEquals(new BigDecimal(new BigInteger("0"), 2), mttArriere);
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleMontantArriereSansPlus() {
		// Inputs
		String mtArriereStr = "000000000000000123";

		// Action
		BigDecimal mttArriere = controle.controleMontantArriere(mtArriereStr);

		// Assert
		assertNull(mttArriere);
		assertFalse(ligneImport.getTopTraitement());
		assertFalse(ligneImport.getAuditLigne().isEmpty());
		assertEquals(Controles.CT033, ligneImport.getAuditLigne().get(0).getCodeAudit());

	}

	@Test
	public void testControleMontantArriereMalFormate() {
		// Inputs
		String mtArriereStr = "+0000000000000X123";

		// Action
		BigDecimal mttArriere = controle.controleMontantArriere(mtArriereStr);

		// Assert
		assertNull(mttArriere);
		assertFalse(ligneImport.getTopTraitement());
		assertFalse(ligneImport.getAuditLigne().isEmpty());
		assertEquals(Controles.CT022, ligneImport.getAuditLigne().get(0).getCodeAudit());

	}

	@Test
	public void testControleMontantArriereLongueurIncorrect() {
		// Inputs
		String mtArriereStr = "+0000000010123";

		// Action
		BigDecimal mttArriere = controle.controleMontantArriere(mtArriereStr);

		// Assert
		assertNull(mttArriere);
		assertFalse(ligneImport.getTopTraitement());
		assertFalse(ligneImport.getAuditLigne().isEmpty());
		assertEquals(Controles.CT022, ligneImport.getAuditLigne().get(0).getCodeAudit());

	}

	@Test
	public void testControleFlagLitigeIncorrect() {
		// Action
		boolean flagLitige = controle.controleFlagLitige("P");

		// Assert
		assertFalse(flagLitige);
		assertFalse(ligneImport.getTopTraitement());
		assertFalse(ligneImport.getAuditLigne().isEmpty());
		assertEquals(Controles.CT035, ligneImport.getAuditLigne().get(0).getCodeAudit());

	}

	@Test
	public void testControleFlagLitigeCorrect() {
		// Action
		boolean flagLitige = controle.controleFlagLitige("O");

		// Assert
		assertTrue(flagLitige);
		assertTrue(ligneImport.getTopTraitement());
		assertTrue(ligneImport.getAuditLigne().isEmpty());

	}

	@Test
	public void testControleFlagTechIncorrect() {
		// Action
		boolean flagTech = controle.controleFlagTech("K");

		// Assert
		assertFalse(flagTech);
		assertFalse(ligneImport.getTopTraitement());
		assertFalse(ligneImport.getAuditLigne().isEmpty());
		assertEquals(Controles.CT034, ligneImport.getAuditLigne().get(0).getCodeAudit());

	}

	@Test
	public void testControleFlagTechCorrect() {
		// Action
		boolean flagTech = controle.controleFlagLitige("N");

		// Assert
		assertFalse(flagTech);
		assertTrue(ligneImport.getTopTraitement());
		assertTrue(ligneImport.getAuditLigne().isEmpty());

	}

	/*
	 * TEST LES SOUS CODE EVENEMENTS
	 */
	@Test
	public void testControlePassantSousCodeEvtDMAvecSousTypeVide() {
		// Arange
		String ssCodeEvt = "";
		String codeEvt = "DM";
		LocalDate dateDemande = LocalDate.of(2019, 10, 1);

		// Act
		String result = controle.controleTypeEvt(ssCodeEvt, codeEvt, dateDemande);

		// Assert
		assertEquals(ssCodeEvt, result);

	}

	@Test
	public void testControleNonPassantSousCodeEvtDMAvecSousTypeABCD() {
		// Arange
		String ssCodeEvt = "ABCD";
		String codeEvt = "DM";
		LocalDate dateDemande = LocalDate.of(2019, 10, 1);
		Mockito.when(functionalCheckMock.isSousCodeEvtValide(ssCodeEvt, codeEvt, dateDemande)).thenReturn(false);

		// Act
		String result = controle.controleTypeEvt(ssCodeEvt, codeEvt, dateDemande);

		// Assert
		assertEquals(ssCodeEvt, result);
		assertEquals(Controles.CT019, ligneImport.getAuditLigne().get(0).getCodeAudit());
	}

	@Test
	public void testControleNonPassantSousCodeEvtDMAvecSousTypeDM50() {
		// Arange
		String ssCodeEvt = "DM50";
		String codeEvt = "DM";
		LocalDate dateDemande = LocalDate.of(2019, 10, 1);

		Mockito.when(functionalCheckMock.isSousCodeEvtValide(ssCodeEvt, codeEvt, dateDemande)).thenReturn(false);

		// Act
		String result = controle.controleTypeEvt(ssCodeEvt, codeEvt, dateDemande);

		// Assert
		assertEquals(ssCodeEvt, result);
		assertEquals(Controles.CT019, ligneImport.getAuditLigne().get(0).getCodeAudit());
	}

	@Test
	public void testControlePassantSousCodeEvtDMAvecSousTypePresentParam() {
		// Arange
		String ssCodeEvt = "DM01";
		String codeEvt = "DM";
		LocalDate dateDemande = LocalDate.of(2019, 10, 1);

		Mockito.when(functionalCheckMock.isSousCodeEvtValide(ssCodeEvt, codeEvt, dateDemande)).thenReturn(true);

		// Act
		String result = controle.controleTypeEvt(ssCodeEvt, codeEvt, dateDemande);

		// Assert
		assertEquals(ssCodeEvt, result);
	}

	@Test
	public void testControlePassantSousCodeEvtDMAvecSousTypeNull() {
		// Arange
		String ssCodeEvt = "";
		String codeEvt = "DM";
		LocalDate dateDemande = LocalDate.of(2019, 10, 1);

		Mockito.when(functionalCheckMock.isSousCodeEvtValide(ssCodeEvt, codeEvt, dateDemande)).thenReturn(false);

		// Act
		String result = controle.controleTypeEvt(ssCodeEvt, codeEvt, dateDemande);

		// Assert
		assertEquals(ssCodeEvt, result);
		assertEquals(Controles.CT019, ligneImport.getAuditLigne().get(0).getCodeAudit());
	}

	@Test
	// DELTA - Envoi évènement ACT sur un évènement ANN en base -> Rejet CF010
	public void testControleNonPassantEvenementAnnuleRecuDeltaACT() {
		// Arange
		StatutEvenement statutEvt = StatutEvenement.ACT;
		controle.setMensuelFile(false); // fichier DELTA
		String codeEvt = "DAX";
		String idLocalEvenement = "2019070300000000000015102";
		String codeBanque = "10107";
		String idLocalTiers = "jira790";

		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);

		Mockito.when(
				functionalCheckMock.isEvementAnnule(codeEvt, idLocalTiers, idLocalEvenement, codeBanque, dateDebEvt))
				.thenReturn(true);

		// Act
		controle.controleEvenementNotAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt);

		// Assert
		assertEquals(Controles.CF010, ligneImport.getAuditLigne().get(0).getCodeAudit());
	}

	@Test
	// DELTA - Envoi évènement CLO sur un évènement ANN en base Rejet Rejet -> CF010
	public void testControleNonPassantEvenementAnnuleRecuDeltaCLO() {
		// Arange
		StatutEvenement statutEvt = StatutEvenement.CLO;
		controle.setMensuelFile(false); // fichier DELTA
		String codeEvt = "DAX";
		String idLocalEvenement = "2019070300000000000015102";
		String codeBanque = "10107";
		String idLocalTiers = "jira790";

		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);

		Mockito.when(
				functionalCheckMock.isEvementAnnule(codeEvt, idLocalTiers, idLocalEvenement, codeBanque, dateDebEvt))
				.thenReturn(true);

		// Act
		controle.controleEvenementNotAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt);

		// Assert
		assertEquals(Controles.CF010, ligneImport.getAuditLigne().get(0).getCodeAudit());
	}

	@Test
	// DELTA - Envoi évènement ANN sur un évènement ANN en base Rejet -> rejet CF010
	public void testControleNonPassantEvenementAnnuleRecuDeltaANN() {
		// Arange
		StatutEvenement statutEvt = StatutEvenement.ANN;
		controle.setMensuelFile(false); // fichier DELTA
		String codeEvt = "DAX";
		String idLocalEvenement = "2019070300000000000015102";
		String codeBanque = "10107";
		String idLocalTiers = "jira790";

		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);

		Mockito.when(
				functionalCheckMock.isEvementAnnule(codeEvt, idLocalTiers, idLocalEvenement, codeBanque, dateDebEvt))
				.thenReturn(true);

		// Act
		controle.controleEvenementNotAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt);

		// Assert
		assertEquals(Controles.CF010, ligneImport.getAuditLigne().get(0).getCodeAudit());
	}

	// DELTA - Envoi évènement ACT sur un évènement qui n'est pas ANN en base -> pas
	// de Rejet en base
	@Test
	public void testControlePassantEvenementAnnuleRecuDeltaACT() {
		// Arange
		StatutEvenement statutEvt = StatutEvenement.ACT;
		controle.setMensuelFile(false); // fichier DELTA
		String codeEvt = "DAX";
		String idLocalEvenement = "2019070300000000000015102";
		String codeBanque = "10107";
		String idLocalTiers = "jira790";

		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);

		Mockito.when(
				functionalCheckMock.isEvementAnnule(codeEvt, idLocalTiers, idLocalEvenement, codeBanque, dateDebEvt))
				.thenReturn(false);

		// Act
		controle.controleEvenementNotAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt);

		// Assert
		assertEquals(0, ligneImport.getAuditLigne().size());
	}

	@Test
	// DELTA - Envoi évènement CLO sur un évènement qui n'est pas ANN en base -> pas
	// de Rejet en base
	public void testControlePassantEvenementAnnuleRecuDeltaCLO() {
		// Arange
		StatutEvenement statutEvt = StatutEvenement.CLO;
		controle.setMensuelFile(false); // fichier DELTA
		String codeEvt = "DAX";
		String idLocalEvenement = "2019070300000000000015102";
		String codeBanque = "10107";
		String idLocalTiers = "jira790";

		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);

		Mockito.when(
				functionalCheckMock.isEvementAnnule(codeEvt, idLocalTiers, idLocalEvenement, codeBanque, dateDebEvt))
				.thenReturn(false);

		// Act
		controle.controleEvenementNotAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt);

		// Assert
		assertEquals(0, ligneImport.getAuditLigne().size());
	}

	@Test
	// DELTA - Envoi évènement ANN sur un évènement qui n'est pas ANN en base -> pas
	// de Rejet en base
	public void testControlePassantEvenementAnnuleRecuDeltaANN() {
		// Arange
		StatutEvenement statutEvt = StatutEvenement.ANN;
		controle.setMensuelFile(false); // fichier DELTA
		String codeEvt = "DAX";
		String idLocalEvenement = "2019070300000000000015102";
		String codeBanque = "10107";
		String idLocalTiers = "jira790";

		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);

		Mockito.when(
				functionalCheckMock.isEvementAnnule(codeEvt, idLocalTiers, idLocalEvenement, codeBanque, dateDebEvt))
				.thenReturn(false);

		// Act
		controle.controleEvenementNotAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt);

		// Assert
		assertEquals(0, ligneImport.getAuditLigne().size());
	}

	@Test
	// MENSUEL - Envoi évènement ACT sur un évènement ANN en base -> Rejet CF010
	public void testControleNonPassantEvenementAnnuleRecuMensuelACT() {
		// Arange
		StatutEvenement statutEvt = StatutEvenement.ACT;
		controle.setMensuelFile(true); // fichier FULL
		String codeEvt = "DAX";
		String idLocalEvenement = "2019070300000000000015102";
		String codeBanque = "10107";
		String idLocalTiers = "jira790";

		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);

		Mockito.when(
				functionalCheckMock.isEvementAnnule(codeEvt, idLocalTiers, idLocalEvenement, codeBanque, dateDebEvt))
				.thenReturn(true);

		// Act
		controle.controleEvenementNotAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt);

		// Assert
		assertEquals(Controles.CF010, ligneImport.getAuditLigne().get(0).getCodeAudit());
	}

	@Test
	// MENSUEL - Envoi évènement CLO sur un évènement ANN en base Rejet Rejet ->
	// CF010
	public void testControleNonPassantEvenementAnnuleRecuMensuelCLO() {
		// Arange
		StatutEvenement statutEvt = StatutEvenement.CLO;
		controle.setMensuelFile(true); // fichier FULL
		String codeEvt = "DAX";
		String idLocalEvenement = "2019070300000000000015102";
		String codeBanque = "10107";
		String idLocalTiers = "jira790";

		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);

		Mockito.when(
				functionalCheckMock.isEvementAnnule(codeEvt, idLocalTiers, idLocalEvenement, codeBanque, dateDebEvt))
				.thenReturn(true);

		// Act
		controle.controleEvenementNotAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt);

		// Assert
		assertEquals(Controles.CF010, ligneImport.getAuditLigne().get(0).getCodeAudit());
	}

	@Test
	// MENSUEL - Envoi évènement ANN sur un évènement ANN en base -> pas de Rejet en
	// base
	public void testControlePassantEvenementAnnuleRecuMensuelANN() {
		// Arange
		StatutEvenement statutEvt = StatutEvenement.ANN;
		controle.setMensuelFile(true); // fichier FULL
		String codeEvt = "DAX";
		String idLocalEvenement = "2019070300000000000015102";
		String codeBanque = "10107";
		String idLocalTiers = "jira790";

		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);

		// Act
		controle.controleEvenementNotAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt);

		// Assert
		assertEquals(0, ligneImport.getAuditLigne().size());
	}

	@Test
	public void testControlePassantDateMajEvtAnnule() {
		// Arange
		String codeEvt = "PSU";
		StatutEvenement statutEvt = StatutEvenement.ANN;
		String idLocalEvenement = "EVTLOCALJIRA182OK";
		String codeBanque = "10107";
		String idLocalTiers = "LOCALTIERSJIRA182OK";
		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);
		LocalDate dateMajAnn = LocalDate.of(2019, 11, 15);
		// cloture le 12/11/2019 et annulation le 15/11/2019 => OK
		ImportEvtCloBean evtClo = new ImportEvtCloBean(idLocalEvenement, codeEvt, dateDebEvt, codeBanque, idLocalTiers,
				LocalDate.of(2019, 11, 12));
		Mockito.when(functionalCheckMock.chercheEvenementCloture(codeBanque, idLocalTiers, codeEvt, idLocalEvenement,
				dateDebEvt)).thenReturn(evtClo);
		// Act
		controle.controleDateEvenementAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt,
				dateMajAnn);

		// Assert
		assertEquals(0, ligneImport.getAuditLigne().size());
	}

	@Test
	public void testControleNonPassantDateMajEvtAnnule() {
		// Arange
		String codeEvt = "PSU";
		StatutEvenement statutEvt = StatutEvenement.ANN;
		String idLocalEvenement = "EVTLOCALJIRA182KO";
		String codeBanque = "10107";
		String idLocalTiers = "LOCALTIERSJIRA182KO";
		LocalDate dateDebEvt = LocalDate.of(2019, 11, 11);
		LocalDate dateMajAnn = LocalDate.of(2019, 11, 15);
		// cloture le 20/11/2019 et annulation le 15/11/2019 => KO
		ImportEvtCloBean evtClo = new ImportEvtCloBean(idLocalEvenement, codeEvt, dateDebEvt, codeBanque, idLocalTiers,
				LocalDate.of(2019, 11, 20));
		Mockito.when(functionalCheckMock.chercheEvenementCloture(codeBanque, idLocalTiers, codeEvt, idLocalEvenement,
				dateDebEvt)).thenReturn(evtClo);
		// Act
		controle.controleDateEvenementAnnule(codeEvt, idLocalEvenement, codeBanque, idLocalTiers, dateDebEvt, statutEvt,
				dateMajAnn);

		// Assert
		assertEquals(1, ligneImport.getAuditLigne().size());
		assertEquals(Controles.CF011, ligneImport.getAuditLigne().get(0).getCodeAudit());

	}

	@Test
	public void testControleLimitesDateOK() {
		// Arange

		LocalDate date = LocalDate.of(2019, 11, 11);
		LocalDate dateCollecte = LocalDate.of(2019, 11, 15);

		// Assert
		assertTrue(controle.controleLimitesDate(date,dateCollecte,Controles.CT047));
		assertTrue(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleLimitesDateSupKO() {
		// Arange
		LocalDate date = LocalDate.of(2019, 12, 11);
		LocalDate dateCollecte = LocalDate.of(2019, 11, 15);

		// Assert
		assertFalse(controle.controleLimitesDate(date,dateCollecte,Controles.CT047));
		Assert.assertEquals(1,ligneImport.getAuditLigne().size());
		Assert.assertEquals(Controles.CT047,ligneImport.getAuditLigne().get(0).getCodeAudit());
		assertFalse(ligneImport.getTopTraitement());
	}

	@Test
	public void testControleLimitesDateInfKO() {
		// Arange

		LocalDate date = LocalDate.of(1969, 12, 11);
		LocalDate dateCollecte = LocalDate.of(2019, 11, 15);

		// Assert
		assertFalse(controle.controleLimitesDate(date,dateCollecte,Controles.CT047));
		Assert.assertEquals(1,ligneImport.getAuditLigne().size());
		Assert.assertEquals(Controles.CT047,ligneImport.getAuditLigne().get(0).getCodeAudit());
		assertFalse(ligneImport.getTopTraitement());
	}

}
