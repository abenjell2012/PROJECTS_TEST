package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;

public class TestIntegrationChangementSegment extends AbstractIntegrationTest {

	@Before
	public void setUp() {
		doInTransaction(() -> {
			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
	}

	@Test
	public void changementSegmentRetailAHorsRetail() {

		doInTransaction(() -> {

			TiersRFT tiersRFTMercedes = new TiersRFT("10807", "mercedes", "0000003555", "002220500",
					LocalDate.of(2019, 2, 1));
			TiersRFT tiersRFTBMW = new TiersRFT("10807", "bmw", "0000004500", "002220501", LocalDate.of(2019, 2, 1));
			TiersRFT tiersRFTCLIO = new TiersRFT("10807", "clio", "0000003555", "002220500", LocalDate.of(2019, 2, 1));

			getEntityManager().persist(tiersRFTMercedes);
			getEntityManager().persist(tiersRFTBMW);
			getEntityManager().persist(tiersRFTCLIO);
			RefCliSsClass refSSclassPROF = new RefCliSsClass();
			refSSclassPROF.setCodTypNot("PROF");
			refSSclassPROF.setTopSuppr("N");
			refSSclassPROF.setLibSsClassCli("PROFESSIONNELS");
			refSSclassPROF.setCodClassCli("RET");
			refSSclassPROF.setCodSsClassCli("RETPRO");
			RefCliSsClass refSSclassCORP = new RefCliSsClass();
			refSSclassCORP.setCodTypNot("CORP");
			refSSclassCORP.setTopSuppr("N");
			refSSclassCORP.setLibSsClassCli("ENTITES DU SECTEUR PUBLIC");
			refSSclassCORP.setCodClassCli("COR");
			refSSclassCORP.setCodSsClassCli("COR010");

			getEntityManager().persist(refSSclassPROF);
			getEntityManager().persist(refSSclassCORP);
		});

		String nomFichier = "NDOD_EVT_DELTA_10807_RCT_190224-180000.txt";
		importFile(nomFichier);

		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(3, tousTiers.size());
			for (Tiers tiers : tousTiers) {
				Assert.assertEquals(1, tiers.getIdentites().size());
				IdentiteTiers identite = tiers.getIdentites().iterator().next();
				if (identite.getIdLocal().equals("clio") || identite.getIdLocal().equals("bmw")) {
					Assert.assertEquals("3120", identite.getCodeSegment());
					Assert.assertNull(tiers.getIdFederal());
				} else {
					Assert.assertEquals("1100", identite.getCodeSegment());
					Assert.assertEquals("0000003555", tiers.getIdFederal());
				}
			}

		});

		String nomFichier2 = "NDOD_EVT_DELTA_10807_RCT_190224-180001.txt";
		importFile(nomFichier2);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(3, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				if (tiers.getIdFederal() != null && tiers.getIdFederal().equals("0000004500")) {
					Assert.assertEquals(2, tiers.getIdentites().size());
					for (IdentiteTiers identiteTiers : tiers.getIdentites()) {
						Assert.assertEquals("bmw", identiteTiers.getIdLocal());
						if (identiteTiers.getCodeSegment().equals("3120")) {
							Assert.assertNotNull(identiteTiers.getDateFin());
							Assert.assertNotNull(identiteTiers.getSuivante());
						} else {
							Assert.assertNull(identiteTiers.getDateFin());
							Assert.assertNull(identiteTiers.getSuivante());
							Assert.assertEquals("1100", identiteTiers.getCodeSegment());
						}
					}
				} else if (tiers.getIdFederal() != null && tiers.getIdFederal().equals("0000003555")) {
					Assert.assertEquals(1, tiers.getIdentites().size());
					Assert.assertEquals("1100", tiers.getIdentites().iterator().next().getCodeSegment());
					Assert.assertEquals("mercedes", tiers.getIdentites().iterator().next().getIdLocal());
				} else {
					Assert.assertNull(tiers.getIdFederal());
					Assert.assertEquals(1, tiers.getIdentites().size());
					Assert.assertEquals("clio", tiers.getIdentites().iterator().next().getIdLocal());
					Assert.assertEquals("3120", tiers.getIdentites().iterator().next().getCodeSegment());
					Assert.assertNull(tiers.getIdentites().iterator().next().getDateFin());
					Assert.assertNull(tiers.getIdentites().iterator().next().getSuivante());
				}
			}

		});

		String nomFichier3 = "NDOD_EVT_DELTA_10807_RCT_190224-180002.txt";
		importFile(nomFichier3);
		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier3);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(3, tousTiers.size());
			for (Tiers tiers : tousTiers) {
				if (tiers.getIdFederal() != null && tiers.getIdFederal().equals("0000004500")) {
					Assert.assertEquals(2, tiers.getIdentites().size());
					for (IdentiteTiers identiteTiers : tiers.getIdentites()) {
						Assert.assertEquals("bmw", identiteTiers.getIdLocal());
						if (identiteTiers.getCodeSegment().equals("3120")) {
							Assert.assertNotNull(identiteTiers.getDateFin());
							Assert.assertNotNull(identiteTiers.getSuivante());
						} else {
							Assert.assertNull(identiteTiers.getDateFin());
							Assert.assertNull(identiteTiers.getSuivante());
							Assert.assertEquals("1100", identiteTiers.getCodeSegment());
						}
					}
				} else if (tiers.getIdFederal() != null && tiers.getIdFederal().equals("0000003555")) {
					Assert.assertEquals(2, tiers.getIdentites().size());
					for (IdentiteTiers identiteTiers : tiers.getIdentites()) {
						Assert.assertNull(identiteTiers.getDateFin());
						Assert.assertNull(identiteTiers.getSuivante());
						Assert.assertEquals("1100", identiteTiers.getCodeSegment());
						if (!identiteTiers.getIdLocal().equals("clio")
								&& !identiteTiers.getIdLocal().equals("mercedes")) {
							Assert.assertNotNull(null);
						}
					}
				} else {
					Assert.assertNull(tiers.getIdFederal());
					Assert.assertEquals(1, tiers.getIdentites().size());
					Assert.assertEquals("clio", tiers.getIdentites().iterator().next().getIdLocal());
					Assert.assertEquals("3120", tiers.getIdentites().iterator().next().getCodeSegment());
					Assert.assertNotNull(tiers.getIdentites().iterator().next().getDateFin());
					Assert.assertNotNull(tiers.getIdentites().iterator().next().getSuivante());
				}
			}
		});
	}

	@Test
	public void changementSegmentRetailAHorsRetailRcff() {

		doInTransaction(() -> {

			TiersRFT tiersRFTMercedes = new TiersRFT("10807", "mercedes", "0000003555", "002220500",
					LocalDate.of(2019, 2, 1));
			TiersRFT tiersRFTBMW = new TiersRFT("10807", "bmw", "0000004500", "002220501", LocalDate.of(2019, 2, 1));
			TiersRFT tiersRFTCLIO = new TiersRFT("10807", "clio", "0000003555", "002220500", LocalDate.of(2019, 2, 1));

			getEntityManager().persist(tiersRFTMercedes);
			getEntityManager().persist(tiersRFTBMW);
			getEntityManager().persist(tiersRFTCLIO);

			// REF_CLI_SS_CLASS
			RefCliSsClass refSSclassPROF = new RefCliSsClass();
			refSSclassPROF.setCodTypNot("PROF");
			refSSclassPROF.setTopSuppr("N");
			refSSclassPROF.setLibSsClassCli("PROFESSIONNELS");
			refSSclassPROF.setCodClassCli("RET");
			refSSclassPROF.setCodSsClassCli("RETPRO");
			RefCliSsClass refSSclassCORP = new RefCliSsClass();
			refSSclassCORP.setCodTypNot("CORP");
			refSSclassCORP.setTopSuppr("N");
			refSSclassCORP.setLibSsClassCli("ENTITES DU SECTEUR PUBLIC");
			refSSclassCORP.setCodClassCli("COR");
			refSSclassCORP.setCodSsClassCli("COR010");
			RefCliSsClass refClassSsClassRCFF = new RefCliSsClass();
			refClassSsClassRCFF.setCodSsClassCli("RETCFF");
			refClassSsClassRCFF.setLibSsClassCli("PARTICULIERS CFF");
			refClassSsClassRCFF.setCodClassCli("RET");
			refClassSsClassRCFF.setTopSuppr("N");
			refClassSsClassRCFF.setCodTypNot("RCFF");

			getEntityManager().persist(refClassSsClassRCFF);
			getEntityManager().persist(refSSclassPROF);
			getEntityManager().persist(refSSclassCORP);
		});

		String nomFichier = "NDOD_EVT_DELTA_10807_RCT_190224-180006.txt";
		importFile(nomFichier);

		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(3, tousTiers.size());
			for (Tiers tiers : tousTiers) {
				Assert.assertEquals(1, tiers.getIdentites().size());
				IdentiteTiers identite = tiers.getIdentites().iterator().next();
				if (identite.getIdLocal().equals("clio") || identite.getIdLocal().equals("bmw")) {
					Assert.assertEquals("3120", identite.getCodeSegment());
					Assert.assertNull(tiers.getIdFederal());
				} else {
					Assert.assertEquals("3200", identite.getCodeSegment());
					Assert.assertEquals("0000003555", tiers.getIdFederal());
				}
			}

		});

		String nomFichier2 = "NDOD_EVT_DELTA_10807_RCT_190224-180007.txt";
		importFile(nomFichier2);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(3, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				if (tiers.getIdFederal() != null && tiers.getIdFederal().equals("0000004500")) {
					Assert.assertEquals(2, tiers.getIdentites().size());
					for (IdentiteTiers identiteTiers : tiers.getIdentites()) {
						Assert.assertEquals("bmw", identiteTiers.getIdLocal());
						if (identiteTiers.getCodeSegment().equals("3120")) {
							Assert.assertNotNull(identiteTiers.getDateFin());
							Assert.assertNotNull(identiteTiers.getSuivante());
						} else {
							Assert.assertNull(identiteTiers.getDateFin());
							Assert.assertNull(identiteTiers.getSuivante());
							Assert.assertEquals("3200", identiteTiers.getCodeSegment());
						}
					}
				} else if (tiers.getIdFederal() != null && tiers.getIdFederal().equals("0000003555")) {
					Assert.assertEquals(1, tiers.getIdentites().size());
					Assert.assertEquals("3200", tiers.getIdentites().iterator().next().getCodeSegment());
					Assert.assertEquals("mercedes", tiers.getIdentites().iterator().next().getIdLocal());
				}
			}

		});


	}

	@Test
	public void changementSegmentHorsRetailARetail() {

		doInTransaction(() -> {

			TiersRFT tiersRFTMercedes = new TiersRFT("10807", "mercedes", "0000003555", "002220500",
					LocalDate.of(2019, 2, 1));
			TiersRFT tiersRFTBMW = new TiersRFT("10807", "bmw", "0000004500", "002220501", LocalDate.of(2019, 2, 1));
			TiersRFT tiersRFTCLIO = new TiersRFT("10807", "clio", "0000003555", "002220500", LocalDate.of(2019, 2, 1));

			getEntityManager().persist(tiersRFTMercedes);
			getEntityManager().persist(tiersRFTBMW);
			getEntityManager().persist(tiersRFTCLIO);
			RefCliSsClass refSSclassPROF = new RefCliSsClass();
			refSSclassPROF.setCodTypNot("PROF");
			refSSclassPROF.setTopSuppr("N");
			refSSclassPROF.setLibSsClassCli("PROFESSIONNELS");
			refSSclassPROF.setCodClassCli("RET");
			refSSclassPROF.setCodSsClassCli("RETPRO");
			RefCliSsClass refSSclassCORP = new RefCliSsClass();
			refSSclassCORP.setCodTypNot("CORP");
			refSSclassCORP.setTopSuppr("N");
			refSSclassCORP.setLibSsClassCli("ENTITES DU SECTEUR PUBLIC");
			refSSclassCORP.setCodClassCli("COR");
			refSSclassCORP.setCodSsClassCli("COR010");

			getEntityManager().persist(refSSclassPROF);
			getEntityManager().persist(refSSclassCORP);
		});

		String nomFichier = "NDOD_EVT_DELTA_10807_RCT_190224-180003.txt";
		importFile(nomFichier);
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());
			Assert.assertNotNull(tousTiers.get(0).getIdFederal());
			Assert.assertEquals("0000003555", tousTiers.get(0).getIdFederal());
			for (IdentiteTiers identiteTiers : tousTiers.get(0).getIdentites()) {
				Assert.assertNull(identiteTiers.getDateFin());
				Assert.assertEquals("1100", identiteTiers.getCodeSegment());
				Assert.assertNull(identiteTiers.getSuivante());
				if (!"mercedes".equals(identiteTiers.getIdLocal()) && !"clio".equals(identiteTiers.getIdLocal())) {
					Assert.assertNotNull(null);
				}
			}

		});

		String nomFichier2 = "NDOD_EVT_DELTA_10807_RCT_190224-180004.txt";
		importFile(nomFichier2);

		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(2, tousTiers.size());

			for (Tiers tiers : tousTiers) {
				if (tiers.getIdFederal() != null) {
					Assert.assertEquals("0000003555", tiers.getIdFederal());
					Assert.assertEquals(2, tiers.getIdentites().size());
					for (IdentiteTiers identiteTiers : tousTiers.get(0).getIdentites()) {
						Assert.assertNotNull(identiteTiers.getIdLocal());
						Assert.assertEquals("1100", identiteTiers.getCodeSegment());
						if ("mercedes".equals(identiteTiers.getIdLocal())) {
							Assert.assertNotNull(identiteTiers.getDateFin());
							Assert.assertNotNull(identiteTiers.getSuivante());
						} else {
							Assert.assertNull(identiteTiers.getDateFin());
							Assert.assertNull(identiteTiers.getSuivante());
						}
					}
				} else {
					Assert.assertEquals(1, tiers.getIdentites().size());
					IdentiteTiers identite = tiers.getIdentites().iterator().next();
					Assert.assertEquals("mercedes", identite.getIdLocal());
					Assert.assertEquals("3120", identite.getCodeSegment());
					Assert.assertNull(identite.getDateFin());
					Assert.assertNull(identite.getSuivante());
				}
			}

		});

		String nomFichier3 = "NDOD_EVT_DELTA_10807_RCT_190224-180005.txt";
		importFile(nomFichier3);

		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier3);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(1, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());
			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(3, tousTiers.size());
			for (Tiers tiers : tousTiers) {
				if (tiers.getIdentites().size() == 3) {
					for (IdentiteTiers identiteTiers : tiers.getIdentites()) {
						if (identiteTiers.getIdLocal().equals("clio")
								&& "1100".equals(identiteTiers.getCodeSegment())) {
							Assert.assertNotNull(identiteTiers.getDateFin());
							Assert.assertNotNull(identiteTiers.getSuivante());
						} else if (identiteTiers.getIdLocal().equals("clio")
								&& "3120".equals(identiteTiers.getCodeSegment())) {
							Assert.assertNull(identiteTiers.getDateFin());
							Assert.assertNull(identiteTiers.getSuivante());
						} else {
							Assert.assertEquals("mercedes", identiteTiers.getIdLocal());
							Assert.assertEquals("1100", identiteTiers.getCodeSegment());
							Assert.assertNotNull(identiteTiers.getDateFin());
							Assert.assertNotNull(identiteTiers.getSuivante());
						}
					}
				} else if (tiers.getIdentites().size() == 1) {
					IdentiteTiers identite = tiers.getIdentites().iterator().next();
					Assert.assertEquals("mercedes", identite.getIdLocal());
					Assert.assertNull(identite.getDateFin());
				} else {
					Assert.assertNotNull(null);
				}
			}
		});
	}

	@Test
	public void changementSegmentTiersWithMultipleEvenements() {

		doInTransaction(() -> {
			RefCliSeg refCliSegProf = new RefCliSeg();
			refCliSegProf.setCodSegCli("3120");
			refCliSegProf.setCodSsClassCli("RETPRO");
			refCliSegProf.setTopSuppr("N");

			RefCliSsClass refSSclassPROF = new RefCliSsClass();
			refSSclassPROF.setCodTypNot("PROF");
			refSSclassPROF.setTopSuppr("N");
			refSSclassPROF.setLibSsClassCli("PROFESSIONNELS");
			refSSclassPROF.setCodClassCli("RET");
			refSSclassPROF.setCodSsClassCli("RETPRO");

			RefCliSeg refCliSegCorp = new RefCliSeg();
			refCliSegCorp.setCodSegCli("1010");
			refCliSegCorp.setCodSsClassCli("COR010");
			refCliSegCorp.setTopSuppr("N");

			RefCliSsClass refSSclassCORP = new RefCliSsClass();
			refSSclassCORP.setCodTypNot("CORP");
			refSSclassCORP.setTopSuppr("N");
			refSSclassCORP.setLibSsClassCli("ENTITES DU SECTEUR PUBLIC");
			refSSclassCORP.setCodClassCli("COR");
			refSSclassCORP.setCodSsClassCli("COR010");

			getEntityManager().persist(refCliSegProf);
			getEntityManager().persist(refCliSegCorp);
			getEntityManager().persist(refSSclassPROF);
			getEntityManager().persist(refSSclassCORP);
		});

		String nomFichier = "NDOD_EVT_DELTA_10807_RCT_200103-180000.txt";
		importFile(nomFichier);

		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Assert.assertEquals(1, tiers.getIdentites().size());

			for (IdentiteTiers ident : tiers.getIdentites()) {
				Assert.assertNull(ident.getDateFin());
				Assert.assertEquals("3120", ident.getCodeSegment());
				List<Evenement> evts = findEvenementByIdentiteTiers(ident.getId());
				Assert.assertEquals(3, evts.size());
			}
		});

		String nomFichier2 = "NDOD_EVT_DELTA_10807_RCT_200103-180001.txt";
		importFile(nomFichier2);

		doInTransaction(() -> {
			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Assert.assertEquals(2, tiers.getIdentites().size());
			for (IdentiteTiers ident : tiers.getIdentites()) {
				if (ident.getDateFin() == null) {
					Assert.assertEquals("1010", ident.getCodeSegment());
					List<Evenement> evts = findEvenementByIdentiteTiers(ident.getId());
					Assert.assertEquals(0, evts.size());
				} else {
					Assert.assertNotNull(ident.getSuivante());
					Assert.assertEquals("3120", ident.getCodeSegment());
					List<Evenement> evts = findEvenementByIdentiteTiers(ident.getId());
					Assert.assertEquals(3, evts.size());
				}
			}
		});
	}
}
