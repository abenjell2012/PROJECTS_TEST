package fr.bpce.yyd.batch;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;

public class TestsIntegrationTiersUnique extends AbstractIntegrationTest {

	@Before
	public void setUp() {
		doInTransaction(() -> {
			insertDateCalculCourante(LocalDate.now().minusDays(1));
		});
	}

	@Test
	public void miseAJourEvtAvec2EvtsDeMemeIdProvenantDe2SIDifferents() {
		// Arrange - On crée le tiers unique manuellement.
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id1 = new IdentiteTiers();
			id1.setCodeBanque("10107");
			id1.setIdLocal("ID-TIERS-LOCAL-0001");
			id1.setCodeSegment("1100");
			id1.setSiren("123456789");
			id1.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id1);

			IdentiteTiers id2 = new IdentiteTiers();
			id2.setCodeBanque("10807");
			id2.setIdLocal("ID-TIERS-LOCAL-0002");
			id2.setCodeSegment(id1.getCodeSegment());
			id2.setSiren(id1.getSiren());
			id2.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id2);

			getEntityManager().persist(tiers);
		});

		// Act - Intégration des deux événements de même ID provenant de 2 SI différents
		// Les événements ont des codes différents.
		// La dernière ligne du fichier met à jour l'événement relatif à l'ID 1, banque
		// 10107.
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-190000.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(3, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();

			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}
			Assert.assertEquals(2, identites.size());
			Assert.assertEquals(2, evenements.size());

			for (Evenement evt : evenements) {
				IdentiteTiers identiteInitiale = evt.getIdentiteInitiale();
				Collection<ComplementEvenement> complements = evt.getComplements();
				if ("10107".equals(identiteInitiale.getCodeBanque())) {
					Assert.assertEquals(2, complements.size());
				}
				if ("10807".equals(identiteInitiale.getCodeBanque())) {
					Assert.assertEquals(1, complements.size());
				}
			}
		});
	}

	@Test
	public void miseAJourEvtAvec2EvtsDeMemeIdProvenantDe2SIDifferentsEtUneFusion() {
		// Arrange - On crée le tiers unique manuellement.
		doInTransaction(() -> {
			Tiers tiers = new Tiers();

			IdentiteTiers id1 = new IdentiteTiers();
			id1.setCodeBanque("10107");
			id1.setIdLocal("ID-TIERS-LOCAL-0001");
			id1.setCodeSegment("1100");
			id1.setSiren("123456789");
			id1.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id1);

			IdentiteTiers id2 = new IdentiteTiers();
			id2.setCodeBanque("10807");
			id2.setIdLocal("ID-TIERS-LOCAL-0002");
			id2.setCodeSegment(id1.getCodeSegment());
			id2.setSiren(id1.getSiren());
			id2.setDateDebut(LocalDate.of(2018, 12, 1));
			tiers.addIdentite(id2);

			getEntityManager().persist(tiers);
		});

		// Arrange - Intégration des deux événements de même ID provenant de 2 SI
		// différents.
		String nomFichier1 = "NDOD_EVT_DELTA_10107_RCT_190224-190010.txt";
		importFile(nomFichier1);

		// Arrange - Fusion sur l'identitée 10107, qui devient 17515, avec changement de
		// l'idTiersLocal
		doInTransaction(() -> {
			List<Tiers> tousTiers = findAllTiers();
			Tiers tiers = tousTiers.get(0);

			for (IdentiteTiers id : tiers.getIdentites()) {
				if ("10107".equals(id.getCodeBanque())) {
					IdentiteTiers idFusion = new IdentiteTiers();
					idFusion.setCodeBanque("17515");
					idFusion.setIdLocal("ID-TIERS-LOCAL-0010");
					idFusion.setCodeSegment(id.getCodeSegment());
					idFusion.setSiren(id.getSiren());
					idFusion.setDateDebut(LocalDate.of(2018, 12, 3));
					tiers.addIdentite(idFusion);

					getEntityManager().persist(idFusion);
					id.setDateFin(idFusion.getDateDebut());
					id.setSuivante(idFusion);

					break;
				}
			}
		});

		// Act - Intégration d'un événement de mise à jour de celui sur la banque qui a
		// fusionné.
		String nomFichier2 = "NDOD_EVT_DELTA_10107_RCT_190224-190011.txt";
		importFile(nomFichier2);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier1 = findAuditFichierByNomFichier(nomFichier1);
			Assert.assertNotNull(fichier1);
			Assert.assertEquals(Controles.FICOK, fichier1.getCodAudit());
			Assert.assertEquals(2, fichier1.getNbLignes());
			Assert.assertEquals(0, fichier1.getNbLignesRejet());

			AuditFichiers fichier2 = findAuditFichierByNomFichier(nomFichier2);
			Assert.assertNotNull(fichier2);
			Assert.assertEquals(Controles.FICOK, fichier2.getCodAudit());
			Assert.assertEquals(1, fichier2.getNbLignes());
			Assert.assertEquals(0, fichier2.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(3, identites.size());
			Assert.assertEquals(3, evenements.size());

			for (Evenement evt : evenements) {
				IdentiteTiers identiteInitiale = evt.getIdentiteInitiale();
				Collection<ComplementEvenement> complements = evt.getComplements();
				if ("10107".equals(identiteInitiale.getCodeBanque())) {
					Assert.assertEquals(1, complements.size());
				}
				if ("10807".equals(identiteInitiale.getCodeBanque())) {
					Assert.assertEquals(1, complements.size());
				}
				if ("17515".equals(identiteInitiale.getCodeBanque())) {
					Assert.assertEquals(1, complements.size());
				}
			}
		});
	}

	@Test
	public void creationTiersUniqueAvec2EvtsProvenantDe2SIDifferents() {
		// Arrange - On crée le tiers unique manuellement.
		final String idFederal = "0123456789";
		doInTransaction(() -> {
			TiersRFT tiersRft1 = new TiersRFT();
			tiersRft1.setCodeBanque("10107");
			tiersRft1.setIdLocal("ID-TIERS-LOCAL-0001");
			tiersRft1.setSiren("123456789");
			tiersRft1.setIdFederal(idFederal);
			tiersRft1.setDate(LocalDate.of(2018, 12, 1));

			TiersRFT tiersRft2 = new TiersRFT();
			tiersRft2.setCodeBanque("10807");
			tiersRft2.setIdLocal("ID-TIERS-LOCAL-0002");
			tiersRft2.setSiren("123456789");
			tiersRft2.setIdFederal(idFederal);
			tiersRft2.setDate(LocalDate.of(2018, 12, 1));

			// Doublon du 2
			TiersRFT tiersRft3 = new TiersRFT();
			tiersRft3.setCodeBanque("10807");
			tiersRft3.setIdLocal("ID-TIERS-LOCAL-0002");
			tiersRft3.setSiren("123456789");
			tiersRft3.setIdFederal(idFederal);
			tiersRft3.setDate(LocalDate.of(2018, 12, 1));

			getEntityManager().persist(tiersRft1);
			getEntityManager().persist(tiersRft2);
			getEntityManager().persist(tiersRft3);
		});

		// Act - Intégration des deux événements provenant de 2 SI différents. RFT nous
		// dit qu'il s'agit d'un tiers unique.
		// Le fichier ne contient pas des SIREN.
		String nomFichier = "NDOD_EVT_DELTA_10107_RCT_190224-190020.txt";
		importFile(nomFichier);

		// Assert
		doInTransaction(() -> {

			AuditFichiers fichier = findAuditFichierByNomFichier(nomFichier);
			Assert.assertNotNull(fichier);
			Assert.assertEquals(Controles.FICOK, fichier.getCodAudit());
			Assert.assertEquals(2, fichier.getNbLignes());
			Assert.assertEquals(0, fichier.getNbLignesRejet());

			List<Tiers> tousTiers = findAllTiers();
			Assert.assertEquals(1, tousTiers.size());

			Tiers tiers = tousTiers.get(0);
			Assert.assertEquals(idFederal, tiers.getIdFederal());
			Collection<IdentiteTiers> identites = tiers.getIdentites();
			Collection<Evenement> evenements = new ArrayList<>();
			for (IdentiteTiers identite : identites) {
				evenements.addAll(findEvenementByIdentiteTiers(identite.getId()));
			}

			Assert.assertEquals(2, identites.size());
			Assert.assertEquals(2, evenements.size());
		});
	}
}
