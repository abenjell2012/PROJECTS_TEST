package fr.bpce.yyd.batch.calcul_tiers.tasks;

import java.util.Arrays;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.commun.messages.ProducteurMessages;
import fr.bpce.yyd.batch.commun.messages.Topic;
import fr.bpce.yyd.batch.messages.dto.LotIdTiersDTO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CalculTiersTasklet implements Tasklet {

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		String idsTiersStr = (String) chunkContext.getStepContext().getJobParameters().get("idsTiers");
		List<String> items = Arrays.asList(idsTiersStr.split(","));
		Long guid = (Long) chunkContext.getStepContext().getJobParameters().get("guid");
		String topicNameCalculListe;
		try {
			topicNameCalculListe = ConfigManager.getProperty("kafka.topic.calcul_liste");

			LotIdTiersDTO lotIds = new LotIdTiersDTO();
			lotIds.setGuid(guid);
			for (String idTiersStr : items) {
				Long idTiers = Long.valueOf(idTiersStr);
				lotIds.addIdTiers(idTiers);
			}
			envoieLotIds(lotIds, Topic.CALCUL_LISTE, topicNameCalculListe);
		} catch (Exception e) {
			log.error("Erreur inattendue : " + e.getMessage(), e);
		}
		return RepeatStatus.FINISHED;
	}

	private void envoieLotIds(LotIdTiersDTO lotIds, Topic topic, String name) {
		if (!lotIds.getIdsTiers().isEmpty()) {
			ProducteurMessages producteur = MessagesFactory.getProducteur();
			producteur.envoieMessage(topic, name, lotIds);
			lotIds.getIdsTiers().clear();
		}
	}
}
