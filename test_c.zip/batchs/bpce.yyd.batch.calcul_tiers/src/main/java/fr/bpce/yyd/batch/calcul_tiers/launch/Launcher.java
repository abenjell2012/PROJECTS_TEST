package fr.bpce.yyd.batch.calcul_tiers.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Launcher {
	private static ApplicationContext context = null;

	private static String logFile = "log4j-calcul-tiers.properties";
	private static boolean isTest;
	private static boolean traitementOk;

	public static void setLogFile(String log) {
		logFile = log;
	}

	public static void setIsTest(boolean test) {
		isTest = test;
	}

	public static void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public static ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public static String getLogFile() {
		return logFile;
	}

	public static boolean isTest() {
		return isTest;
	}

	public static boolean isTraitementOk() {
		return traitementOk;
	}

	public static void setTraitementOk(boolean traitementOk) {
		Launcher.traitementOk = traitementOk;
	}

	public void runBatch(String[] tiers) {

		log.info("Debut BATCH NDOD : CALCUL TIERS");

		try {
			Job job = (Job) getApplicationContext().getBean(Constant.JOB_CALCUL_TIERS);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");
			launchSpringBatchJob(tiers, job, jobLauncher);
		} catch (Exception err) {
			log.error("Erreur inattendue : " + err.getMessage(), err);
			exitWithErrorCode(1);
		}
		log.info("Fin BATCH NDOD : CALCUL TIERS");

	}

	private void launchSpringBatchJob(String[] tiers, Job job, JobLauncher jobLauncher) {
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobExecution execution = null;
		JobParameters jobParameters = new JobParametersBuilder().addString("idsTiers", String.join(",", tiers))
				.addLong("guid", guid).toJobParameters();
		try {
			execution = jobLauncher.run(job, jobParameters);
		} catch (Exception err) {
			log.error("Erreur inattendue : " + err.getMessage(), err);
			exitWithErrorCode(1);
		} finally {
			if (!isTest()) {
				finaliserTraitement(batchStatus(execution));
			}
		}
	}

	public static void main(String[] args) {
		if (args.length > 0) {
			PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource(getLogFile()));
			Launcher launcher = new Launcher();
			launcher.runBatch(args);
			traitementOk = true;
		} else {
			log.info("Fin BATCH NDOD : liste des tiers a traiter vide");
			exitWithErrorCode(0);
		}
	}

}
