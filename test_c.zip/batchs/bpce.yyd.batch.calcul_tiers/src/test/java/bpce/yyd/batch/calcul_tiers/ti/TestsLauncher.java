package bpce.yyd.batch.calcul_tiers.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.Properties;

import javax.persistence.EntityManager;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import fr.bpce.yyd.batch.calcul_tiers.launch.Launcher;
import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.messages.kafka.ProducteurMessagesKafka;

@RunWith(PowerMockRunner.class)
@PrepareForTest(value = { MessagesFactory.class })
@PowerMockIgnore("javax.management.*")
public class TestsLauncher {

	private static ApplicationContext context = null;
	protected static TransactionTemplate transactionTemplate = null;

	@FunctionalInterface
	public interface TransactionCallback {
		void doInTransaction();
	}

	@BeforeClass
	public static void initSpring() throws IOException, NoSuchFieldException, SecurityException,
			IllegalArgumentException, IllegalAccessException {
		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		transactionTemplate = new TransactionTemplate(getTransactionManager());
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		Properties properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);

		Launcher.setApplicationContext(context);
		Launcher.setIsTest(true);
		Launcher.setLogFile("log4j.properties");
	}

	public static ApplicationContext getContext() {
		return context;
	}

	@Test
	public void launchOK() {
		JobExecution jobExec = null;
		// simuler envoi kafka
		ProducteurMessagesKafka producteur = Mockito.mock(ProducteurMessagesKafka.class);
		Mockito.doNothing().when(producteur).envoieMessage(Mockito.any(), Mockito.anyString(), Mockito.anyList());
		// Mock producteur kafka
		PowerMockito.mockStatic(MessagesFactory.class);
		PowerMockito.doReturn(producteur).when(MessagesFactory.class);
		MessagesFactory.getProducteur();

		String[] tiers = { "1", "2", "3" };

		try {
			jobExec = lauchBatch(tiers);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(jobExec);
		assertEquals(ExitStatus.COMPLETED, jobExec.getExitStatus());
	}

	@Test
	public void launcherMain() {
		// simuler envoi kafka
		ProducteurMessagesKafka producteur = Mockito.mock(ProducteurMessagesKafka.class);
		Mockito.doNothing().when(producteur).envoieMessage(Mockito.any(), Mockito.anyString(), Mockito.anyList());
		// Mock producteur kafka
		PowerMockito.mockStatic(MessagesFactory.class);
		PowerMockito.doReturn(producteur).when(MessagesFactory.class);
		MessagesFactory.getProducteur();

		String[] tiers = { "1", "2", "3" };
		Launcher.main(tiers);
		assertTrue(Launcher.isTraitementOk());
	}

	public static void doInTransaction(final TransactionCallback checker) {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				checker.doInTransaction();
			}
		});
	}

	public static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	public static EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	public JobExecution lauchBatch(String[] tiers) throws Exception {
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		Job job = (Job) context.getBean(Constant.JOB_CALCUL_TIERS);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		JobParameters jobParameters = new JobParametersBuilder().addString("idsTiers", String.join(",", tiers))
				.addLong("guid", guid).toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}
}
