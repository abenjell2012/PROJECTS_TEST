package fr.bpce.yyd.batch.flux_mensuel_part.writer;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.core.io.FileSystemResource;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import fr.bpce.yyd.batch.commun.beans.DetailTiersInfo;
import fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils;

public class DetailTiersInfoFileWriter extends FlatFileItemWriter<DetailTiersInfo> {

	private static final String NB_LIGNES_TIERS = "NB_LIGNES_TIERS";

	private static final Logger LOG_GER = Logger.getLogger(DetailTiersInfoFileWriter.class);

	private static final String PATTERN_FICHIER_OUT = "NDOD_REST_{0}_TIERS_{1}_{2}_{3}.txt";
	private String typeFic;
	private String repertoireRestit;
	private String codeBanque;
	private String environnement;
	private StepExecution stepExecution;
	private String filePath;

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(codeBanque, "codeBanque must not be null");
		Assert.notNull(environnement, "environnement must not be null");
		Assert.notNull(repertoireRestit, "repertoireRestit must not be null");

		filePath = repertoireRestit + "tiers/"
				+ RestitSyntheseUtils.generateFileName(PATTERN_FICHIER_OUT, typeFic, codeBanque, environnement);
		LOG_GER.info("Fichier à générer " + filePath);

		super.setResource(new FileSystemResource(new File(filePath)));
		super.afterPropertiesSet();

	}

	@Override
	public synchronized void write(List<? extends DetailTiersInfo> items) throws Exception {
		if (!CollectionUtils.isEmpty(items)) {
			LOG_GER.info("CodeBanque " + codeBanque + " | Ecriture de " + items.size() + " ligne(s) DetailTiersInfo");
			super.write(items);
			Long nbLignesCourant = (Long) this.stepExecution.getExecutionContext().get(NB_LIGNES_TIERS);
			this.stepExecution.getExecutionContext().put(NB_LIGNES_TIERS, nbLignesCourant + items.size());

		}

	}

	public void setRepertoireRestit(String repertoireRestit) {
		this.repertoireRestit = repertoireRestit;
	}

	public void setCodeBanque(String codeBanque) {
		this.codeBanque = codeBanque;
	}

	public void setEnvironnement(String environnement) {
		this.environnement = environnement;
	}

	public void setTypeFic(String typeFic) {
		this.typeFic = typeFic;
	}

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		stepExecution.getExecutionContext().put(NB_LIGNES_TIERS, 0L);
		this.stepExecution = stepExecution;

	}

	@AfterStep
	public ExitStatus afterStep(StepExecution stepExecution) {
		stepExecution.getExecutionContext().put("tiersFichier", filePath);
		return stepExecution.getExitStatus();

	}

}
