package fr.bpce.yyd.batch.flux_mensuel_part.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;

public class Launcher {

	private static final Logger LOGGER = Logger.getLogger(Launcher.class);

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public void runBatch(String dateStr, String typeFic) {

		JobExecution execution = null;

		try {
			LOGGER.info("Debut BATCH " + Constant.JOB_FLUX_MENSUEL);

			Job job = (Job) getApplicationContext().getBean(Constant.JOB_FLUX_MENSUEL);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

			LocalDate dar = null;
			if (dateStr != null) {
				dar = LocalDate.parse(dateStr, DateTimeFormatter.BASIC_ISO_DATE);
			} else {
				dar = LocalDate.now();
			}

			String env = ConfigManager.getProperty("env");
			String repRestitOut = ConfigManager.getProperty("flux_mensuel.rep.out");
			String repRestitOutTmp = ConfigManager.getProperty("flux_mensuel.rep.out.tmp");
			String repRestitOutBdp = ConfigManager.getProperty("flux_mensuel.rep.out.bdp");
			FileCommunUtils.checkRepertoire(repRestitOutTmp + "events");
			FileCommunUtils.checkRepertoire(repRestitOutTmp + "tiers");

			FileCommunUtils.checkRepertoire(repRestitOut);

			FileCommunUtils.checkRepertoire(repRestitOutBdp);


			JobParameters jobParameters = new JobParametersBuilder().addString("repRestitOut", repRestitOut)
					.addString("repRestitOutTmp", repRestitOutTmp)
					.addString("repRestitOutBdp", repRestitOutBdp)
					.addString("env", env).addString("dar", dar.format(DateTimeFormatter.BASIC_ISO_DATE))
					.addString("typeFic", typeFic).addDate("date", java.sql.Date.valueOf(dar))
					.addLong("id", new Date().getTime()).toJobParameters();
			execution = jobLauncher.run(job, jobParameters);

		} catch (Exception err) {
			LOGGER.error("Erreur inattendue : " + err.getMessage(), err);
			exitWithErrorCode(1);
		} finally {
			finaliserTraitement(batchStatus(execution));
		}
	}

	public static void main(String[] args) {

		PropertyConfigurator.configure(
				ClassLoader.getSystemClassLoader().getResource("log4j-synthese-flux-mensuel-part.properties"));
		Launcher launcher = new Launcher();
		String dateParam = null;
		String typeFic = null;

		if (args == null || args.length < 1) {
			LOGGER.error("L'argument type de fichier(MENS,INIT) est obligatoire");
			exitWithErrorCode(1);
		} else if (args.length > 2) {
			LOGGER.error("Le nombre d'arguments est de 2 (MENS/INIT et dar)");
			exitWithErrorCode(1);
		}
		if (args != null) {
			if (args[0].equals("MENS") || args[0].equals("INIT")) {
				typeFic = args[0];
			} else {
				LOGGER.info("Le type de fichier doit être égal à MENS ou INIT");
				exitWithErrorCode(1);
			}
			if (args.length == 2) {
				String date = args[1];
				try {
					LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
					dateParam = date; // Le format est bon
				} catch (DateTimeParseException dtpe) {
					LOGGER.error("Erreur le format de la date passe en parametre est incorrect " + args[1]);
					exitWithErrorCode(1);
				}
			}
		}
		launcher.runBatch(dateParam, typeFic);
	}
}