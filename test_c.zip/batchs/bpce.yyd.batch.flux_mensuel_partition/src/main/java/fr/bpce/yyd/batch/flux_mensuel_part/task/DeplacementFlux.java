package fr.bpce.yyd.batch.flux_mensuel_part.task;


import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.util.FileSystemUtils;
import java.io.File;


@Slf4j
@Setter
public class DeplacementFlux implements Tasklet {

    private String repertoireRestitTmp = null;
    private String repertoireRestitBdp = null;
    private String repertoireRestit = null;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        File src = new File(repertoireRestitTmp);
        File dest = new File(repertoireRestit);
        File destBdp = new File(repertoireRestitBdp);
        try {
            FileSystemUtils.copyRecursively(src, dest);

            FileSystemUtils.copyRecursively(src, destBdp);

            FileSystemUtils.deleteRecursively(src);
        }catch (Exception e){
           log.error("Erreur lors du deplacement des Flux");
        }
        return RepeatStatus.FINISHED;
    }


}