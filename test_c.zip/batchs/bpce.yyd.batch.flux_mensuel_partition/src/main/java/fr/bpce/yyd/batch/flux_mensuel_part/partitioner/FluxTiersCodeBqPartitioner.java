package fr.bpce.yyd.batch.flux_mensuel_part.partitioner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;

import fr.bpce.yyd.commun.constantes.Constant;

public class FluxTiersCodeBqPartitioner implements Partitioner {

	private static final Logger LOGGER = Logger.getLogger(FluxTiersCodeBqPartitioner.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private String datePhoto;

	private static final String QUERY_COD_BQ = "select distinct code_banque from REST_TIERS_ID_LOCAL";
	private static final String LISTE_CODE_BQ_MOTIF_SDA = "select valeur_param from par_mdc_seg where code_param = 'LISTE_CODE_BQ_MOTIF_SDA'";

	@Override
	public Map<String, ExecutionContext> partition(int gridSize) {

		List<String> codeBqList = jdbcTemplate.queryForList(QUERY_COD_BQ, String.class);
		List<String> paramCodeBqSda = jdbcTemplate.queryForList(LISTE_CODE_BQ_MOTIF_SDA, String.class);

		List<String> codeBqSda = new ArrayList<>();
		if (!paramCodeBqSda.isEmpty()) {
			String[] codeBqSdaTab = paramCodeBqSda.get(0).split(Constant.SEP_VIRGULE);
			codeBqSda = Arrays.asList(codeBqSdaTab);
		}

		Map<String, ExecutionContext> result = new HashMap<>();

		if (!CollectionUtils.isEmpty(codeBqList)) {
			for (String codeBanque : codeBqList) {
				ExecutionContext executionContext = new ExecutionContext();
				executionContext.putString("codeBanque", codeBanque);
				executionContext.putString("codeBanqueForSDA",
						codeBqSda.contains(codeBanque) ? Constant.MOTIF_SDA_OUI : Constant.MOTIF_SDA_NON);
				result.put("codeBanque " + codeBanque, executionContext);
			}

		} else {
			LOGGER.warn("L'extraction des donnees tiers n'est faite pour aucun établissement");
		}

		return result;

	}

	public String getDatePhoto() {
		return datePhoto;
	}

	public void setDatePhoto(String datePhoto) {
		this.datePhoto = datePhoto;
	}

}
