package fr.bpce.yyd.batch.flux_mensuel_part.aggregator;

import org.springframework.batch.item.file.transform.LineAggregator;

import fr.bpce.yyd.batch.commun.beans.DataEvenement;
import fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils;

public class DetailEvtsFixedLengthLineAgregator implements LineAggregator<DataEvenement> {

	@Override
	public String aggregate(DataEvenement item) {
		return RestitSyntheseUtils.generateDetailFicEvents(item);
	}

}
