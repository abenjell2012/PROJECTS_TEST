package fr.bpce.yyd.batch.flux_mensuel_part.task;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Setter
public class CompressionFluxTask implements Tasklet {

	private String cleFichier;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		Collection<StepExecution> stepExecutions = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getStepExecutions();
		for (StepExecution stepExecution : stepExecutions) {
			if (stepExecution.getExecutionContext().containsKey(cleFichier)
					&& ExitStatus.COMPLETED.equals(stepExecution.getExitStatus())) {
				String fileName = stepExecution.getExecutionContext().getString(cleFichier);
				Path filePath = Paths.get(fileName);
				if (filePath.toFile().exists()) {
					log.info("compression " + fileName);
					FileCommunUtils.compressToGZIP(fileName, fileName + ".gz");
					Files.delete(filePath);
				}
			}
		}

		return RepeatStatus.FINISHED;
	}

}