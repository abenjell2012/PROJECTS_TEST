package bpce.yyd.batch.calcul_after_notif.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import javax.persistence.EntityManager;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import fr.bpce.yyd.batch.calcul.launch.Launcher;
import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.messages.kafka.ProducteurMessagesKafka;
import fr.bpce.yyd.commun.enums.CodeParamMdc;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ParMdcBqSeg;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;

@RunWith(PowerMockRunner.class)
@PrepareForTest(value = { MessagesFactory.class })
@PowerMockIgnore("javax.management.*")
public class TestsLauncher {
	private static ApplicationContext context = null;
	protected static TransactionTemplate transactionTemplate = null;

	@FunctionalInterface
	public interface TransactionCallback {
		void doInTransaction();
	}

	@BeforeClass
	public static void initSpring() throws IOException, NoSuchFieldException, SecurityException,
			IllegalArgumentException, IllegalAccessException {
		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		transactionTemplate = new TransactionTemplate(getTransactionManager());
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		Properties properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);
		initData();

		Launcher.setApplicationContext(context);
		Launcher.setIsTest(true);
		Launcher.setLogFile("log4j.properties");
	}

	public static ApplicationContext getContext() {
		return context;
	}

	@Test
	public void launchOK() {
		JobExecution jobExec = null;
		// simuler envoi kafka
		ProducteurMessagesKafka producteur = Mockito.mock(ProducteurMessagesKafka.class);
		Mockito.doNothing().when(producteur).envoieMessage(Mockito.any(), Mockito.anyString(), Mockito.anyList());
		// Mock producteur kafka
		PowerMockito.mockStatic(MessagesFactory.class);
		PowerMockito.doReturn(producteur).when(MessagesFactory.class);
		MessagesFactory.getProducteur();

		try {
			jobExec = lauchBatch();
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(jobExec);
		assertEquals(ExitStatus.COMPLETED, jobExec.getExitStatus());
	}

	@Test
	public void launcherMain() {
		// simuler envoi kafka
		ProducteurMessagesKafka producteur = Mockito.mock(ProducteurMessagesKafka.class);
		Mockito.doNothing().when(producteur).envoieMessage(Mockito.any(), Mockito.anyString(), Mockito.anyList());
		// Mock producteur kafka
		PowerMockito.mockStatic(MessagesFactory.class);
		PowerMockito.doReturn(producteur).when(MessagesFactory.class);
		MessagesFactory.getProducteur();

		Launcher.main(null);
		assertTrue(Launcher.isTraitementOk());
	}

	private static void initData() {
		doInTransaction(() -> {
			AuditFichiers af = new AuditFichiers();
			getEntityManager().persist(af);

			Tiers tiers = new Tiers();
			getEntityManager().persist(tiers);

			IdentiteTiers ident = new IdentiteTiers();
			ident.setTiers(tiers);
			ident.setIdLocal("idLocal");
			ident.setCodeBanque("10107");
			ident.setCodeSegment("3210");
			ident.setDateDebut(LocalDate.now().minusDays(10));
			getEntityManager().persist(ident);

			Evenement evtImx = new Evenement();
			evtImx.setCode("IMX");
			evtImx.setDateDebut(LocalDate.now().minusDays(10));
			evtImx.setIdentiteInitiale(ident);
			getEntityManager().persist(evtImx);

			ComplementEvenement complImx = new ComplementEvenement();
			complImx.setAuditFichier(af);
			complImx.setIdentiteInitiale(ident);
			complImx.setEvenement(evtImx);
			complImx.setStatutEvt(StatutEvenement.ACT);
			complImx.setDateMaj(evtImx.getDateDebut());
			complImx.setDatePhoto(evtImx.getDateDebut());
			complImx.setArriereLitige(false);
			complImx.setArriereTech(false);
			complImx.setMiseAJour(false);
			complImx.setMontantArriere(BigDecimal.valueOf(10000l));
			getEntityManager().persist(complImx);

			RefCliSeg refSeg = new RefCliSeg();
			refSeg.setCodSegCli("3210");
			refSeg.setCodSsClassCli("RETPRO");
			refSeg.setTopSuppr("N");
			getEntityManager().persist(refSeg);

			RefCliSsClass refSsClass = new RefCliSsClass();
			refSsClass.setCodSsClassCli("RETPRO");
			refSsClass.setCodTypNot("PROF");
			refSsClass.setLibSsClassCli("Professionnel");
			refSsClass.setTopSuppr("N");
			getEntityManager().persist(refSsClass);

			ParMdcBqSeg paramSeuilAbsolu = new ParMdcBqSeg();
			paramSeuilAbsolu.setCodeParam(CodeParamMdc.SEUIL_EUR_RETAIL);
			paramSeuilAbsolu.setCodeSegment("*");
			paramSeuilAbsolu.setCodeBq("*");
			paramSeuilAbsolu.setDateDebut(LocalDate.of(2019, 01, 01));
			paramSeuilAbsolu.setValeurParam("100");
			getEntityManager().persist(paramSeuilAbsolu);

			ParMdcSeg paramDateCalculCourante = new ParMdcSeg();
			paramDateCalculCourante.setCodeParam(CodeParamMdc.DATE_CALCUL_COURANTE);
			paramDateCalculCourante.setCodeSegment("*");
			paramDateCalculCourante.setDateDebut(LocalDate.of(2019, 01, 01));
			paramDateCalculCourante.setValeurParam(LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE));
			getEntityManager().persist(paramDateCalculCourante);
		});
	}

	public static void doInTransaction(final TransactionCallback checker) {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				checker.doInTransaction();
			}
		});
	}

	public static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	public static EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	public JobExecution lauchBatch() throws Exception {
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		Job job = (Job) context.getBean(Constant.JOB_CALCUL);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		JobParameters jobParameters = new JobParametersBuilder()
				.addString("date", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
				.addLong("guid", guid).toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}
}
