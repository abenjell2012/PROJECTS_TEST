/*
 * YYD calcul_after_notif batch permettant de calculer les tiers illigibles après réception d'une notification
 * 02.09.2020 Copyright (c) 2020 BPCE. All Rights Reserved.
 * mailto:contact AT ndod@bpce.fr
 *
 * YYD calcul_after_notif is private software, Proprietary software licenses;
 * you cannot redistribute it and/or modify it.
 *
 * YYD calcul_after_notif is used in our compagny
 *
 */
package fr.bpce.yyd.batch.calcul.writer;

import java.time.LocalDate;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.commun.messages.ProducteurMessages;
import fr.bpce.yyd.batch.commun.messages.Topic;
import fr.bpce.yyd.batch.commun.repositories.ParMdcRepository;
import fr.bpce.yyd.batch.messages.dto.LotIdTiersDTO;

@Service
public class EnvoiTiersItemWriter implements ItemWriter<Long> {
	private static Logger logger = Logger.getLogger(EnvoiTiersItemWriter.class);

	private Long guid;

	@Autowired
	private ParMdcRepository parMdcRepo;

	private LocalDate dateCalcul;

	@BeforeStep
	public void initialize(StepExecution stepExecution) {
		dateCalcul = parMdcRepo.findDateCalculCourante();
	}

	@Override
	public void write(List<? extends Long> items) throws Exception {

		logger.info("Début d'envoi d'un message kafka");
		LotIdTiersDTO lotIds = new LotIdTiersDTO();
		lotIds.setDateCalcul(dateCalcul.plusDays(1));
		lotIds.getIdsTiers().addAll(items);
		lotIds.setGuid(guid);
		envoieLotIds(lotIds);
		logger.info("Fin d'envoi du message kafka");

	}

	private void envoieLotIds(LotIdTiersDTO lotIds) throws UnknownPropertyException, InvalidInitialisationException {
		if (!lotIds.getIdsTiers().isEmpty()) {
			String topicName = ConfigManager.getProperty("kafka.topic.calcul_liste");
			ProducteurMessages producteur = MessagesFactory.getProducteur();
			producteur.envoieMessage(Topic.CALCUL_LISTE, topicName, lotIds);
			// Réinitialisation
			lotIds.getIdsTiers().clear();
		}
	}

	public void setParamGuid(Long paramGuidl) {
		guid = paramGuidl;
	}

	public void setParMdcRepo(ParMdcRepository parMdcRepo) {
		this.parMdcRepo = parMdcRepo;
	}
}
