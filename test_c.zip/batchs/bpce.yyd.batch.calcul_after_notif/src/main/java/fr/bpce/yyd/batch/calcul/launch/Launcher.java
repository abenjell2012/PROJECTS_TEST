/*
 * YYD calcul_after_notif batch permettant de calculer les tiers illigibles après réception d'une notification
 * 02.09.2020 Copyright (c) 2020 BPCE. All Rights Reserved.
 * mailto:contact AT ndod@bpce.fr
 *
 * YYD calcul_after_notif is private software, Proprietary software licenses;
 * you cannot redistribute it and/or modify it.
 *
 * YYD calcul_after_notif is used in our compagny
 *
 */
package fr.bpce.yyd.batch.calcul.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.constantes.Constant;

public class Launcher {

	private static Logger logger = Logger.getLogger(Launcher.class);

	private static ApplicationContext context = null;

	private static String logFile = "log4j-calcul.properties";
	private static boolean isTest;
	private static boolean traitementOk;

	public static void setLogFile(String log) {
		logFile = log;
	}

	public static void setIsTest(boolean test) {
		isTest = test;
	}

	public static void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public static ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public static String getLogFile() {
		return logFile;
	}

	public static boolean isTest() {
		return isTest;
	}

	public static boolean isTraitementOk() {
		return traitementOk;
	}

	public static void setTraitementOk(boolean traitementOk) {
		Launcher.traitementOk = traitementOk;
	}

	public void runBatch() {

		try {
			logger.info("Debut BATCH CALCUL");

			Job job = (Job) getApplicationContext().getBean(Constant.JOB_CALCUL);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

			Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
			JobParameters jobParameters = new JobParametersBuilder()
					.addString("date", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
					.addLong("guid", guid).toJobParameters();
			runJob(job, jobLauncher, jobParameters);
		} catch (Exception err) {
			logger.error("Erreur inattendue pour le batch calcul " + err.getMessage(), err);
			exitWithErrorCode(1);
		}
	}

	private void runJob(Job job, JobLauncher jobLauncher, JobParameters jobParameters) {
		JobExecution execution = null;
		try {
			execution = jobLauncher.run(job, jobParameters);
		} catch (Exception e) {
			logger.error("Erreur: " + e.getMessage());
			exitWithErrorCode(1);
		} finally {
			if (!isTest()) {
				finaliserTraitement(batchStatus(execution));
			}
		}
	}

	public static void main(String[] args) {
		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource(getLogFile()));
		Launcher launcher = new Launcher();
		launcher.runBatch();
		traitementOk = true;
	}
}
