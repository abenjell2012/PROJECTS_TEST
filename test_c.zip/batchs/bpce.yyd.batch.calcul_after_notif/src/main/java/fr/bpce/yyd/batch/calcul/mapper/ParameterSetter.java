/*
 * YYD calcul_after_notif batch permettant de calculer les tiers illigibles après réception d'une notification
 * 02.09.2020 Copyright (c) 2020 BPCE. All Rights Reserved.
 * mailto:contact AT ndod@bpce.fr
 *
 * YYD calcul_after_notif is private software, Proprietary software licenses;
 * you cannot redistribute it and/or modify it.
 *
 * YYD calcul_after_notif is used in our compagny
 *
 */
package fr.bpce.yyd.batch.calcul.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.PreparedStatementSetter;

import fr.bpce.yyd.batch.commun.repositories.ParMdcRepository;

public class ParameterSetter implements PreparedStatementSetter {

	@Autowired
	private ParMdcRepository parMdcRepo;

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		// récupérer parametre DATE_CALCUL_COURANTE
		LocalDate dateCalcul = parMdcRepo.findDateCalculCourante();
		for (int i = 1; i < 6; i++) {
			ps.setDate(i, Date.valueOf(dateCalcul));
		}
	}

	public void setParMdcRepo(ParMdcRepository parMdcRepo) {
		this.parMdcRepo = parMdcRepo;
	}
}
