/*
 * YYD calcul_after_notif batch permettant de calculer les tiers illigibles après réception d'une notification
 * 02.09.2020 Copyright (c) 2020 BPCE. All Rights Reserved.
 * mailto:contact AT ndod@bpce.fr
 *
 * YYD calcul_after_notif is private software, Proprietary software licenses;
 * you cannot redistribute it and/or modify it.
 *
 * YYD calcul_after_notif is used in our compagny
 *
 */
package fr.bpce.yyd.batch.calcul.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CalculRowMapper implements RowMapper<Long> {

	@Override
	public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
		return rs.getLong(1);
	}
}
