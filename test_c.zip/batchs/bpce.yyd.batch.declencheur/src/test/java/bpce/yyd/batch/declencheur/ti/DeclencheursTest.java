package bpce.yyd.batch.declencheur.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.TypedQuery;

import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.*;
import fr.bpce.yyd.commun.model.reference.ParGravite;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;

public class DeclencheursTest extends AbstractTestIntegration {

	@Test
	public void testDeclencheurRFT() throws Exception {

		// ARRANGE
		doInTransaction(() -> {

			Tiers t1 = new Tiers();
			t1.setIdFederal("IDRFT1");
			IdentiteTiers id1 = new IdentiteTiers();
			id1.setCodeBanque("10107");
			id1.setIdLocal("IDLOC1");
			id1.setCodeSegment("1010");
			id1.setDateDebut(LocalDate.of(2015, 1, 3));
			t1.addIdentite(id1);
			getEntityManager().persist(t1);

			IdentiteTiers id2 = new IdentiteTiers();
			id2.setCodeBanque("10108");
			id2.setIdLocal("IDLOC2");
			id2.setCodeSegment("1010");
			id2.setDateDebut(LocalDate.of(2015, 1, 3));
			t1.addIdentite(id2);

			IdentiteTiers id3 = new IdentiteTiers();
			id3.setCodeBanque("10109");
			id3.setIdLocal("IDLOC3");
			id3.setCodeSegment("1010");
			id3.setDateDebut(LocalDate.of(2015, 1, 3));
			t1.addIdentite(id3);

			TiersRFT t1RFT = new TiersRFT();
			t1RFT.setCodeBanque("10107");
			t1RFT.setDate(LocalDate.of(2015, 1, 4));
			t1RFT.setIdLocal("IDLOC1");
			t1RFT.setIdFederal("IDRFT1");
			getEntityManager().persist(t1RFT);

			TiersRFT t2RFT = new TiersRFT();
			t2RFT.setCodeBanque("10108");
			t2RFT.setDate(LocalDate.of(2015, 1, 4));
			t2RFT.setIdLocal("IDLOC2");
			t2RFT.setIdFederal("IDRFT1");
			getEntityManager().persist(t2RFT);

			TiersRFT t3RFT = new TiersRFT();
			t3RFT.setCodeBanque("10109");
			t3RFT.setDate(LocalDate.of(2015, 1, 4));
			t3RFT.setIdLocal("IDLOC3");
			t3RFT.setIdFederal("IDRFT1");
			getEntityManager().persist(t3RFT);

			AuditFichiers auditFichiers = new AuditFichiers();
			auditFichiers.setDateAudit(Date.valueOf(LocalDate.of(2015, 1, 2)));
			getEntityManager().persist(auditFichiers);

			ComplementEvenement complementEvenementIMX = new ComplementEvenement();
			complementEvenementIMX.setDatePhoto(LocalDate.of(2015, 1, 5));
			complementEvenementIMX.setDateMaj(LocalDate.of(2015, 1, 5));
			complementEvenementIMX.setStatutEvt(StatutEvenement.ACT);
			complementEvenementIMX.setAuditFichier(auditFichiers);
			complementEvenementIMX.setMontantArriere(BigDecimal.valueOf(50));
			complementEvenementIMX.setArriereLitige(false);
			complementEvenementIMX.setArriereTech(false);
			complementEvenementIMX.setIdentiteInitiale(id1);

			Evenement evenementIMX = new Evenement();
			evenementIMX.setCode("IMX");
			evenementIMX.setDateDebut(LocalDate.of(2015, 1, 5));
			evenementIMX.setIdContrat("idContrat");
			evenementIMX.setIdentiteInitiale(id1);
			evenementIMX.addComplement(complementEvenementIMX);
			getEntityManager().persist(evenementIMX);

		});
		// ACT
		lauchBatchDeclencheur("20150106");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 6)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(3L, results.size());
		assertEquals("TOPA", results.get(0).getMotifDeclencheur());
		assertEquals("TOPA", results.get(1).getMotifDeclencheur());
		assertEquals("TOPA", results.get(2).getMotifDeclencheur());

	}

	@Test
	public void testDeclencheurRFTCA() throws Exception {

		// ARRANGE
		doInTransaction(() -> {

			Tiers t1 = new Tiers();
			t1.setIdFederal("IDRFT1");
			IdentiteTiers id1 = new IdentiteTiers();
			id1.setCodeBanque("10107");
			id1.setIdLocal("IDLOC1");
			id1.setCodeSegment("1010");
			id1.setDateDebut(LocalDate.of(2015, 1, 3));
			t1.addIdentite(id1);
			getEntityManager().persist(t1);

			TiersRFT t1RFT = new TiersRFT();
			t1RFT.setCodeBanque("10107");
			t1RFT.setDate(LocalDate.of(2015, 1, 4));
			t1RFT.setIdLocal("IDLOC1");
			t1RFT.setIdFederal("IDRFT1");
			getEntityManager().persist(t1RFT);

			TiersRFT t2RFT = new TiersRFT();
			t2RFT.setCodeBanque("10108");
			t2RFT.setDate(LocalDate.of(2015, 1, 4));
			t2RFT.setIdLocal("IDLOC2");
			t2RFT.setIdFederal("IDRFT1");
			getEntityManager().persist(t2RFT);

			TiersRFT t3RFT = new TiersRFT();
			t3RFT.setCodeBanque("10109");
			t3RFT.setDate(LocalDate.of(2015, 1, 4));
			t3RFT.setIdLocal("IDLOC3");
			t3RFT.setIdFederal("IDRFT1");
			getEntityManager().persist(t3RFT);

			AuditFichiers auditFichiers = new AuditFichiers();
			auditFichiers.setDateAudit(Date.valueOf(LocalDate.of(2015, 1, 2)));
			getEntityManager().persist(auditFichiers);

			ComplementEvenement complementEvenementIMX = new ComplementEvenement();
			complementEvenementIMX.setDatePhoto(LocalDate.of(2015, 1, 5));
			complementEvenementIMX.setDateMaj(LocalDate.of(2015, 1, 5));
			complementEvenementIMX.setStatutEvt(StatutEvenement.ACT);
			complementEvenementIMX.setAuditFichier(auditFichiers);
			complementEvenementIMX.setMontantArriere(BigDecimal.valueOf(50));
			complementEvenementIMX.setArriereLitige(false);
			complementEvenementIMX.setArriereTech(false);
			complementEvenementIMX.setIdentiteInitiale(id1);

			Evenement evenementIMX = new Evenement();
			evenementIMX.setCode("IMX");
			evenementIMX.setDateDebut(LocalDate.of(2015, 1, 5));
			evenementIMX.setIdContrat("idContrat");
			evenementIMX.setIdentiteInitiale(id1);
			evenementIMX.addComplement(complementEvenementIMX);
			getEntityManager().persist(evenementIMX);

		});
		// ACT
		lauchBatchDeclencheur("20150106");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 6)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(3L, results.size());
		assertEquals("TOPA", results.get(0).getMotifDeclencheur());
		assertEquals("RFTCA", results.get(1).getMotifDeclencheur());
		assertEquals("RFTCA", results.get(2).getMotifDeclencheur());

	}
	
	@Test
	public void testDeclencheurRFTCAConnue() throws Exception {

		// ARRANGE
		doInTransaction(() -> {

			Tiers t1 = new Tiers();
			t1.setIdFederal("IDRFT1");
			IdentiteTiers id1 = new IdentiteTiers();
			id1.setCodeBanque("10107");
			id1.setIdLocal("IDLOC1");
			id1.setCodeSegment("1010");
			id1.setDateDebut(LocalDate.of(2015, 1, 3));
			t1.addIdentite(id1);
			getEntityManager().persist(t1);

			TiersRFT t1RFT = new TiersRFT();
			t1RFT.setCodeBanque("10107");
			t1RFT.setDate(LocalDate.of(2015, 1, 4));
			t1RFT.setIdLocal("IDLOC1");
			t1RFT.setIdFederal("IDRFT1");
			getEntityManager().persist(t1RFT);

			TiersRFT t2RFT = new TiersRFT();
			t2RFT.setCodeBanque("10108");
			t2RFT.setDate(LocalDate.of(2015, 1, 4));
			t2RFT.setIdLocal("IDLOC2");
			t2RFT.setIdFederal("IDRFT1");
			getEntityManager().persist(t2RFT);

			TiersRFT t3RFT = new TiersRFT();
			t3RFT.setCodeBanque("10109");
			t3RFT.setDate(LocalDate.of(2015, 1, 4));
			t3RFT.setIdLocal("IDLOC3");
			t3RFT.setIdFederal("IDRFT1");
			getEntityManager().persist(t3RFT);
			
			Tiers t2 = new Tiers();
			t2.setIdFederal("IDRFT1");
			IdentiteTiers id2 = new IdentiteTiers();
			id2.setCodeBanque("10108");
			id2.setIdLocal("IDLOC2");
			id2.setCodeSegment("1010");
			id2.setDateDebut(LocalDate.of(2015, 1, 6));
			t2.addIdentite(id1);
			getEntityManager().persist(t2);

			AuditFichiers auditFichiers = new AuditFichiers();
			auditFichiers.setDateAudit(Date.valueOf(LocalDate.of(2015, 1, 2)));
			getEntityManager().persist(auditFichiers);

			ComplementEvenement complementEvenementIMX = new ComplementEvenement();
			complementEvenementIMX.setDatePhoto(LocalDate.of(2015, 1, 5));
			complementEvenementIMX.setDateMaj(LocalDate.of(2015, 1, 5));
			complementEvenementIMX.setStatutEvt(StatutEvenement.ACT);
			complementEvenementIMX.setAuditFichier(auditFichiers);
			complementEvenementIMX.setMontantArriere(BigDecimal.valueOf(50));
			complementEvenementIMX.setArriereLitige(false);
			complementEvenementIMX.setArriereTech(false);
			complementEvenementIMX.setIdentiteInitiale(id1);

			Evenement evenementIMX = new Evenement();
			evenementIMX.setCode("IMX");
			evenementIMX.setDateDebut(LocalDate.of(2015, 1, 5));
			evenementIMX.setIdContrat("idContrat");
			evenementIMX.setIdentiteInitiale(id1);
			evenementIMX.addComplement(complementEvenementIMX);
			getEntityManager().persist(evenementIMX);

		});
		// ACT
		lauchBatchDeclencheur("20150105");
		lauchBatchDeclencheur("20150106");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 6)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(3L, results.size());
		assertEquals("TOPA", results.get(0).getMotifDeclencheur());
		assertEquals("RFTCA", results.get(1).getMotifDeclencheur());
		assertEquals("RFTCA", results.get(2).getMotifDeclencheur());

	}

	@Test
	public void testDeclencheurDoublonIdentiteTiers() throws Exception {

		// ARRANGE
		doInTransaction(() -> {

			Tiers t1 = new Tiers();

			IdentiteTiers id1 = new IdentiteTiers();
			id1.setCodeBanque("10107");
			id1.setIdLocal("IDLOC1");
			id1.setDateDebut(LocalDate.of(2015, 1, 3));
			id1.setCodeSegment("3200");
			t1.addIdentite(id1);

			getEntityManager().persist(t1);

			Tiers t2 = new Tiers();

			IdentiteTiers id2 = new IdentiteTiers();
			id2.setCodeBanque("10107");
			id2.setIdLocal("IDLOC1");
			id2.setDateDebut(LocalDate.of(2015, 1, 3));

			t2.addIdentite(id2);
			getEntityManager().persist(t2);


		});
		// ACT
		lauchBatchDeclencheur("20150105");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 5)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("SEG", results.get(0).getMotifDeclencheur());


	}

	@Test
	public void testDeclencheurDoublonIdentiteTiersCodeSegDifferents() throws Exception {

		// ARRANGE
		doInTransaction(() -> {

			Tiers t1 = new Tiers();

			IdentiteTiers id1 = new IdentiteTiers();
			id1.setCodeBanque("10107");
			id1.setIdLocal("IDLOC1");
			id1.setDateDebut(LocalDate.of(2015, 1, 3));
			id1.setCodeSegment("3200");
			t1.addIdentite(id1);

			getEntityManager().persist(t1);

			Tiers t2 = new Tiers();

			IdentiteTiers id2 = new IdentiteTiers();
			id2.setCodeBanque("10107");
			id2.setIdLocal("IDLOC1");
			id2.setDateDebut(LocalDate.of(2015, 1, 3));
			id2.setCodeSegment("1010");
			t2.addIdentite(id2);

			getEntityManager().persist(t2);


		});
		// ACT
		lauchBatchDeclencheur("20150105");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 5)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("SEG", results.get(0).getMotifDeclencheur());


	}

	@Test
	public void testDoublonStatutSain() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);


			StatutHistorise statusSain1= new StatutHistorise();
			statusSain1.setStatut(StatutTiers.SAIN);
			statusSain1.setAnnule(Boolean.FALSE);
			statusSain1.setDateDeb(LocalDate.of(2015, 1, 1));
			statusSain1.setTiers(tiers);
			getEntityManager().persist(statusSain1);

			StatutHistorise statusSain2= new StatutHistorise();
			statusSain2.setStatut(StatutTiers.SAIN);
			statusSain2.setDateDeb(LocalDate.of(2015, 1, 2));
			statusSain2.setAnnule(Boolean.FALSE);
			statusSain2.setTiers(tiers);
			getEntityManager().persist(statusSain2);


		});
		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1, results.size());
	}

	@Test
	public void testDoublonStatutSainDefaut() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);


			StatutHistorise statusSain1= new StatutHistorise();
			statusSain1.setStatut(StatutTiers.SAIN);
			statusSain1.setAnnule(Boolean.FALSE);
			statusSain1.setDateDeb(LocalDate.of(2015, 1, 1));
			statusSain1.setTiers(tiers);
			getEntityManager().persist(statusSain1);

			StatutHistorise statusSain2= new StatutHistorise();
			statusSain2.setStatut(StatutTiers.DEFAUT);
			statusSain2.setDateDeb(LocalDate.of(2015, 1, 2));
			statusSain2.setAnnule(Boolean.FALSE);
			statusSain2.setTiers(tiers);
			getEntityManager().persist(statusSain2);


		});
		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1, results.size());
	}

	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}
