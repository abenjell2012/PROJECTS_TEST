package bpce.yyd.batch.declencheur.ti;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.*;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import javax.persistence.TypedQuery;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DeclencheurTOPPPTest extends AbstractTestIntegration {


	@Test
	public void testDeclencheurTOPPP() throws Exception{

		// ARRANGE
		initData();
		// ACT
		lauchBatchDeclencheur("20150102");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 2)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("TOPPP", results.get(0).getMotifDeclencheur());


	}

	private static void initData() {

		doInTransaction(() -> {


			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);


			PeriodeProbatoire periodeProbatoire = new PeriodeProbatoire();
			periodeProbatoire.setDateDebut(LocalDate.of(2015, 1, 1));
			periodeProbatoire.setTiers(tiers);
			getEntityManager().persist(periodeProbatoire);

			MotifStatutTiers motifStatutTiers = new MotifStatutTiers(periodeProbatoire);

			StatutHistorise statutHistorise = new StatutHistorise();
			statutHistorise.setStatut(StatutTiers.DEFAUT);
			statutHistorise.setGravite("DX");
			statutHistorise.setDateDeb(LocalDate.of(2015, 1, 1));
			statutHistorise.setMotif(motifStatutTiers);
			statutHistorise.setTiers(tiers);
			getEntityManager().persist(statutHistorise);

		});
	}


	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}
