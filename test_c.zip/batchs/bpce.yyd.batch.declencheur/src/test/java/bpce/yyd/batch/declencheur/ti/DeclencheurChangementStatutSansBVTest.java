package bpce.yyd.batch.declencheur.ti;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.Declencheur;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.reference.ParGravite;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import javax.persistence.TypedQuery;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DeclencheurChangementStatutSansBVTest extends AbstractTestIntegration {


	@Test
	public void testCxASain() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setCodeSegment("1010");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("CX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("CX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersCX = new StatutHistorise();
			statusTiersCX.setStatut(StatutTiers.DEFAUT);
			statusTiersCX.setGravite("CX");
			statusTiersCX.setAnnule(Boolean.FALSE);
			statusTiersCX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersCX.setTiers(tiers);
			getEntityManager().persist(statusTiersCX);

			StatutHistorise statusTiersSain= new StatutHistorise();
			statusTiersSain.setStatut(StatutTiers.SAIN);
			statusTiersSain.setAnnule(Boolean.FALSE);
			statusTiersSain.setDateDeb(LocalDate.of(2015, 1, 3));
			statusTiersSain.setTiers(tiers);
			getEntityManager().persist(statusTiersSain);


		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STCL", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testDxASain() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setCodeSegment("1010");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("DX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersDX = new StatutHistorise();
			statusTiersDX.setStatut(StatutTiers.DEFAUT);
			statusTiersDX.setGravite("DX");
			statusTiersDX.setAnnule(Boolean.FALSE);
			statusTiersDX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersDX.setTiers(tiers);
			getEntityManager().persist(statusTiersDX);

			StatutHistorise statusTiersSain= new StatutHistorise();
			statusTiersSain.setStatut(StatutTiers.SAIN);
			statusTiersSain.setAnnule(Boolean.FALSE);
			statusTiersSain.setDateDeb(LocalDate.of(2015, 1, 3));
			statusTiersSain.setTiers(tiers);
			getEntityManager().persist(statusTiersSain);


		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STCL", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testRxASain() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("RX");
			parMdcGraviteCX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteCX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setCodeSegment("1010");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("RX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("RX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersRX = new StatutHistorise();
			statusTiersRX.setStatut(StatutTiers.DEFAUT);
			statusTiersRX.setGravite("RX");
			statusTiersRX.setAnnule(Boolean.FALSE);
			statusTiersRX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersRX.setDateFin(LocalDate.of(2015, 1, 2));
			statusTiersRX.setTiers(tiers);
			getEntityManager().persist(statusTiersRX);

			StatutHistorise statusTiersSain= new StatutHistorise();
			statusTiersSain.setStatut(StatutTiers.SAIN);
			statusTiersSain.setAnnule(Boolean.FALSE);
			statusTiersSain.setDateDeb(LocalDate.of(2015, 1, 3));
			statusTiersSain.setTiers(tiers);
			getEntityManager().persist(statusTiersSain);


		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STCL", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testDaD() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("CX");
			photoTiers.setStatutCalcule("D");
			photoTiers.setPalierCalcule("CX");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersCX = new StatutHistorise();
			statusTiersCX.setStatut(StatutTiers.DEFAUT);
			statusTiersCX.setGravite("CX");
			statusTiersCX.setAnnule(false);
			statusTiersCX.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersCX.setTiers(tiers);
			getEntityManager().persist(statusTiersCX);

			StatutHistorise statusTiersCX2= new StatutHistorise();
			statusTiersCX2.setStatut(StatutTiers.DEFAUT);
			statusTiersCX2.setDateDeb(LocalDate.of(2015, 1, 3));
			statusTiersCX.setGravite("CX");
			statusTiersCX.setAnnule(false);
			statusTiersCX2.setTiers(tiers);
			getEntityManager().persist(statusTiersCX2);


		});
		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(0, results.size());
	}

	@Test
	public void testSainACx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("CX");
			parMdcGraviteCX.setOrdre(1);
			getEntityManager().persist(parMdcGraviteCX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setCodeSegment("1010");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersSain= new StatutHistorise();
			statusTiersSain.setStatut(StatutTiers.SAIN);
			statusTiersSain.setAnnule(Boolean.FALSE);
			statusTiersSain.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersSain.setTiers(tiers);
			getEntityManager().persist(statusTiersSain);

			StatutHistorise statusTiersCX = new StatutHistorise();
			statusTiersCX.setStatut(StatutTiers.DEFAUT);
			statusTiersCX.setGravite("CX");
			statusTiersCX.setAnnule(Boolean.FALSE);
			statusTiersCX.setDateDeb(LocalDate.of(2015, 1, 3));
			statusTiersCX.setTiers(tiers);
			getEntityManager().persist(statusTiersCX);

		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STCL", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testSainADx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteDX = new ParGravite();
			parMdcGraviteDX.setGravite("DX");
			parMdcGraviteDX.setOrdre(2);
			getEntityManager().persist(parMdcGraviteDX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setCodeSegment("1010");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersSain= new StatutHistorise();
			statusTiersSain.setStatut(StatutTiers.SAIN);
			statusTiersSain.setAnnule(Boolean.FALSE);
			statusTiersSain.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersSain.setTiers(tiers);
			getEntityManager().persist(statusTiersSain);

			StatutHistorise statusTiersDX = new StatutHistorise();
			statusTiersDX.setStatut(StatutTiers.DEFAUT);
			statusTiersDX.setGravite("DX");
			statusTiersDX.setAnnule(Boolean.FALSE);
			statusTiersDX.setDateDeb(LocalDate.of(2015, 1, 3));
			statusTiersDX.setTiers(tiers);
			getEntityManager().persist(statusTiersDX);

		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STCL", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testSainARx() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			ParGravite parMdcGraviteCX = new ParGravite();
			parMdcGraviteCX.setGravite("RX");
			parMdcGraviteCX.setOrdre(3);
			getEntityManager().persist(parMdcGraviteCX);

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setCodeSegment("1010");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusTiersSain= new StatutHistorise();
			statusTiersSain.setStatut(StatutTiers.SAIN);
			statusTiersSain.setAnnule(Boolean.FALSE);
			statusTiersSain.setDateDeb(LocalDate.of(2015, 1, 1));
			statusTiersSain.setDateFin(LocalDate.of(2015, 1, 2));
			statusTiersSain.setTiers(tiers);
			getEntityManager().persist(statusTiersSain);

			StatutHistorise statusTiersRX = new StatutHistorise();
			statusTiersRX.setStatut(StatutTiers.DEFAUT);
			statusTiersRX.setGravite("RX");
			statusTiersRX.setAnnule(Boolean.FALSE);
			statusTiersRX.setDateDeb(LocalDate.of(2015, 1, 3));
			statusTiersRX.setTiers(tiers);
			getEntityManager().persist(statusTiersRX);

		});
		// ACT
		lauchBatchDeclencheur("20150110");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 10)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("STCL", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testNdaNd() throws Exception{

		// ARRANGE
		doInTransaction(() -> {

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setDateDebut(LocalDate.of(2015, 1, 1));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			RestTiersLocal restTiersLocal = new RestTiersLocal();
			restTiersLocal.setIdLocal("IDLOC1");
			restTiersLocal.setCodeBanque("10107");
			restTiersLocal.setDateDebut(LocalDate.of(2015, 1, 1));
			getEntityManager().persist(restTiersLocal);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(restTiersLocal);
			photoTiers.setDatePhoto(LocalDate.of(2015, 1, 1));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("ND");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);

			StatutHistorise statusSain1= new StatutHistorise();
			statusSain1.setStatut(StatutTiers.SAIN);
			statusSain1.setAnnule(Boolean.FALSE);
			statusSain1.setDateDeb(LocalDate.of(2015, 1, 1));
			statusSain1.setTiers(tiers);
			getEntityManager().persist(statusSain1);

			StatutHistorise statusSain2= new StatutHistorise();
			statusSain2.setStatut(StatutTiers.SAIN);
			statusSain2.setDateDeb(LocalDate.of(2015, 1, 3));
			statusSain2.setTiers(tiers);
			getEntityManager().persist(statusSain2);


		});
		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(0, results.size());
	}




	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}
