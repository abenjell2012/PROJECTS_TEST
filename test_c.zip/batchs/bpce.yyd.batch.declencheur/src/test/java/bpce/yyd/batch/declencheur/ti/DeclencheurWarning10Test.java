package bpce.yyd.batch.declencheur.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Declencheur;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;

public class DeclencheurWarning10Test extends AbstractTestIntegration {

	@Test
	public void testDeclencheurWarning10() throws Exception {

		// ARRANGE
		initData();
		// ACT
		lauchBatchDeclencheur("20150104");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 4)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("W10", results.get(0).getMotifDeclencheur());
	}

	private static void initData() {

		doInTransaction(() -> {

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 3));
			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			AuditFichiers auditFichiers = new AuditFichiers();
			auditFichiers.setDateAudit(Date.valueOf(LocalDate.of(2015, 1, 4)));
			auditFichiers.setDatePhoto(LocalDate.of(2015, 1, 4));
			getEntityManager().persist(auditFichiers);

			Evenement evenementF = new Evenement();
			evenementF.setCode("F");
			evenementF.setDateDebut(LocalDate.of(2015, 1, 3));
			evenementF.setIdContrat("idContrat");
			evenementF.setIdentiteInitiale(id);

			getEntityManager().persist(evenementF);

			ComplementEvenement complementEvenementF = new ComplementEvenement();
			complementEvenementF.setDatePhoto(LocalDate.of(2015, 1, 3));
			complementEvenementF.setDateMaj(LocalDate.of(2015, 1, 3));
			complementEvenementF.setStatutEvt(StatutEvenement.ACT);
			complementEvenementF.setAuditFichier(auditFichiers);
			complementEvenementF.setArriereLitige(false);
			complementEvenementF.setArriereTech(false);
			complementEvenementF.setIdentiteInitiale(id);
			complementEvenementF.setEvenement(evenementF);
			getEntityManager().persist(complementEvenementF);

			Evenement evenementIMX = new Evenement();
			evenementIMX.setCode("IMX");
			evenementIMX.setDateDebut(LocalDate.of(2015, 1, 4));
			evenementIMX.setIdContrat("idContrat");
			evenementIMX.setIdentiteInitiale(id);

			getEntityManager().persist(evenementIMX);

			ComplementEvenement complementEvenementIMX = new ComplementEvenement();
			complementEvenementIMX.setDatePhoto(LocalDate.of(2015, 1, 4));
			complementEvenementIMX.setDateMaj(LocalDate.of(2015, 1, 4));
			complementEvenementIMX.setStatutEvt(StatutEvenement.ACT);
			complementEvenementIMX.setAuditFichier(auditFichiers);
			complementEvenementIMX.setMontantArriere(BigDecimal.valueOf(100000l));
			complementEvenementIMX.setArriereLitige(false);
			complementEvenementIMX.setArriereTech(false);
			complementEvenementIMX.setIdentiteInitiale(id);
			complementEvenementIMX.setEvenement(evenementIMX);
			getEntityManager().persist(complementEvenementIMX);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("IDLOC1");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2014, 11, 1));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2014, 11, 1));
			photoTiers.setTopA(true);
			photoTiers.setTopF(true);
			getEntityManager().persist(photoTiers);

		});
	}

	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}
