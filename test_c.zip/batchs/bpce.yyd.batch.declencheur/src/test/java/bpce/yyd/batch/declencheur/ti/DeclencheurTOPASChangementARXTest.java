package bpce.yyd.batch.declencheur.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Declencheur;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;

public class DeclencheurTOPASChangementARXTest extends AbstractTestIntegration {

	@Test
	public void testDeclencheurTOPASChangementARXJourJ() throws Exception {
		// Tiers en AR0 le 02-MARS -21 donc en AS le 02/03
		// Puis passe de AR0 à AR1 le 01-MAI -21
		// le déclencheur est lancé le 01 MAI 21 (le meme jour que le passage en AR1)

		// ARRANGE
		initData();

		// ACT
		lauchBatchDeclencheur("20210501");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2021, 5, 1)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("TOPAS", results.get(0).getMotifDeclencheur());

	}

	@Test
	public void testDeclencheurTOPASChangementARX_Moins_10_jour() throws Exception {
		// Tiers en AR0 le 02-MARS -21 donc en AS le 02/03
		// Puis passe de AR0 à AR1 le 01-MAI -21
		// le déclencheur est lancé le 11 MAI 21 (soit 10 jours plus tard)

		// ARRANGE //meme jeux de données que le test précédent seul la date de
		// lancement est différente
		initData();

		// ACT
		lauchBatchDeclencheur("20210511");

		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2021, 5, 11)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("TOPAS", results.get(0).getMotifDeclencheur());

	}

	private static void initData() {

		doInTransaction(() -> {

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2021, 3, 2));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			Evenement evenement = new Evenement();
			evenement.setCode("DAX");
			evenement.setIdentiteInitiale(id);
			getEntityManager().persist(evenement);

			AuditFichiers auditFichiers = new AuditFichiers();
			auditFichiers.setDatePhoto(LocalDate.of(2021, 3, 2));
			getEntityManager().persist(auditFichiers);

			ComplementEvenement complementEvenement = new ComplementEvenement();
			complementEvenement.setStatutEvt(StatutEvenement.ACT);
			complementEvenement.setArriereLitige(false);
			complementEvenement.setArriereTech(false);
			complementEvenement.setMiseAJour(true);
			complementEvenement.setDatePhoto(LocalDate.of(2021, 3, 2));
			complementEvenement.setAuditFichier(auditFichiers);
			complementEvenement.setEvenement(evenement);
			complementEvenement.setIdentiteInitiale(id);
			getEntityManager().persist(complementEvenement);

			ElementsDeCalcul edc = new ElementsDeCalcul();
			edc.setTiers(tiers);
			getEntityManager().persist(edc);

			ArriereSignificatif as = new ArriereSignificatif();
			as.setTiers(tiers);
			as.setDateDebut(LocalDate.of(2021, 3, 2));
			ComplementArriere complAS = new ComplementArriere();
			complAS.setEntree(edc);
			as.setComplement(complAS);
			getEntityManager().persist(as);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("IDLOC1");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2021, 3, 2));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2021, 3, 2));
			photoTiers.setTopA(true);
			photoTiers.setTopAS(true);
			photoTiers.setPalierAS("AR0");
			getEntityManager().persist(photoTiers);

		});
	}

	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}
