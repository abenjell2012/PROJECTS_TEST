package bpce.yyd.batch.declencheur.ti;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.enums.StatutTiers;
import fr.bpce.yyd.commun.model.*;
import fr.bpce.yyd.commun.model.restitution.*;
import org.junit.After;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DeclencheurDECTest extends AbstractTestIntegration {


	@Test
	public void testDeclencheurDEC() throws Exception{

		// ARRANGE
		initData();
		// ACT
		lauchBatchDeclencheur("20150102");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 2)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("DEC", results.get(0).getMotifDeclencheur());


	}

	private static void initData() {

		doInTransaction(() -> {

			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2014, 12, 28));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise stSain = new StatutHistorise();
			stSain.setStatut(StatutTiers.SAIN);
			stSain.setDateDeb(LocalDate.of(2014, 12, 31));
			stSain.setDateFin(LocalDate.of(2015, 1, 3));
			stSain.setMotif(null);
			stSain.setTiers(tiers);
			stSain.setAnnule(false);
			getEntityManager().persist(stSain);

			Evenement evenement = new Evenement();
			evenement.setCode("DEC");
			evenement.setIdentiteInitiale(id);

			getEntityManager().persist(evenement);

			AuditFichiers auditFichiers = new AuditFichiers();
			auditFichiers.setDatePhoto(LocalDate.of(2015, 1, 2));
			auditFichiers.setDateAudit(Date.valueOf(LocalDate.of(2015, 1, 2)));

			getEntityManager().persist(auditFichiers);

			ComplementEvenement complementEvenement = new ComplementEvenement();
			complementEvenement.setStatutEvt(StatutEvenement.ACT);
			complementEvenement.setMiseAJour(false);
			complementEvenement.setDatePhoto(LocalDate.of(2015, 1, 2));
			complementEvenement.setAuditFichier(auditFichiers);
			complementEvenement.setEvenement(evenement);
			complementEvenement.setIdentiteInitiale(id);
			getEntityManager().persist(complementEvenement);


			StatutHistorise stDX = new StatutHistorise();
			stDX.setStatut(StatutTiers.DEFAUT);
			stDX.setGravite("DX");
			stDX.setDateDeb(LocalDate.of(2015, 1, 3));
			stDX.setMotif(new MotifStatutTiers(complementEvenement));
			stDX.setTiers(tiers);
			stDX.setAnnule(false);
			getEntityManager().persist(stDX);

		});
	}

	@Test
	public void declencheurOldPhotoDEC() {
		// Arrange - On crée le tiers + identite
		doInTransaction(() -> {
			Tiers tiers = new Tiers();


			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2014, 12, 28));
			id.setDateFin(null);

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			StatutHistorise stSain = new StatutHistorise();
			stSain.setStatut(StatutTiers.SAIN);
			stSain.setDateDeb(LocalDate.of(2014, 12, 31));
			stSain.setDateFin(LocalDate.of(2015, 1, 3));
			stSain.setMotif(null);
			stSain.setTiers(tiers);
			stSain.setAnnule(false);
			getEntityManager().persist(stSain);

			Evenement evenement = new Evenement();
			evenement.setCode("DEC");
			evenement.setIdentiteInitiale(id);

			getEntityManager().persist(evenement);

			AuditFichiers auditFichiers = new AuditFichiers();
			auditFichiers.setDatePhoto(LocalDate.of(2015, 1, 2));
			auditFichiers.setDateAudit(Date.valueOf(LocalDate.of(2015, 1, 2)));

			getEntityManager().persist(auditFichiers);

			ComplementEvenement complementEvenement = new ComplementEvenement();
			complementEvenement.setStatutEvt(StatutEvenement.ACT);
			complementEvenement.setMiseAJour(false);
			complementEvenement.setDatePhoto(LocalDate.of(2015, 1, 2));
			complementEvenement.setAuditFichier(auditFichiers);
			complementEvenement.setEvenement(evenement);
			complementEvenement.setIdentiteInitiale(id);
			getEntityManager().persist(complementEvenement);


			StatutHistorise stDX = new StatutHistorise();
			stDX.setStatut(StatutTiers.DEFAUT);
			stDX.setGravite("DX");
			stDX.setDateDeb(LocalDate.of(2015, 1, 3));
			stDX.setMotif(new MotifStatutTiers(complementEvenement));
			stDX.setTiers(tiers);
			stDX.setAnnule(false);
			getEntityManager().persist(stDX);

			RestTiersLocal tiersLoc = new RestTiersLocal();
			tiersLoc.setIdLocal("IDLOC1");
			tiersLoc.setCodeBanque("10107");
			tiersLoc.setCodeSegment("1010");
			tiersLoc.setDateDebut(LocalDate.of(2014, 12, 28));
			getEntityManager().persist(tiersLoc);

			RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
			photoTiers.setRestRechTiersLocal(tiersLoc);
			photoTiers.setDatePhoto(LocalDate.of(2014, 12, 28));
			photoTiers.setOrigineStatutEffectif("STC");
			photoTiers.setStatutEffectif("D");
			photoTiers.setPalierEffectif("DX");
			photoTiers.setStatutCalcule("ND");
			photoTiers.setTopAS(false);
			photoTiers.setTopPP(false);
			photoTiers.setTopA(false);
			photoTiers.setTopF(false);
			photoTiers.setWarning3(false);
			photoTiers.setWarning10(false);
			getEntityManager().persist(photoTiers);
		});

		// Act
		lauchBatchDeclencheur("20150102");

		// Assert
		doInTransaction(() -> {
			List<Declencheur> declencheurs = findAllDeclencheurs();
			Assert.assertEquals(1, declencheurs.size());
			Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
			Assert.assertEquals("IDLOC1", declencheurs.get(0).getIdLocal());
			Assert.assertEquals("DEC", declencheurs.get(0).getMotifDeclencheur());
		});
	}

    @Test
    public void declencheurDECSortiRFT() {
        // Arrange - On crée le tiers + identite
        doInTransaction(() -> {
            TiersRFT rft2 = new TiersRFT();
            rft2.setCodeBanque("10107");
            rft2.setIdFederal("idFederal1");
            rft2.setIdLocal("ID-TIERS-LOCAL-0002");
            rft2.setDate(LocalDate.of(2018, 12, 1));
            getEntityManager().persist(rft2);

            Tiers tiers = new Tiers();
            tiers.setIdFederal("idFederal1");

            Tiers tiers1 = new Tiers();


            IdentiteTiers id = new IdentiteTiers();
            id.setCodeBanque("10107");
            id.setIdLocal("ID-TIERS-LOCAL-0001");
            id.setCodeSegment("1010");
            id.setSiren("siren1");
            id.setDateDebut(LocalDate.of(2018, 12, 1));
            tiers1.addIdentite(id);
            getEntityManager().persist(tiers1);

            IdentiteTiers id2 = new IdentiteTiers();
            id2.setCodeBanque("10107");
            id2.setIdLocal("ID-TIERS-LOCAL-0002");
            id2.setCodeSegment("1030");
            id2.setSiren("siren1");
            id2.setDateDebut(LocalDate.of(2018, 12, 1));
            tiers.addIdentite(id2);
            getEntityManager().persist(tiers);

            Evenement evenement = new Evenement();
            evenement.setCode("DEC");
            evenement.setIdentiteInitiale(id);

            getEntityManager().persist(evenement);

            AuditFichiers auditFichiers = new AuditFichiers();
            auditFichiers.setDatePhoto(LocalDate.of(2018, 12, 1));
            auditFichiers.setDateAudit(Date.valueOf(LocalDate.of(2018, 12, 1)));

            getEntityManager().persist(auditFichiers);

            ComplementEvenement complementEvenement = new ComplementEvenement();
            complementEvenement.setStatutEvt(StatutEvenement.ACT);
            complementEvenement.setMiseAJour(false);
            complementEvenement.setDatePhoto(LocalDate.of(2018, 12, 1));
            complementEvenement.setAuditFichier(auditFichiers);
            complementEvenement.setEvenement(evenement);
            complementEvenement.setIdentiteInitiale(id);
            getEntityManager().persist(complementEvenement);

            StatutHistorise statusTiers = new StatutHistorise();
            statusTiers.setStatut(StatutTiers.SAIN);
            statusTiers.setAnnule(Boolean.FALSE);
            statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
            statusTiers.setTiers(tiers);
            getEntityManager().persist(statusTiers);

            RestTiersSiren siren = new RestTiersSiren();
            siren.setSiren("siren1");
            getEntityManager().persist(siren);

            RestTiersIdRft rft = new RestTiersIdRft();
            rft.setIdRft("idFederal1");
            getEntityManager().persist(rft);

            RestAssociateRftSiren assoc = new RestAssociateRftSiren();
            assoc.setRestIdSiren(siren);
            assoc.setRestIdRFT(rft);
            getEntityManager().persist(assoc);

            RestTiersLocal tiersLoc = new RestTiersLocal();
            tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
            tiersLoc.setCodeBanque("10107");
            tiersLoc.setCodeSegment("1010");
            tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
            tiersLoc.setRestAssoRftSiren(assoc);
            getEntityManager().persist(tiersLoc);

            RestTiersLocal tiersLoc2 = new RestTiersLocal();
            tiersLoc2.setIdLocal("ID-TIERS-LOCAL-0002");
            tiersLoc2.setCodeBanque("10107");
            tiersLoc2.setCodeSegment("1030");
            tiersLoc2.setDateDebut(LocalDate.of(2018, 12, 1));
            tiersLoc2.setRestAssoRftSiren(assoc);
            getEntityManager().persist(tiersLoc2);

            RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
            photoTiers.setRestRechTiersLocal(tiersLoc);
            photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
            photoTiers.setOrigineStatutEffectif("STC");
            photoTiers.setStatutEffectif("ND");
            photoTiers.setStatutCalcule("ND");
            photoTiers.setTopAS(false);
            photoTiers.setTopPP(false);
            photoTiers.setTopA(false);
            photoTiers.setTopF(false);
            photoTiers.setWarning3(false);
            photoTiers.setWarning10(false);
            getEntityManager().persist(photoTiers);

            RestSynthTierLocalStatus photoTiers2 = new RestSynthTierLocalStatus();
            photoTiers2.setRestRechTiersLocal(tiersLoc2);
            photoTiers2.setDatePhoto(LocalDate.of(2018, 11, 1));
            photoTiers2.setOrigineStatutEffectif("STC");
            photoTiers2.setStatutEffectif("ND");
            photoTiers2.setStatutCalcule("ND");
            photoTiers2.setTopAS(false);
            photoTiers2.setTopPP(false);
            photoTiers2.setTopA(false);
            photoTiers2.setTopF(false);
            photoTiers2.setWarning3(false);
            photoTiers2.setWarning10(false);
            getEntityManager().persist(photoTiers2);
        });

        // Act
        lauchBatchDeclencheur("20181201");

        // Assert
        doInTransaction(() -> {
            List<Declencheur> declencheurs = findAllDeclencheurs();
            Assert.assertEquals(1, declencheurs.size());
            Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
            Assert.assertEquals("ID-TIERS-LOCAL-0001", declencheurs.get(0).getIdLocal());
            Assert.assertEquals("DEC", declencheurs.get(0).getMotifDeclencheur());
            Assert.assertEquals("1010", declencheurs.get(0).getCodeSegment());
        });
    }

    @Test
    public void declencheurDECDifferentTiersPartage() {
        // Arrange - On crée le tiers + identite
        doInTransaction(() -> {
            TiersRFT rft1 = new TiersRFT();
            rft1.setCodeBanque("10107");
            rft1.setIdFederal("idFederal1");
            rft1.setIdLocal("ID-TIERS-LOCAL-0001");
            rft1.setDate(LocalDate.of(2018, 12, 1));
            getEntityManager().persist(rft1);

            TiersRFT rft2 = new TiersRFT();
            rft2.setCodeBanque("10107");
            rft2.setIdFederal("idFederal1");
            rft2.setIdLocal("ID-TIERS-LOCAL-0002");
            rft2.setDate(LocalDate.of(2018, 12, 1));
            getEntityManager().persist(rft2);

            Tiers tiers = new Tiers();
            tiers.setIdFederal("idFederal1");

            IdentiteTiers id = new IdentiteTiers();
            id.setCodeBanque("10107");
            id.setIdLocal("ID-TIERS-LOCAL-0001");
            id.setCodeSegment("1010");
            id.setSiren("siren1");
            id.setDateDebut(LocalDate.of(2018, 12, 1));
            tiers.addIdentite(id);

            IdentiteTiers id2 = new IdentiteTiers();
            id2.setCodeBanque("10107");
            id2.setIdLocal("ID-TIERS-LOCAL-0002");
            id2.setCodeSegment("1020");
            id2.setSiren("siren1");
            id2.setDateDebut(LocalDate.of(2018, 12, 1));
            tiers.addIdentite(id2);
            getEntityManager().persist(tiers);

            Evenement evenement = new Evenement();
            evenement.setCode("DEC");
            evenement.setIdentiteInitiale(id);

            getEntityManager().persist(evenement);

            AuditFichiers auditFichiers = new AuditFichiers();
            auditFichiers.setDatePhoto(LocalDate.of(2018, 12, 1));
            auditFichiers.setDateAudit(Date.valueOf(LocalDate.of(2018, 12, 1)));

            getEntityManager().persist(auditFichiers);

            ComplementEvenement complementEvenement = new ComplementEvenement();
            complementEvenement.setStatutEvt(StatutEvenement.ACT);
            complementEvenement.setMiseAJour(false);
            complementEvenement.setDatePhoto(LocalDate.of(2018, 12, 1));
            complementEvenement.setAuditFichier(auditFichiers);
            complementEvenement.setEvenement(evenement);
            complementEvenement.setIdentiteInitiale(id);
            getEntityManager().persist(complementEvenement);

            StatutHistorise statusTiers = new StatutHistorise();
            statusTiers.setStatut(StatutTiers.SAIN);
            statusTiers.setAnnule(Boolean.FALSE);
            statusTiers.setDateDeb(LocalDate.of(2018, 12, 1));
            statusTiers.setTiers(tiers);
            getEntityManager().persist(statusTiers);

            RestTiersSiren siren = new RestTiersSiren();
            siren.setSiren("siren1");
            getEntityManager().persist(siren);

            RestTiersIdRft rft = new RestTiersIdRft();
            rft.setIdRft("idFederal1");
            getEntityManager().persist(rft);

            RestAssociateRftSiren assoc = new RestAssociateRftSiren();
            assoc.setRestIdSiren(siren);
            assoc.setRestIdRFT(rft);
            getEntityManager().persist(assoc);

            RestTiersLocal tiersLoc = new RestTiersLocal();
            tiersLoc.setIdLocal("ID-TIERS-LOCAL-0001");
            tiersLoc.setCodeBanque("10107");
            tiersLoc.setCodeSegment("1010");
            tiersLoc.setDateDebut(LocalDate.of(2018, 12, 1));
            tiersLoc.setRestAssoRftSiren(assoc);
            getEntityManager().persist(tiersLoc);

            RestTiersLocal tiersLoc2 = new RestTiersLocal();
            tiersLoc2.setIdLocal("ID-TIERS-LOCAL-0002");
            tiersLoc2.setCodeBanque("10107");
            tiersLoc2.setCodeSegment("1030");
            tiersLoc2.setDateDebut(LocalDate.of(2018, 12, 1));
            tiersLoc2.setRestAssoRftSiren(assoc);
            getEntityManager().persist(tiersLoc2);

            RestSynthTierLocalStatus photoTiers = new RestSynthTierLocalStatus();
            photoTiers.setRestRechTiersLocal(tiersLoc);
            photoTiers.setDatePhoto(LocalDate.of(2018, 11, 1));
            photoTiers.setOrigineStatutEffectif("STC");
            photoTiers.setStatutEffectif("ND");
            photoTiers.setStatutCalcule("ND");
            photoTiers.setTopAS(false);
            photoTiers.setTopPP(false);
            photoTiers.setTopA(false);
            photoTiers.setTopF(false);
            photoTiers.setWarning3(false);
            photoTiers.setWarning10(false);
            getEntityManager().persist(photoTiers);

            RestSynthTierLocalStatus photoTiers2 = new RestSynthTierLocalStatus();
            photoTiers2.setRestRechTiersLocal(tiersLoc2);
            photoTiers2.setDatePhoto(LocalDate.of(2018, 11, 1));
            photoTiers2.setOrigineStatutEffectif("STC");
            photoTiers2.setStatutEffectif("ND");
            photoTiers2.setStatutCalcule("ND");
            photoTiers2.setTopAS(false);
            photoTiers2.setTopPP(false);
            photoTiers2.setTopA(false);
            photoTiers2.setTopF(false);
            photoTiers2.setWarning3(false);
            photoTiers2.setWarning10(false);
            getEntityManager().persist(photoTiers2);
        });

        // Act
        lauchBatchDeclencheur("20181201");

        // Assert
        doInTransaction(() -> {
            List<Declencheur> declencheurs = findAllDeclencheurs();
            Assert.assertEquals(2, declencheurs.size());
            Assert.assertEquals("10107", declencheurs.get(0).getCodeBanque());
            Assert.assertEquals("ID-TIERS-LOCAL-0001", declencheurs.get(0).getIdLocal());
            Assert.assertEquals("DEC", declencheurs.get(0).getMotifDeclencheur());
            Assert.assertEquals("10107", declencheurs.get(1).getCodeBanque());
            Assert.assertEquals("ID-TIERS-LOCAL-0002", declencheurs.get(1).getIdLocal());
            Assert.assertEquals("SEG", declencheurs.get(1).getMotifDeclencheur());
            Assert.assertEquals("1020", declencheurs.get(1).getCodeSegment());
        });
    }

    private BatchStatus lauchBatchDeclencheur(String dateLaunch) {
		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();
		try {
			JobExecution execution = jobLauncher.run(job, jobParameters);
			return execution.getStatus();
		} catch (Exception e) {
			e.printStackTrace();
			return BatchStatus.UNKNOWN;
		}
	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}
	/**
	 * Utilitaire pour assertions : retourne liste de Declencheur
	 *
	 * @return List<Declencheur>
	 */
	public List<Declencheur> findAllDeclencheurs() {
		EntityManager entityManager = getEntityManager();
		TypedQuery<Declencheur> query = entityManager.createQuery("select s from Declencheur s", Declencheur.class);
		return query.getResultList();
	}
}
