package bpce.yyd.batch.declencheur.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.enums.StatutEvenement;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.Declencheur;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;

public class DeclencheurWarning3Test extends AbstractTestIntegration {
/*	@TestH2 non passant mais ok sur oracle
	public void testDeclencheurWarning3() throws Exception {

		// ARRANGE
		initData();
		// ACT
		lauchBatchDeclencheur("20150102");
		// VERIFY
		TypedQuery<Declencheur> q = getEntityManager().createQuery(
				" SELECT d from Declencheur d where d.dateDeclencheur = :dateDec order by idLocal ", Declencheur.class);
		q.setParameter("dateDec", Date.valueOf(LocalDate.of(2015, 1, 2)));
		List<Declencheur> results = q.getResultList();
		assertNotNull(results);
		assertEquals(2L, results.size());
		if ("IDLOC1".equals(results.get(0).getIdLocal())) {
			assertEquals("W3", results.get(0).getMotifDeclencheur());
		} else {
			assertEquals("W3", results.get(1).getMotifDeclencheur());
		}

	}*///H2 non passant mais ok sur oracle

	private static void initData() {

		doInTransaction(() -> {

			// 1ere reception d'un RAD --> Déclenchement
			Tiers tiers = new Tiers();

			IdentiteTiers id = new IdentiteTiers();
			id.setCodeBanque("10107");
			id.setIdLocal("IDLOC1");
			id.setCodeSegment("1010");
			id.setDateDebut(LocalDate.of(2015, 1, 2));

			tiers.addIdentite(id);
			getEntityManager().persist(tiers);

			Evenement evenement = new Evenement();
			evenement.setCode("RAD");
			evenement.setDateDebut(LocalDate.of(2015, 1, 2));
			evenement.setIdentiteInitiale(id);

			getEntityManager().persist(evenement);

			AuditFichiers auditFichiers = new AuditFichiers();
			auditFichiers.setDatePhoto(LocalDate.of(2015, 1, 2));
			auditFichiers.setDateAudit(Date.valueOf(LocalDate.of(2015, 1, 2)));

			getEntityManager().persist(auditFichiers);

			ComplementEvenement complementEvenement = new ComplementEvenement();
			complementEvenement.setStatutEvt(StatutEvenement.ACT);
			complementEvenement.setMiseAJour(false);
			complementEvenement.setDateMaj(LocalDate.of(2015, 1, 2));
			complementEvenement.setDatePhoto(LocalDate.of(2015, 1, 2));
			complementEvenement.setAuditFichier(auditFichiers);
			complementEvenement.setEvenement(evenement);
			complementEvenement.setIdentiteInitiale(id);
			getEntityManager().persist(complementEvenement);

			// Nieme reception d'un RAD --> Non déclenchement
			Evenement evenement3 = new Evenement();
			evenement3.setCode("RAD");
			evenement3.setDateDebut(LocalDate.of(2015, 1, 2));
			evenement3.setIdentiteInitiale(id);

			getEntityManager().persist(evenement3);

			ComplementEvenement complementEvenement3 = new ComplementEvenement();
			complementEvenement3.setStatutEvt(StatutEvenement.ACT);
			complementEvenement3.setMiseAJour(false);
			complementEvenement3.setDateMaj(LocalDate.of(2015, 1, 2));
			complementEvenement3.setDatePhoto(LocalDate.of(2015, 1, 2));
			complementEvenement3.setAuditFichier(auditFichiers);
			complementEvenement3.setEvenement(evenement3);
			complementEvenement3.setIdentiteInitiale(id);
			getEntityManager().persist(complementEvenement3);

			// Evenement différent de RAD --> Non déclenchement
			Tiers tiers2 = new Tiers();

			IdentiteTiers id2 = new IdentiteTiers();
			id2.setCodeBanque("10107");
			id2.setIdLocal("IDLOC2");
			id2.setCodeSegment("1010");
			id2.setDateDebut(LocalDate.of(2015, 1, 2));

			tiers2.addIdentite(id2);
			getEntityManager().persist(tiers2);

			Evenement evenement2 = new Evenement();
			evenement2.setCode("IMX");
			evenement2.setDateDebut(LocalDate.of(2015, 1, 2));
			evenement2.setIdentiteInitiale(id2);

			getEntityManager().persist(evenement2);

			AuditFichiers auditFichiers2 = new AuditFichiers();
			auditFichiers2.setDatePhoto(LocalDate.of(2015, 1, 2));
			auditFichiers2.setDateAudit(Date.valueOf(LocalDate.of(2015, 1, 2)));

			getEntityManager().persist(auditFichiers2);

			ComplementEvenement complementEvenement2 = new ComplementEvenement();
			complementEvenement2.setStatutEvt(StatutEvenement.ACT);
			complementEvenement2.setMiseAJour(false);
			complementEvenement2.setDateMaj(LocalDate.of(2015, 1, 2));
			complementEvenement2.setDatePhoto(LocalDate.of(2015, 1, 2));
			complementEvenement2.setAuditFichier(auditFichiers2);
			complementEvenement2.setEvenement(evenement2);
			complementEvenement2.setIdentiteInitiale(id2);
			getEntityManager().persist(complementEvenement2);

		});
	}

	private JobExecution lauchBatchDeclencheur(String dateLaunch) throws Exception {

		Job job = (Job) context.getBean(Constant.JOB_DECLENCHEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();

	}

}
