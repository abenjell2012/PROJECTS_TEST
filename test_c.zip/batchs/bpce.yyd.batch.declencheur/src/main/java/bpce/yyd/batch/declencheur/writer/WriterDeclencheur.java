package bpce.yyd.batch.declencheur.writer;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import fr.bpce.yyd.commun.model.Declencheur;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
public class WriterDeclencheur implements ItemWriter<Declencheur> {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_QUERY_DECLENCHEUR = "insert into REST_DECLENCHEURS "
			+ "(TIERS_ID,ID_LOCAL,CODE_BANQUE,CODE_SEGMENT,SIREN,ID_RFT,DATE_DECLENCHEUR,DATE_DERNIERE_PHOTO,MOTIF_DECLENCHEUR) " + "values (?,?,?,?,?,?,?,?,?)";

	@Override
	public void write(List<? extends Declencheur> items) throws Exception {

		log.info("Début de chargement de: " + items.size() + " lignes");

		jdbcTemplate.batchUpdate(INSERT_QUERY_DECLENCHEUR, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				ps.setObject(1, items.get(i).getTiers());
				ps.setString(2, items.get(i).getIdLocal());
				ps.setString(3, items.get(i).getCodeBanque());
				ps.setString(4, items.get(i).getCodeSegment());
				ps.setString(5, items.get(i).getSiren());
				ps.setString(6, items.get(i).getIdRFT());
				ps.setDate(7, items.get(i).getDateDeclencheur());
				ps.setDate(8, items.get(i).getDateDernierePhoto());
				ps.setString(9, items.get(i).getMotifDeclencheur());
			}

			@Override
			public int getBatchSize() {
				return items.size();
			}
		});
	}
}