package bpce.yyd.batch.declencheur.beans;

import java.sql.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataTableTemp {

	private String idRFT;

	private String idLocal;

	private String codeBanque;

	private String codeSegment;

	private String siren;

	private Date datePhoto;

	private String statutEffectif;

	private String palierEffectif;

	private String origineStatutEffectif;

	private String statutCalcule;

	private String palierCalcule;

	private boolean topPP;

	private boolean topF;

	private boolean topA;

	private boolean topAS;

	private String palierAS;

	private Date dateDebForcageBV;

	private Date dateFinForcageBV;

}
