package bpce.yyd.batch.declencheur.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.jdbc.core.PreparedStatementSetter;

import fr.bpce.yyd.batch.commun.constantes.Constant;

public class ParameterSetterEF implements PreparedStatementSetter {

	private String date;

	public ParameterSetterEF(String date) {
		this.date = date;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		LocalDate dateBatch = LocalDate.parse(date, Constant.YYYYMMDD_FORMATTER);
		Date dateDebut = Date.valueOf(dateBatch);
		for (int i = 1; i < 14; i++) {
			ps.setDate(i, dateDebut);
		}
	}
}
