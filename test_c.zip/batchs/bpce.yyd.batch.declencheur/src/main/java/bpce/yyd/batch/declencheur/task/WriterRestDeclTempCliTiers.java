package bpce.yyd.batch.declencheur.task;


import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.utils.SpringBatchUtil;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Setter
@Service
public class WriterRestDeclTempCliTiers implements Tasklet {

	private String sql;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		int retour;

		retour = jdbcTemplate.update(sql);

		StepExecution stepExec = SpringBatchUtil.getStepExecution(chunkContext);
		stepExec.setWriteCount(retour);
		log.info("INSERT_REST_DECL_TEMP_CLI_TIERS = " + retour);
		return RepeatStatus.FINISHED;
	}
}
