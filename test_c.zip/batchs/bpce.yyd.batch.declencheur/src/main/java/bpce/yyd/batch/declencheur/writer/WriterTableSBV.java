package bpce.yyd.batch.declencheur.writer;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import bpce.yyd.batch.declencheur.beans.DataTableSBV;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
public class WriterTableSBV implements ItemWriter<DataTableSBV> {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_QUERY_REST_DECL_SBV_ALL = "insert into REST_DECL_SBV_ALL "
			+ "(ID,TIERS_ID,ID_RFT,ID_LOCAL,CODE_BQ,SIREN,CODE_SEGMENT,STATUT_FORCE,GRAVITE,DATE_DEBUT,DATE_FIN) "
			+ "values (?,?,?,?,?,?,?,?,?,?,?)";

	@Override
	public void write(List<? extends DataTableSBV> items) throws Exception {

		log.info("Début de chargement de: " + items.size() + " lignes");

		jdbcTemplate.batchUpdate(INSERT_QUERY_REST_DECL_SBV_ALL, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				ps.setString(1, items.get(i).getID());
				ps.setString(2, items.get(i).getTiersID());
				ps.setString(3, items.get(i).getIdRFT());
				ps.setString(4, items.get(i).getIdLocal());
				ps.setString(5, items.get(i).getCodeBanque());
				ps.setString(6, items.get(i).getSiren());
				ps.setString(7, items.get(i).getCodeSegment());
				ps.setString(8, items.get(i).getStatutForce());
				ps.setString(9, items.get(i).getGravite());
				ps.setDate(10, items.get(i).getDateDebut());
				ps.setDate(11, items.get(i).getDateFin());
				
			}

			@Override
			public int getBatchSize() {
				return items.size();
			}
		});
	}
}