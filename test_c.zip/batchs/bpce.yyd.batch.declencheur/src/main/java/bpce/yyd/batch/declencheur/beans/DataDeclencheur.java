package bpce.yyd.batch.declencheur.beans;

import java.sql.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataDeclencheur {

	private Long tiersId;

	private String idRFT;

	private String idLocal;

	private String codeBanque;

	private String codeSegment;

	private String siren;

	private Date dateDernierePhoto;

	private String motifDeclencheur;

}
