package bpce.yyd.batch.declencheur.task;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class VidageTableRestDeclTempCliTiersAll implements Tasklet {


	private static final String TRUNCATE_REST_DECL_TEMP_CLI_TIERS_ALL = "TRUNCATE TABLE REST_DECL_TEMP_CLI_TIERS_ALL";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		jdbcTemplate.update(TRUNCATE_REST_DECL_TEMP_CLI_TIERS_ALL);
		return RepeatStatus.FINISHED;
	}
}
