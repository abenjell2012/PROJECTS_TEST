package bpce.yyd.batch.declencheur.mapper;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.jdbc.core.PreparedStatementSetter;

import fr.bpce.yyd.batch.commun.constantes.Constant;

public class ParameterSetter implements PreparedStatementSetter {

	private String date;

	public ParameterSetter(String date) {
		this.date = date;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		LocalDate dateBatch = LocalDate.parse(date, Constant.YYYYMMDD_FORMATTER);
		Date dateDebut = Date.valueOf(dateBatch);
		ps.setDate(1, dateDebut);
		ps.setDate(2, dateDebut);
		ps.setDate(3, dateDebut);
		ps.setDate(4, dateDebut);
		ps.setDate(5, dateDebut);
		ps.setDate(6, dateDebut);
		ps.setDate(7, dateDebut);	
		ps.setDate(8, dateDebut);
		ps.setDate(9, dateDebut);	
		ps.setDate(10, Date.valueOf(dateDebut.toLocalDate().minusDays(30)));
		ps.setDate(11, Date.valueOf(dateDebut.toLocalDate().minusDays(60)));
		ps.setDate(12, Date.valueOf(dateDebut.toLocalDate().minusDays(90)));
		for (int i = 13; i < 38; i++) {
			ps.setDate(i, dateDebut);
		}
		ps.setDate(38, Date.valueOf(dateDebut.toLocalDate().minusDays(30)));
		ps.setDate(39, Date.valueOf(dateDebut.toLocalDate().minusDays(60)));
		ps.setDate(40, Date.valueOf(dateDebut.toLocalDate().minusDays(90)));

	}
}
