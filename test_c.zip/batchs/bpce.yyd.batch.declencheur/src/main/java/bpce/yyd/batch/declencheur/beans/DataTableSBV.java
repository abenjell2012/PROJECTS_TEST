package bpce.yyd.batch.declencheur.beans;

import java.sql.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataTableSBV {
	private String ID;
	
	private String tiersID;

	private String idRFT;

	private String idLocal;

	private String codeBanque;

	private String siren;

	private String codeSegment;

	private String statutForce;
	
	private String gravite;
	
	private Date dateDebut;
	
	private Date dateFin;
}




