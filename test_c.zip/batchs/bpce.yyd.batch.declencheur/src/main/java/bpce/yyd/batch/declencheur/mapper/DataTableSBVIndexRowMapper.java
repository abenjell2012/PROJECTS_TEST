package bpce.yyd.batch.declencheur.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bpce.yyd.batch.declencheur.beans.DataTableSBV;

public class DataTableSBVIndexRowMapper implements RowMapper<DataTableSBV> {

	@Override
	public DataTableSBV mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataTableSBV data = new DataTableSBV();

		data.setID(rs.getString(1));
		data.setTiersID(rs.getString(2));
		data.setIdRFT(rs.getString(3));
		data.setIdLocal(rs.getString(4));
		data.setCodeBanque(rs.getString(5));
		data.setSiren(rs.getString(6));
		data.setCodeSegment(rs.getString(7));
		data.setStatutForce(rs.getString(8));
		data.setGravite(rs.getString(9));
		data.setDateDebut(rs.getDate(10));
		data.setDateFin(rs.getDate(11));
		return data;
	}
}
