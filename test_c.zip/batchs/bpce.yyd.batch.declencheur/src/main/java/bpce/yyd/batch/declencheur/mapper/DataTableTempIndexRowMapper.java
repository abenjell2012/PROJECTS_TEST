package bpce.yyd.batch.declencheur.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bpce.yyd.batch.declencheur.beans.DataTableTemp;

public class DataTableTempIndexRowMapper implements RowMapper<DataTableTemp> {

	@Override
	public DataTableTemp mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataTableTemp data = new DataTableTemp();

		data.setIdRFT(rs.getString(1));
		data.setSiren(rs.getString(2));
		data.setIdLocal(rs.getString(3));
		data.setCodeBanque(rs.getString(4));
		data.setCodeSegment(rs.getString(5));
		data.setStatutEffectif(rs.getString(6));
		data.setPalierEffectif(rs.getString(7));
		data.setOrigineStatutEffectif(rs.getString(8));
		data.setStatutCalcule(rs.getString(9));
		data.setPalierCalcule(rs.getString(10));
		data.setTopA(rs.getBoolean(11));
		data.setTopAS(rs.getBoolean(12));
		data.setTopPP(rs.getBoolean(13));
		data.setTopF(rs.getBoolean(14));
		data.setDatePhoto(rs.getDate(15));
		data.setPalierAS(rs.getString(16));
		data.setDateDebForcageBV(rs.getDate(17));
		data.setDateFinForcageBV(rs.getDate(18));
		return data;
	}
}
