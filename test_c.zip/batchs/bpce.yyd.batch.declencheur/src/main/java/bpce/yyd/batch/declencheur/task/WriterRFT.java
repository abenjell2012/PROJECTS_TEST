package bpce.yyd.batch.declencheur.task;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.SpringBatchUtil;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Setter
@Service
public class WriterRFT implements Tasklet {

	private String sql;

	private String date;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LocalDate dateBatch = LocalDate.parse(date,Constant.YYYYMMDD_FORMATTER);
		Date dateDebut = Date.valueOf(dateBatch);
		int retour;

		retour = jdbcTemplate.update(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setDate(1, dateDebut);
				ps.setDate(2, dateDebut);
				ps.setDate(3, dateDebut);
			}
		});
		StepExecution stepExec = SpringBatchUtil.getStepExecution(chunkContext);
		stepExec.setWriteCount(retour);
		log.info("INSERT_RFT_CARTESIEN = " + retour);
		return RepeatStatus.FINISHED;
	}
}
