package bpce.yyd.batch.declencheur.task;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.SpringBatchUtil;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

@Slf4j
@Setter
@Service
public class WriterDateFinSBV implements Tasklet {

	private String sqlDateFinBV;

	private String date;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LocalDate dateBatchFinSBV = LocalDate.parse(date,Constant.YYYYMMDD_FORMATTER);
		Date dateDebut = Date.valueOf(dateBatchFinSBV);
		int retour;

		retour = jdbcTemplate.update(sqlDateFinBV, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setDate(1, dateDebut);
			}
		});
		StepExecution stepExec = SpringBatchUtil.getStepExecution(chunkContext);
		stepExec.setWriteCount(retour);
		log.info("INSERT_CHANGEMENT_DATE_FIN_SBV = " + retour);
		return RepeatStatus.FINISHED;
	}
}
