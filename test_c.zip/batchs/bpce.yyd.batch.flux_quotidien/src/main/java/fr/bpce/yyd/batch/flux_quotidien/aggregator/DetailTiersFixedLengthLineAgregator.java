package fr.bpce.yyd.batch.flux_quotidien.aggregator;

import org.springframework.batch.item.file.transform.LineAggregator;

import fr.bpce.yyd.batch.commun.beans.DetailTiersInfo;
import fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils;

public class DetailTiersFixedLengthLineAgregator implements LineAggregator<DetailTiersInfo> {

	@Override
	public String aggregate(DetailTiersInfo item) {
		return RestitSyntheseUtils.generateDetailFicTiers(item);
	}

}
