package fr.bpce.yyd.batch.flux_quotidien.callback;

import java.io.IOException;
import java.io.Writer;

import org.springframework.batch.item.file.FlatFileFooterCallback;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FluxFooterCallBack implements FlatFileFooterCallback, InitializingBean {

	private String dateGeneration;
	private String codeBq;
	private Long nbEnregistement;

	@Override
	public void writeFooter(Writer writer) throws IOException {
		log.warn("write footer " + codeBq);
		writer.write(RestitSyntheseUtils.generateEnqueueFic(codeBq, nbEnregistement.intValue(),
				dateGeneration));
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.hasText(dateGeneration);
		Assert.hasText(codeBq);
	}

	public void setDateGeneration(String dateGeneration) {
		this.dateGeneration = dateGeneration;
	}

	public void setCodeBq(String codeBq) {
		this.codeBq = codeBq;
	}

	public void setNbEnregistement(Long nbEnregistement) {
		this.nbEnregistement = nbEnregistement;
	}

}
