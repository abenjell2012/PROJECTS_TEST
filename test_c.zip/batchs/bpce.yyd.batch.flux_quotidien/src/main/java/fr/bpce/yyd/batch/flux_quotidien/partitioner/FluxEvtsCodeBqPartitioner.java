package fr.bpce.yyd.batch.flux_quotidien.partitioner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;

public class FluxEvtsCodeBqPartitioner implements Partitioner {

	private static final Logger LOGGER = Logger.getLogger(FluxEvtsCodeBqPartitioner.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private String datePhoto;

	private static final String QUERY_COD_BQ = "select distinct code_banque from REST_TIERS_ID_LOCAL";

	@Override
	public Map<String, ExecutionContext> partition(int gridSize) {

		List<String> codeBqList = jdbcTemplate.queryForList(QUERY_COD_BQ, String.class);

		Map<String, ExecutionContext> result = new HashMap<>();

		if (!CollectionUtils.isEmpty(codeBqList)) {
			for (String codeBanque : codeBqList) {
				ExecutionContext executionContext = new ExecutionContext();
				executionContext.putString("codeBanque", codeBanque);
				result.put("codeBanque " + codeBanque, executionContext);
			}

		} else {
			LOGGER.warn("L'extraction des donnees evenements n'est faite pour aucun établissement");
		}

		return result;

	}

	public String getDatePhoto() {
		return datePhoto;
	}

	public void setDatePhoto(String datePhoto) {
		this.datePhoto = datePhoto;
	}

}
