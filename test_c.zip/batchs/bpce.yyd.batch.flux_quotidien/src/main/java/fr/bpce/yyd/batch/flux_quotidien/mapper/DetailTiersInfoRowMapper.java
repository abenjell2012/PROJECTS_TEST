package fr.bpce.yyd.batch.flux_quotidien.mapper;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import fr.bpce.yyd.batch.commun.beans.DetailTiersInfo;
import fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils;

public class DetailTiersInfoRowMapper implements RowMapper<DetailTiersInfo> {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public DetailTiersInfo mapRow(ResultSet rs, int rowNum) throws SQLException {

		DetailTiersInfo detailTiersInfo = new DetailTiersInfo();
		String codeBqSDA = rs.getString(41);

		detailTiersInfo.setIdSituation(rs.getString(1));
		detailTiersInfo.setDatePhoto(convertToLocalDate(rs.getDate(2)));
		detailTiersInfo.setIdFederal(rs.getString(3));
		detailTiersInfo.setCodeBanque(rs.getString(4));
		detailTiersInfo.setIdLocal(rs.getString(5));
		detailTiersInfo.setCodeSegment(rs.getString(6));
		detailTiersInfo.setStatutEff(rs.getString(7));
		detailTiersInfo.setPalierEff(rs.getString(8));
		detailTiersInfo.setDateMajStatutEff(convertToLocalDate(rs.getDate(9)));
		detailTiersInfo.setOrigineStatutEff(
				RestitSyntheseUtils.trouveOrigineStatutEffectif(rs.getString(10), detailTiersInfo.getStatutEff(),
						codeBqSDA, detailTiersInfo.getCodeBanque(), detailTiersInfo.getIdLocal(), jdbcTemplate));
		detailTiersInfo.setCommentaireForcage(rs.getString(11));
		detailTiersInfo.setTopPP(convertToTop(rs.getLong(12)));
		detailTiersInfo.setDatePrevFinPP(convertToLocalDate(rs.getDate(13)));
		detailTiersInfo.setTopF(convertToTop(rs.getLong(14)));
		detailTiersInfo.setTopA(convertToTop(rs.getLong(15)));
		detailTiersInfo.setTopAS(convertToTop(rs.getLong(16)));
		detailTiersInfo.setPalierAS(rs.getString(17));
		detailTiersInfo.setDateMetierEvtEntreeDefautCalcule(convertToLocalDate(rs.getDate(18)));
		detailTiersInfo.setCodeEvtEntreeDefautCalcule(rs.getString(19));
		// ca doit être un string en base ?
		detailTiersInfo.setIdEvtEntreeDefaut(rs.getString(20));
		detailTiersInfo.setMontantTotalImx(RestitSyntheseUtils.getNotNullBigDecimal(rs.getBigDecimal(21)));
		detailTiersInfo.setMontantTotalDax(RestitSyntheseUtils.getNotNullBigDecimal(rs.getBigDecimal(22)));
		detailTiersInfo.setMontantTotalArrieres(RestitSyntheseUtils.getNotNullBigDecimal(rs.getBigDecimal(23)));
		detailTiersInfo.setMontantEngaConsolide(RestitSyntheseUtils.getNotNullBigDecimal(rs.getBigDecimal(24)));
		detailTiersInfo.setDarDonneeEngaConsolide(convertToLocalDate(rs.getDate(25)));
		detailTiersInfo.setWarning1p1(convertToTop(rs.getLong(26)));
		detailTiersInfo.setWarning1p2(convertToTop(rs.getLong(27)));
		detailTiersInfo.setWarning1p3(convertToTop(rs.getLong(28)));
		detailTiersInfo.setWarning1p4(convertToTop(rs.getLong(29)));
		detailTiersInfo.setWarning2(convertToTop(rs.getLong(30)));
		detailTiersInfo.setWarning3(convertToTop(rs.getLong(31)));
		detailTiersInfo.setWarning4(convertToTop(rs.getLong(32)));
		detailTiersInfo.setWarning5p1(convertToTop(rs.getLong(33)));
		detailTiersInfo.setWarning5p2(convertToTop(rs.getLong(34)));
		detailTiersInfo.setWarning5p3(convertToTop(rs.getLong(35)));
		detailTiersInfo.setWarning6(convertToTop(rs.getLong(36)));
		detailTiersInfo.setWarning7(convertToTop(rs.getLong(37)));
		detailTiersInfo.setWarning8(convertToTop(rs.getLong(38)));
		detailTiersInfo.setWarning9(convertToTop(rs.getLong(39)));
		detailTiersInfo.setWarning10(convertToTop(rs.getLong(40)));

		return detailTiersInfo;
	}

	private LocalDate convertToLocalDate(Date date) {
		return date != null ? date.toLocalDate() : null;
	}

	private char convertToTop(Long value) {
		return (value > 0) ? 'O' : 'N';
	}

}
