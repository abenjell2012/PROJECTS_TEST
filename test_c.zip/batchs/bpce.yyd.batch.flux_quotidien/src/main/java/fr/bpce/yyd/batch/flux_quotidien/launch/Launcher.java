package fr.bpce.yyd.batch.flux_quotidien.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;


public class Launcher {

	private static final Logger LOGGER = Logger.getLogger(Launcher.class);

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public void runBatch(String dateStr) {

		JobExecution execution = null;

		try {
			LOGGER.info("Debut BATCH " + Constant.JOB_FLUX_QUOTIDIEN);

			Job job = (Job) getApplicationContext().getBean(Constant.JOB_FLUX_QUOTIDIEN);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

			LocalDate datePhotoFlux = null;
			if (dateStr != null) {
				datePhotoFlux = LocalDate.parse(dateStr, DateTimeFormatter.BASIC_ISO_DATE);
			} else {
				datePhotoFlux = LocalDate.now();
			}

			String env = ConfigManager.getProperty("env");
			String repRestitOut = ConfigManager.getProperty("flux_quotidien.rep.out");
			FileCommunUtils.checkRepertoire(repRestitOut + "events");
			FileCommunUtils.checkRepertoire(repRestitOut + "tiers");

			JobParameters jobParameters = new JobParametersBuilder().addString("repRestitOut", repRestitOut)
					.addString("env", env)
					.addString("datePhoto", datePhotoFlux.format(DateTimeFormatter.BASIC_ISO_DATE))
					.addDate("date", java.sql.Date.valueOf(datePhotoFlux)).addLong("id", new Date().getTime())
					.toJobParameters();
			execution = jobLauncher.run(job, jobParameters);
		} catch (Exception err) {
			LOGGER.error("Erreur inattendue : " + err.getMessage(), err);
			exitWithErrorCode(1);
		} finally {
			finaliserTraitement(batchStatus(execution));
		}
	}

	public static void main(String[] args) {

		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource("log4j-synthese-flux-quotidien.properties"));
		// Paramètre (éventuel) : date pour laquelle on calcule.
		// Sinon, ce sera la date du jour.
		String strDateCalcul = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
		if (args != null && args.length == 1) {
			String date = args[0];
			try {
				LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
				strDateCalcul = date; // Le format est bon
			} catch (DateTimeParseException dtpe) {
				LOGGER.error("Erreur le format de la date passe en parametre est incorrect " + args[0]);
				exitWithErrorCode(1);			
			}
		} else if (args != null && args.length > 1) {
			LOGGER.error("Erreur - mauvais paramètres en entrée, on attend pas plus d'1 paramètre");
			exitWithErrorCode(1);
		}

		Launcher launcher = new Launcher();
		launcher.runBatch(strDateCalcul);
	}
}