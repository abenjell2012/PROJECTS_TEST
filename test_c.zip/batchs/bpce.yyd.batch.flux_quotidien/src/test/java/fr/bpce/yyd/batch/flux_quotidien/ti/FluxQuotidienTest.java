package fr.bpce.yyd.batch.flux_quotidien.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestSynthEvtLocauxStatus;
import fr.bpce.yyd.commun.model.restitution.RestSynthEvtMDCStatus;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersIdRft;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;

public class FluxQuotidienTest extends AbstractTestIntegration {

	private static final String REP_OUT_ROOT = "./src/test/resources/restitution/";

	@Test
	public void testFluxQuotCas1() throws Exception {

		// ARRANGE
		initDataCas1();
		// ACT
		lauchBatchFluxQuot("20200601");
		// VERIFY
		verifyFilesContent();

	}

	private void verifyFilesContent() throws FileNotFoundException, IOException {

		// vérifier le fichier tiers

		File tiersFile = new File(REP_OUT_ROOT + "/tiers").listFiles()[0];
		assertTrue(tiersFile.getName().startsWith("NDOD_REST_TIERS_DELTA_10107_RCT_"));
		assertTrue(tiersFile.getName().endsWith(".gz"));

		List<String> tiersLines = readLinesFromGZ(tiersFile);
		assertNotNull(tiersLines);
		assertEquals(3, tiersLines.size());
		assertEquals("*12020060110107MDC001", tiersLines.get(0));
		assertEquals(
				"1              2020060100000028701010767936544                                          1100D DX20191110STC                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     N        NOOAR320191110AR3AR3AR3012121                  +00000000010432112+00000000009685433+00000000020117545+0000000005866653220191031ONNNNNNNNNNNNNN",
				tiersLines.get(1));
		assertEquals("*92020060110107MDC001+00000000000001", tiersLines.get(2));

		// vérifier le fichier évènement

		File evtFile = new File(REP_OUT_ROOT + "/events").listFiles()[0];
		assertTrue(evtFile.getName().startsWith("NDOD_REST_EVT_DELTA_10107_RCT_"));
		assertTrue(evtFile.getName().endsWith(".gz"));

		List<String> evtLines = readLinesFromGZ(evtFile);
		assertNotNull(evtLines);
		assertEquals(4, evtLines.size());
		assertEquals("*12020060110107MDC001", evtLines.get(0));
		assertEquals(
			"00000028701010767936544                                          IDLOCALIMXTESTCAS1            IMX                                                                                                                                                                                                            11138ACT2020060120200601        NNCONTRATIMX01                                      +00000000000015798                                                                                                ",
				evtLines.get(1));
		assertEquals(
				"00000028701010767936544                                          AR3AR312321                   AR3                                                                                                                                                                                                            10107   20200601                                                                    +00000000000000000                                                                                                ",
				evtLines.get(2));
		assertEquals("*92020060110107MDC001+00000000000002", evtLines.get(3));

	}

	private static void initDataCas1() {

		doInTransaction(() -> {

			RestTiersIdRft idRft = new RestTiersIdRft();
			idRft.setIdRft("0000002870");
			idRft.setCodeBanqueReferente("10107");
			getEntityManager().persist(idRft);

			RestAssociateRftSiren assoc = new RestAssociateRftSiren();
			assoc.setRestIdRFT(idRft);
			getEntityManager().persist(assoc);

			RestTiersLocal idlocal = new RestTiersLocal();
			idlocal.setRestAssoRftSiren(assoc);
			idlocal.setCodeBanque("10107");
			idlocal.setIdLocal("67936544");
			idlocal.setCodeSegment("1100");
			idlocal.setDateDebut(LocalDate.of(2020, 5, 1));
			getEntityManager().persist(idlocal);

			RestSynthTierLocalStatus status = new RestSynthTierLocalStatus();
			status.setRestRechTiersLocal(idlocal);
			status.setIdSyntheseTiers(1L);
			status.setDatePhoto(LocalDate.of(2020, 06, 01));
			status.setStatutEffectif("D");
			status.setDateMAJStatutEffectif(LocalDate.of(2019, 11, 10));
			status.setPalierEffectif("DX");
			status.setOrigineStatutEffectif("STC");
			status.setTopPP(false);
			status.setTopA(true);
			status.setTopAS(true);
			status.setIdEvtEntreeDefaut("AR3012121");
			status.setMontantTotalDAX(new BigDecimal("96854.3254"));
			status.setMontantTotalIMX(new BigDecimal("104321.12"));
			status.setMontantTotalArriere(new BigDecimal("201175.4454"));
			status.setPalierAS("AR3");
			status.setCodeEvtEntreeDefaut("AR3");
			status.setDateMetierEntreeDefaut(LocalDate.of(2019, 11, 10));
			status.setMontantEnCours(new BigDecimal("586665.32"));
			status.setDarEncours(LocalDateTime.of(2019, 10, 31, 0, 0));
			status.setWarning1p1(true);

			getEntityManager().persist(status);

			RestSynthEvtLocauxStatus evtLoc1 = new RestSynthEvtLocauxStatus();
			evtLoc1.setCode("IMX");
			evtLoc1.setSousCode(null);
			evtLoc1.setCodeBanqueEmetrice("11138");
			evtLoc1.setCommentaire("evt IMX");
			evtLoc1.setDateDebutEvent(LocalDate.of(2020, 06, 01));
			evtLoc1.setDateCloture(null);
			evtLoc1.setDateGenerationEVT(LocalDate.of(2020, 06, 01));
			evtLoc1.setDateMAJStatut(LocalDate.of(2020, 06, 01));
			evtLoc1.setDatePhotoEvent(LocalDate.of(2020, 06, 01));
			evtLoc1.setIdContrat("CONTRATIMX01");
			evtLoc1.setIdLocalEvt("IDLOCALIMXTESTCAS1");
			evtLoc1.setMontant(new BigDecimal("157.98"));
			evtLoc1.setRestSynthTiersLocal(status);
			evtLoc1.setStatut("ACT");
			evtLoc1.setCommentaire("impayé de plus de 90 jours");
			evtLoc1.setTopLitige(false);
			evtLoc1.setTopTechnique(false);
			getEntityManager().persist(evtLoc1);

			RestSynthEvtMDCStatus evtMdc1 = new RestSynthEvtMDCStatus();
			evtMdc1.setCodeBanqueEvt("10107");
			evtMdc1.setDateGenerationMDC(LocalDate.of(2020, 06, 01));
			evtMdc1.setCodeMdc("AR3");
			evtMdc1.setCreationDateEvt(LocalDate.of(2020, 06, 01));
			evtMdc1.setDateCloture(null);
			evtMdc1.setDateMiseAJourStatut(LocalDate.of(2020, 06, 01));
			evtMdc1.setIdMdcEvent("AR312321");
			evtMdc1.setRestSynthTiersLocal(status);

			getEntityManager().persist(evtMdc1);

		});
	}

	/**
	 * Initialiser le contexte Spring avant le démarrage des tests
	 *
	 * @throws NoSuchFieldException
	 * @throws IllegalAccessException
	 * @throws IOException
	 */
	@BeforeClass
	public static void initSpringContext() throws NoSuchFieldException, IllegalAccessException, IOException {
		initSpring();
	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();
		deleteDirectory(new File(REP_OUT_ROOT));

	}

	private JobExecution lauchBatchFluxQuot(String strDate) throws Exception {

		Job job = (Job) getContext().getBean(Constant.JOB_FLUX_QUOTIDIEN);
		JobLauncher jobLauncher = (JobLauncher) getContext().getBean("jobLauncher");

		LocalDate datePhotoFlux = LocalDate.parse(strDate, DateTimeFormatter.BASIC_ISO_DATE);
		String env = ConfigManager.getProperty("env");
		String repRestitOut = ConfigManager.getProperty("flux_quotidien.rep.out");
		FileCommunUtils.checkRepertoire(repRestitOut + "events");
		FileCommunUtils.checkRepertoire(repRestitOut + "tiers");

		JobParameters jobParameters = new JobParametersBuilder().addString("repRestitOut", repRestitOut)
				.addString("env", env).addString("datePhoto", datePhotoFlux.format(DateTimeFormatter.BASIC_ISO_DATE))
				.addDate("date", java.sql.Date.valueOf(datePhotoFlux)).addLong("id", new java.util.Date().getTime())
				.toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

	public static List<String> readLinesFromGZ(File file) throws FileNotFoundException, IOException {
		List<String> lines = new ArrayList<>();

		try (GZIPInputStream gzip = new GZIPInputStream(new FileInputStream(file));
				BufferedReader br = new BufferedReader(new InputStreamReader(gzip));) {
			String line = null;
			while ((line = br.readLine()) != null) {
				lines.add(line);
			}
		}
		return lines;
	}

	private static boolean deleteDirectory(File directoryToBeDeleted) {
		File[] allContents = directoryToBeDeleted.listFiles();
		if (allContents != null) {
			for (File file : allContents) {
				deleteDirectory(file);
			}
		}
		return directoryToBeDeleted.delete();
	}

}
