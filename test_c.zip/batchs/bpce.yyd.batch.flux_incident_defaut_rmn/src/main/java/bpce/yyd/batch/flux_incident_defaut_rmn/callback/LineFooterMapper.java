package bpce.yyd.batch.flux_incident_defaut_rmn.callback;

import java.io.*;

import org.springframework.batch.item.file.FlatFileFooterCallback;
import org.springframework.stereotype.Service;


@Service
public class LineFooterMapper implements FlatFileFooterCallback {
	private String date;
	private String fileName;

	@Override
	public void writeFooter(Writer writer) throws IOException {
		String ngLignes = String.format("%015d", getNombreLignes() + 1);
		writer.write("*9;" + date + ";00001;" + ngLignes);
	}

	private long getNombreLignes() {
		long lines = 0;
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName))){
			while(bufferedReader.readLine() != null)
			{
				++lines;
			}


		} catch (IOException e) {
			e.printStackTrace();
		}
		return lines;
	}

	public void setDate(String date) {
		this.date = date;
	}

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}