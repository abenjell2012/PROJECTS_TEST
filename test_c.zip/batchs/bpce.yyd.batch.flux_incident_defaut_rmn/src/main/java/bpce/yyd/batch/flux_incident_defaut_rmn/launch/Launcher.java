package bpce.yyd.batch.flux_incident_defaut_rmn.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import java.io.File;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;

public class Launcher {

	private static final Logger LOGGER = Logger.getLogger(Launcher.class);

	private static String logFile = "log4j-restit-incident-defaut.properties";
	private static ApplicationContext context;
	private static boolean isTest;
	private static boolean traitementOk;
	public static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

	public static String getFileOut(String dateCalcul) throws UnknownPropertyException, InvalidInitialisationException {
		FileCommunUtils.checkRepertoire(ConfigManager.getProperty("incident.rep.tmp"));
		String repOut = ConfigManager.getProperty("incident.rep.tmp");
		String env = ConfigManager.getProperty("env");
		if (repOut != null) {
			LocalDateTime date = LocalDateTime.now();
			StringBuilder name = new StringBuilder();
			name.append("IDF001");
			name.append(".INCDEF");
			name.append("." + dateCalcul);
			if (!"PRD".equalsIgnoreCase(env) && !"PROD".equalsIgnoreCase(env)) {
				name.append(".R");
			} else {
				name.append(".P");
			}
			name.append(".99999");
			name.append("." + date.format(TIME_FORMATTER));
			name.append(".csv");
			String filename = name.toString();

			StringBuilder path = new StringBuilder(repOut);
			path.append(File.separator);
			String pathname = path.toString();

			repOut = pathname + filename;
		}
		return repOut;
	}

	public void runBatch(String date) {
		JobExecution execution = null;
		try {
			LOGGER.info("Debut BATCH NDOD : INCIDENTS");
			Job job = (Job) getApplicationContext().getBean(Constant.JOB_FLUX_INCIDENT_DEFAUT);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

			String dateLaunch;
			if (date != null) {
				dateLaunch = date;
			} else {
				dateLaunch = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
			}

			Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
			JobParameters jobParameters = new JobParametersBuilder().addString("date", dateLaunch).addLong("guid", guid)
					.addString("filename", getFileOut(dateLaunch)).toJobParameters();
			execution = jobLauncher.run(job, jobParameters);

		} catch (Exception err) {
			LOGGER.error("Erreur inattendue : " + err.getMessage(), err);
			if (!isTest()) {
				exitWithErrorCode(1);
			}
		} finally {
			if (!isTest()) {
				finaliserTraitement(batchStatus(execution));
			}
		}
	}

	public static void main(String[] args) {
		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource(getLogFile()));
		Launcher launcher = new Launcher();
		String date = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);

		if (args == null || args.length == 0) {
			launcher.runBatch(date);
			traitementOk = true;
		} else if (args.length == 1) {
			String dateArgs = args[0];
			try {
				LocalDate.parse(dateArgs, DateTimeFormatter.BASIC_ISO_DATE);
				date = dateArgs;
			} catch (DateTimeParseException dtpe) {
				LOGGER.error("Erreur le format de la date passe en parametre est incorrect " + args[0]);
				exitWithErrorCode(1);
			}
			launcher.runBatch(date);
			traitementOk = true;
		} else if (args.length > 1) {
			LOGGER.error("Erreur - mauvais paramètres en entrée, on attend pas plus d'1 paramètre");
			exitWithErrorCode(1);
		}
	}

	public static void setLogFile(String log) {
		logFile = log;
	}

	public static String getLogFile() {
		return logFile;
	}

	public static void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public static ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public static void setIsTest(boolean test) {
		isTest = test;
	}

	public static boolean isTest() {
		return isTest;
	}

	public static boolean isTraitementOk() {
		return traitementOk;
	}

	public static void setTraitementOk(boolean traitementOk) {
		Launcher.traitementOk = traitementOk;
	}
}