package bpce.yyd.batch.flux_incident_defaut_rmn.tasks;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import fr.bpce.yyd.batch.commun.utils.SpringBatchUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.moveFileToDir;

@Service
@Slf4j
public class CopieVersRepINCDEF implements Tasklet {

	private String fileName;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		Path repertoireFinal = null;

		repertoireFinal = Paths.get(ConfigManager.getProperty("incident.rep.out"));

		try {
			 moveFileToDir(Paths.get(fileName), repertoireFinal);
		} catch (IOException e) {
			log.error("Erreur lors de la copie du fichier vers le répertoire INCDEF " + e.getMessage(), e);
			exitWithErrorCode(1);
		}

		return RepeatStatus.FINISHED;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
