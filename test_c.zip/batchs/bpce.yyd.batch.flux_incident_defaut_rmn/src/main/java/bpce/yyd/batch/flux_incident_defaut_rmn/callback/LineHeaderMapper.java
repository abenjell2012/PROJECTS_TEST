package bpce.yyd.batch.flux_incident_defaut_rmn.callback;

import java.io.IOException;
import java.io.Writer;

import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.stereotype.Service;

@Service
public class LineHeaderMapper implements FlatFileHeaderCallback {
	private String date;

	@Override
	public void writeHeader(Writer writer) throws IOException {
		writer.write("*1;" + date + ";00001");
	}

	public void setDate(String date) {
		this.date = date;
	}
}