package bpce.yyd.batch.flux_incident_defaut_rmn.beans;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DefautDetail {

	private String typeEnregistrement;

	private String datePhoto;

	private String idRft;

	private String idSituationDefaut;

	private String dateEntreeDefaut;

	private String dateSortieDefaut;

	private String palier;

	private String datePalier;

	private String dernierDefautClo;

}
