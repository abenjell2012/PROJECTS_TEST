package bpce.yyd.batch.flux_incident_defaut_rmn.beans;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IncidentDetail {

	private String typeEnregistrement;

	private String datePhoto;

	private String idRft;

	private String code;

	private String dateDebut;

	private String dateFin;

	private String idSituationIncident;
}
