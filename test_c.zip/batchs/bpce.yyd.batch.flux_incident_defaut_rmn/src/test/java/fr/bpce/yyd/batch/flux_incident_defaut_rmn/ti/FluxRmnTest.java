package fr.bpce.yyd.batch.flux_incident_defaut_rmn.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import fr.bpce.yyd.commun.model.AuditRestitutionIncident;
import fr.bpce.yyd.commun.model.restitution.rmn.RmnSituationDefaut;
import org.junit.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.support.TransactionTemplate;

import bpce.yyd.batch.flux_incident_defaut_rmn.launch.Launcher;
import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.utils.AbstractTestIntegration;
import fr.bpce.yyd.commun.model.SyntheseIncident;

import javax.persistence.TypedQuery;

public class FluxRmnTest extends AbstractTestIntegration {

	private static final String REP_OUT_ROOT = "./src/test/resources/restitution/";
	private static final String REP_OUT_TMP = "./src/test/resources/restitution_tmp/";

	@Test
	public void launcherTestStandard() throws IOException {
		initDataIncidentStandard();
		initSituationDefaut();
		String[] args = { "20211207" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertEquals(1,listFiles.size());

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();
		Assert.assertEquals(4,lines.size());
		Assert.assertEquals("*1;20211207;00001",lines.get(0));
		Assert.assertEquals("I;0000002870;1;20211127;;RC1",lines.get(1));
		Assert.assertEquals("D;0000002870;1;;;;;",lines.get(2));
		Assert.assertEquals("*9;20211207;00001;000000000000004",lines.get(3));

	}

	@Test
	public void launcherTestCloture() throws IOException {
		initDataCloture();
		initSituationDefaut();
		String[] args = { "20211207" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertEquals(1,listFiles.size());

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();
		Assert.assertEquals(4,lines.size());
		Assert.assertEquals("*1;20211207;00001",lines.get(0));
		Assert.assertEquals("I;0000002870;1;20211127;20211207;RC1",lines.get(1));
		Assert.assertEquals("D;0000002870;1;;;;;",lines.get(2));
		Assert.assertEquals("*9;20211207;00001;000000000000004",lines.get(3));

	}

	@Test
	public void launcherTestAnn() throws IOException {
		initDataAnn();
		initSituationDefaut();
		String[] args = { "20211207" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertEquals(1,listFiles.size());

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();

		Assert.assertEquals(4,lines.size());
		Assert.assertEquals("*1;20211207;00001",lines.get(0));
		Assert.assertEquals("I;0000002870;1;;;",lines.get(1));
		Assert.assertEquals("D;0000002870;1;;;;;",lines.get(2));
		Assert.assertEquals("*9;20211207;00001;000000000000004",lines.get(3));

	}

	@Test
	public void launcherTestDefautSainIncident() throws IOException {
		initDataIncidentStandard();
		initSituationDefautSain();
		String[] args = { "20211207" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertEquals(1,listFiles.size());

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();

		Assert.assertEquals(4,lines.size());
		Assert.assertEquals("*1;20211207;00001",lines.get(0));
		Assert.assertEquals("I;0000002870;1;20211127;;RC1",lines.get(1));
		Assert.assertEquals("D;0000002870;1;;;;;",lines.get(2));
		Assert.assertEquals("*9;20211207;00001;000000000000004",lines.get(3));

	}

	@Test
	public void launcherTestDefautSain() throws IOException {
		initSituationDefautSain();
		String[] args = { "20211207" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertTrue(listFiles.size() == 1);

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();

		Assert.assertEquals(2,lines.size());
		Assert.assertEquals("*1;20211207;00001",lines.get(0));
		Assert.assertEquals("*9;20211207;00001;000000000000002",lines.get(1));

	}

	@Test
	public void launcherTestSeg() throws IOException {
		initDataSeg();
		initSituationDefaut();
		String[] args = { "20211207" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertTrue(listFiles.size() == 1);

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();

		Assert.assertEquals(3,lines.size());
		Assert.assertEquals("*1;20211207;00001",lines.get(0));
		Assert.assertEquals("D;0000002870;1;;;;;",lines.get(1));
		Assert.assertEquals("*9;20211207;00001;000000000000003",lines.get(2));

	}

	@Test
	public void launcherTestSituationIncidentSansSituationDefaut() throws IOException {
		initDataIncidentStandard();
		String[] args = { "20211207" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertTrue(listFiles.size() == 1);

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();

		Assert.assertEquals(2,lines.size());
		Assert.assertEquals("*1;20211207;00001",lines.get(0));
		Assert.assertEquals("*9;20211207;00001;000000000000002",lines.get(1));

	}


	@Test
	public void launcherTestAncienneSyntheseIncidentNouvelleSituationDefaut() throws IOException {
		initDataIncidentStandard();
		initSituationDefaut() ;

		doInTransaction(() -> {
			RmnSituationDefaut situationDefaut = new RmnSituationDefaut();
			situationDefaut.setDatePhoto(LocalDate.of(2021, 12, 8));
			situationDefaut.setIdSituation(String.valueOf(1L));
			situationDefaut.setIdFederal("0000002870");
			situationDefaut.setOrigine("ORIGINE1");
			getEntityManager().persist(situationDefaut);

		});

		String[] args = { "20211208" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertTrue(listFiles.size() == 1);

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();

		Assert.assertEquals(4,lines.size());
		Assert.assertEquals("*1;20211208;00001",lines.get(0));
		Assert.assertEquals("I;0000002870;1;20211127;;RC1",lines.get(1));
		Assert.assertEquals("D;0000002870;1;;;;;",lines.get(2));
		Assert.assertEquals("*9;20211208;00001;000000000000004",lines.get(3));

	}

	@Test
	public void launcherTestNouvelleSyntheseIncidentAncienneSituationDefaut() throws IOException {
		initDataIncidentStandard();
		initSituationDefaut() ;

		doInTransaction(() -> {
			SyntheseIncident incident = new SyntheseIncident();
			incident.setDatePhoto(LocalDate.of(2021, 12, 8));
			incident.setIdSituationIncident(1L);
			incident.setIdRft("0000002870");
			incident.setCode("RC2");
			incident.setMotifPhoto("STANDARD");
			incident.setDateDebut(LocalDate.of(2021, 11, 27));
			getEntityManager().persist(incident);

		});

		String[] args = { "20211208" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertTrue(listFiles.size() == 1);

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();
		Assert.assertEquals( 4,lines.size());
		Assert.assertEquals("*1;20211208;00001",lines.get(0));
		Assert.assertEquals("I;0000002870;1;20211127;;RC2",lines.get(1));
		Assert.assertEquals("D;0000002870;1;;;;;",lines.get(2));
		Assert.assertEquals("*9;20211208;00001;000000000000004",lines.get(3));
	}

	@Test
	public void test904() throws IOException {
		test904J1();
		test904J2();
		test904J3();
		test904J4();
	}

	private void test904J4() throws IOException {
		File generatedFile;
		BufferedReader bufferedReader;
		initDataIncident18072022904();

		String[] args18072022 = { "20220718" };
		Launcher.main(args18072022);
		assertTrue(Launcher.isTraitementOk());

		TypedQuery<AuditRestitutionIncident> q1807 = getEntityManager().createQuery(
				" SELECT d from AuditRestitutionIncident d where d.datePhoto = :datePhoto and d.idRft = :idRFT",
				AuditRestitutionIncident.class);
		q1807.setParameter("datePhoto", LocalDate.of(2022, 07, 18));
		q1807.setParameter("idRFT", "0001771038");
		List<AuditRestitutionIncident> results1807 = q1807.getResultList();

		Assert.assertNotNull(results1807);
		assertEquals(1L, results1807.size());
		assertEquals("221980001771038", results1807.get(0).getIdSituationDefaut().toString());
		assertEquals("221990001771038", results1807.get(0).getIdSituationIncident().toString());

		List<String> listFiles1807 = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertTrue(listFiles1807.size() == 4);

		String filename1807 = listFiles1807.get(3);
		generatedFile = new File(filename1807);
		bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines1807 = new ArrayList<>();
		String line1807 = null;
		while ((line1807 = bufferedReader.readLine()) != null) {
			lines1807.add(line1807);
		}
		bufferedReader.close();
		Assert.assertTrue(lines1807.size() == 6);
		Assert.assertTrue(lines1807.get(0).equals("*1;20220718;00001"));
		Assert.assertTrue(lines1807.get(1).equals("I;0001771038;221990001771038;20220716;;DA1"));
		Assert.assertTrue(lines1807.get(2).equals("I;0001771038;221990001771038;20220718;;DA2"));
		Assert.assertTrue(lines1807.get(3).equals("I;0001771038;221990001771038;20220716;;EI1"));
		Assert.assertTrue(lines1807.get(4).equals("D;0001771038;221980001771038;;;CX;20220717;"));
		Assert.assertTrue(lines1807.get(5).equals("*9;20220718;00001;000000000000006"));


	}

	private void test904J3() throws IOException {
		File generatedFile;
		BufferedReader bufferedReader;
		initDataDefaut90417072022();

		String[] args17072022 = { "20220717" };
		Launcher.main(args17072022);
		assertTrue(Launcher.isTraitementOk());

		TypedQuery<AuditRestitutionIncident> q1707 = getEntityManager().createQuery(
				" SELECT d from AuditRestitutionIncident d where d.datePhoto = :datePhoto and d.idRft = :idRFT",
				AuditRestitutionIncident.class);
		q1707.setParameter("datePhoto", LocalDate.of(2022, 07, 17));
		q1707.setParameter("idRFT", "0001771038");
		List<AuditRestitutionIncident> results1707 = q1707.getResultList();

		Assert.assertNotNull(results1707);
		assertEquals(1L, results1707.size());
		assertEquals("221980001771038", results1707.get(0).getIdSituationDefaut().toString());
		assertEquals("221970001771038", results1707.get(0).getIdSituationIncident().toString());

		List<String> listFiles1707 = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertTrue(listFiles1707.size() == 3);

		String filename1707 = listFiles1707.get(2);
		generatedFile = new File(filename1707);
		bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines1707 = new ArrayList<>();
		String line1707 = null;
		while ((line1707 = bufferedReader.readLine()) != null) {
			lines1707.add(line1707);
		}
		bufferedReader.close();
		Assert.assertTrue(lines1707.size() == 5);
		Assert.assertTrue(lines1707.get(0).equals("*1;20220717;00001"));
		Assert.assertTrue(lines1707.get(1).equals("I;0001771038;221970001771038;20220716;;DA1"));
		Assert.assertTrue(lines1707.get(2).equals("I;0001771038;221970001771038;20220716;;EI1"));
		Assert.assertTrue(lines1707.get(3).equals("D;0001771038;221980001771038;;;CX;20220717;"));
		Assert.assertTrue(lines1707.get(4).equals("*9;20220717;00001;000000000000005"));
	}

	private void test904J2() throws IOException {
		File generatedFile;
		BufferedReader bufferedReader;
		initDataIncident16072022904();
		;

		String[] args16072022 = { "20220716" };
		Launcher.main(args16072022);
		assertTrue(Launcher.isTraitementOk());

		TypedQuery<AuditRestitutionIncident> q1607 = getEntityManager().createQuery(
				" SELECT d from AuditRestitutionIncident d where d.datePhoto = :datePhoto and d.idRft = :idRFT",
				AuditRestitutionIncident.class);
		q1607.setParameter("datePhoto", LocalDate.of(2022, 07, 16));
		q1607.setParameter("idRFT", "0001771038");
		List<AuditRestitutionIncident> results1607 = q1607.getResultList();

		Assert.assertNotNull(results1607);
		assertEquals(1L, results1607.size());
		assertEquals("221960001771038", results1607.get(0).getIdSituationDefaut().toString());
		assertEquals("221970001771038", results1607.get(0).getIdSituationIncident().toString());


		List<String> listFiles1607 = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertTrue(listFiles1607.size() == 2);

		String filename1607 = listFiles1607.get(1);
		generatedFile = new File(filename1607);
		bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines1607 = new ArrayList<>();
		String line1607 = null;
		while ((line1607 = bufferedReader.readLine()) != null) {
			lines1607.add(line1607);
		}
		bufferedReader.close();
		Assert.assertTrue(lines1607.size() == 5);
		Assert.assertTrue(lines1607.get(0).equals("*1;20220716;00001"));
		Assert.assertTrue(lines1607.get(1).equals("I;0001771038;221970001771038;20220716;;DA1"));
		Assert.assertTrue(lines1607.get(2).equals("I;0001771038;221970001771038;20220716;;EI1"));
		Assert.assertTrue(lines1607.get(3).equals("D;0001771038;221960001771038;;;;;"));
		Assert.assertTrue(lines1607.get(4).equals("*9;20220716;00001;000000000000005"));
	}

	private void test904J1() throws IOException {
		initDataDefaut90415072022();
		initDataIncident15072022904();
		;

		String[] args = { "20220715" };
		Launcher.main(args);
		assertTrue(Launcher.isTraitementOk());

		TypedQuery<AuditRestitutionIncident> q = getEntityManager().createQuery(
				" SELECT d from AuditRestitutionIncident d where d.datePhoto = :datePhoto and d.idRft = :idRFT",
				AuditRestitutionIncident.class);
		q.setParameter("datePhoto", LocalDate.of(2022, 07, 15));
		q.setParameter("idRFT", "0001771038");
		List<AuditRestitutionIncident> results = q.getResultList();

		Assert.assertNotNull(results);
		assertEquals(1L, results.size());
		assertEquals("221960001771038", results.get(0).getIdSituationDefaut().toString());
		assertEquals("221960001771038", results.get(0).getIdSituationIncident().toString());

		List<String> listFiles = Stream.of(new File(REP_OUT_ROOT).listFiles()).filter(file -> !file.isDirectory())
				.map(File::getName).collect(Collectors.toList());

		Assert.assertTrue(listFiles.size() == 1);

		String filename = listFiles.get(0);
		File generatedFile = new File(filename);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(REP_OUT_ROOT + "/" + generatedFile));

		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			lines.add(line);
		}
		bufferedReader.close();
		Assert.assertTrue(lines.size() == 6);
		Assert.assertTrue(lines.get(0).equals("*1;20220715;00001"));
		Assert.assertTrue(lines.get(1).equals("I;0001771038;221960001771038;20220715;;DA1"));
		Assert.assertTrue(lines.get(2).equals("I;0001771038;221960001771038;20220715;;EI1"));
		Assert.assertTrue(lines.get(3).equals("I;0001771038;221960001771038;20220715;;RC1"));
		Assert.assertTrue(lines.get(4).equals("D;0001771038;221960001771038;;;;;"));
		Assert.assertTrue(lines.get(5).equals("*9;20220715;00001;000000000000006"));
	}


	private static void initSituationDefaut() {
		doInTransaction(() -> {
			RmnSituationDefaut situationDefaut = new RmnSituationDefaut();
			situationDefaut.setDatePhoto(LocalDate.of(2021, 12, 7));
			situationDefaut.setIdSituation(String.valueOf(1L));
			situationDefaut.setIdFederal("0000002870");
			situationDefaut.setOrigine("ORIGINE2");
			getEntityManager().persist(situationDefaut);

		});
	}

	private static void initSituationDefautSain() {
		doInTransaction(() -> {
			RmnSituationDefaut situationDefaut = new RmnSituationDefaut();
			situationDefaut.setDatePhoto(LocalDate.of(2021, 12, 7));
			situationDefaut.setIdSituation(String.valueOf(1L));
			situationDefaut.setIdFederal("0000002870");
			situationDefaut.setOrigine("ENTREE MDC");
			situationDefaut.setPalierEffectif(null);
			getEntityManager().persist(situationDefaut);

		});
	}


	private static void initDataIncidentStandard() {
		doInTransaction(() -> {
			SyntheseIncident incident = new SyntheseIncident();
			incident.setDatePhoto(LocalDate.of(2021, 12, 7));
			incident.setIdSituationIncident(1L);
			incident.setIdRft("0000002870");
			incident.setCode("RC1");
			incident.setMotifPhoto("STANDARD");
			incident.setDateDebut(LocalDate.of(2021, 11, 27));
			getEntityManager().persist(incident);

		});
	}

	private static void initDataIncident15072022904() {
		doInTransaction(() -> {

			SyntheseIncident incident1507DA1 = new SyntheseIncident();
			incident1507DA1.setDatePhoto(LocalDate.of(2022, 07, 15));
			incident1507DA1.setIdSituationIncident(221960001771038L);
			incident1507DA1.setIdRft("0001771038");
			incident1507DA1.setCode("DA1");
			incident1507DA1.setMotifPhoto("STANDARD");
			incident1507DA1.setDateDebut(LocalDate.of(2022, 07, 15));
			getEntityManager().persist(incident1507DA1);

			SyntheseIncident incident1507EI1 = new SyntheseIncident();
			incident1507EI1.setDatePhoto(LocalDate.of(2022, 07, 15));
			incident1507EI1.setIdSituationIncident(221960001771038L);
			incident1507EI1.setIdRft("0001771038");
			incident1507EI1.setCode("EI1");
			incident1507EI1.setMotifPhoto("STANDARD");
			incident1507EI1.setDateDebut(LocalDate.of(2022, 07, 15));
			getEntityManager().persist(incident1507EI1);

			SyntheseIncident incident1507RC1 = new SyntheseIncident();
			incident1507RC1.setDatePhoto(LocalDate.of(2022, 07, 15));
			incident1507RC1.setIdSituationIncident(221960001771038L);
			incident1507RC1.setIdRft("0001771038");
			incident1507RC1.setCode("RC1");
			incident1507RC1.setMotifPhoto("STANDARD");
			incident1507RC1.setDateDebut(LocalDate.of(2022, 07, 15));
			getEntityManager().persist(incident1507RC1);

		});
	}

	private static void initDataIncident16072022904() {
		doInTransaction(() -> {

			SyntheseIncident incident1607DA1 = new SyntheseIncident();
			incident1607DA1.setDatePhoto(LocalDate.of(2022, 07, 16));
			incident1607DA1.setIdSituationIncident(221970001771038L);
			incident1607DA1.setIdRft("0001771038");
			incident1607DA1.setCode("DA1");
			incident1607DA1.setMotifPhoto("STANDARD");
			incident1607DA1.setDateDebut(LocalDate.of(2022, 07, 16));
			getEntityManager().persist(incident1607DA1);

			SyntheseIncident incident1607EI1 = new SyntheseIncident();
			incident1607EI1.setDatePhoto(LocalDate.of(2022, 07, 16));
			incident1607EI1.setIdSituationIncident(221970001771038L);
			incident1607EI1.setIdRft("0001771038");
			incident1607EI1.setCode("EI1");
			incident1607EI1.setMotifPhoto("STANDARD");
			incident1607EI1.setDateDebut(LocalDate.of(2022, 07, 16));
			getEntityManager().persist(incident1607EI1);

		});
	}

	private static void initDataIncident18072022904() {
		doInTransaction(() -> {

			SyntheseIncident incident1807DA1 = new SyntheseIncident();
			incident1807DA1.setDatePhoto(LocalDate.of(2022, 07, 18));
			incident1807DA1.setIdSituationIncident(221990001771038L);
			incident1807DA1.setIdRft("0001771038");
			incident1807DA1.setCode("DA1");
			incident1807DA1.setMotifPhoto("STANDARD");
			incident1807DA1.setDateDebut(LocalDate.of(2022, 07, 16));
			getEntityManager().persist(incident1807DA1);

			SyntheseIncident incident1807EI1 = new SyntheseIncident();
			incident1807EI1.setDatePhoto(LocalDate.of(2022, 07, 18));
			incident1807EI1.setIdSituationIncident(221990001771038L);
			incident1807EI1.setIdRft("0001771038");
			incident1807EI1.setCode("EI1");
			incident1807EI1.setMotifPhoto("STANDARD");
			incident1807EI1.setDateDebut(LocalDate.of(2022, 07, 16));
			getEntityManager().persist(incident1807EI1);

			SyntheseIncident incident1807DA2 = new SyntheseIncident();
			incident1807DA2.setDatePhoto(LocalDate.of(2022, 07, 18));
			incident1807DA2.setIdSituationIncident(221990001771038L);
			incident1807DA2.setIdRft("0001771038");
			incident1807DA2.setCode("DA2");
			incident1807DA2.setMotifPhoto("STANDARD");
			incident1807DA2.setDateDebut(LocalDate.of(2022, 07, 18));
			getEntityManager().persist(incident1807DA2);

		});
	}

	private static void initDataDefaut90415072022() {
		doInTransaction(() -> {
			RmnSituationDefaut situationDefaut = new RmnSituationDefaut();
			situationDefaut.setDatePhoto(LocalDate.of(2022, 7, 15));
			situationDefaut.setIdSituation(String.valueOf(221960001771038L));
			situationDefaut.setIdFederal("0001771038");
			situationDefaut.setOrigine("ENTREE MDC");
			situationDefaut.setPalierEffectif(null);
			situationDefaut.setMotifStatut("INI");
			situationDefaut.setCodeSegment("1010");
			situationDefaut.setCodTypNot("CORP");
			getEntityManager().persist(situationDefaut);

		});
	}

	private static void initDataDefaut90417072022() {
		doInTransaction(() -> {

			RmnSituationDefaut situationDefaut2 = new RmnSituationDefaut();
			situationDefaut2.setDatePhoto(LocalDate.of(2022, 7, 17));
			situationDefaut2.setIdSituation(String.valueOf(221980001771038L));
			situationDefaut2.setIdFederal("0001771038");
			situationDefaut2.setOrigine("CHGT PALIER");
			situationDefaut2.setPalierEffectif("CX");
			situationDefaut2.setMotifStatut("DT");
			situationDefaut2.setCodeSegment("1010");
			situationDefaut2.setCodTypNot("CORP");
			situationDefaut2.setDatePalierEffectif(LocalDate.of(2022, 7, 17));
			getEntityManager().persist(situationDefaut2);
		});
	}


	private static void initDataCloture() {
		doInTransaction(() -> {
			SyntheseIncident incident = new SyntheseIncident();
			incident.setDatePhoto(LocalDate.of(2021, 12, 7));
			incident.setIdSituationIncident(1L);
			incident.setIdRft("0000002870");
			incident.setCode("RC1");
			incident.setMotifPhoto("MOTIF_CLOTURE");
			incident.setDateDebut(LocalDate.of(2021, 11, 27));
			incident.setDateFin(LocalDate.of(2021, 11, 27).plusDays(10));
			getEntityManager().persist(incident);
		});
	}

	private static void initDataAnn() {
		doInTransaction(() -> {
			SyntheseIncident incident = new SyntheseIncident();
			incident.setDatePhoto(LocalDate.of(2021, 12, 7));
			incident.setIdSituationIncident(1L);
			incident.setIdRft("0000002870");
			incident.setMotifPhoto("ANN");
			getEntityManager().persist(incident);
		});
	}

	private static void initDataSeg() {
		doInTransaction(() -> {
			SyntheseIncident incident = new SyntheseIncident();
			incident.setDatePhoto(LocalDate.of(2021, 12, 7));
			incident.setIdSituationIncident(1L);
			incident.setIdRft("0000002870");
			incident.setMotifPhoto("SEG");
			getEntityManager().persist(incident);
		});
	}

	/**
	 * Initialiser le contexte Spring avant le démarrage des tests
	 *
	 * @throws NoSuchFieldException
	 * @throws IllegalAccessException
	 * @throws IOException
	 */
	@BeforeClass
	public static void initSpring() throws IOException, NoSuchFieldException, SecurityException,
			IllegalArgumentException, IllegalAccessException {
		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		transactionTemplate = new TransactionTemplate(getTransactionManager());
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		Properties properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);

		Launcher.setApplicationContext(context);
		Launcher.setIsTest(true);
		Launcher.setLogFile("log4j.properties");
	}

	/**
	 * Vider les tables après chaque test
	 */
	@Before
	public void initDirectory() {

		FileCommunUtils.checkRepertoire(REP_OUT_ROOT);

	}

	/**
	 * Vider les tables après chaque test
	 */
	@After
	public void resetData() {
		deleteAllTables();
		deleteDirectory(new File(REP_OUT_ROOT));
		deleteDirectory(new File(REP_OUT_TMP));
	}

	private static boolean deleteDirectory(File directoryToBeDeleted) {
		File[] allContents = directoryToBeDeleted.listFiles();
		if (allContents != null) {
			for (File file : allContents) {
				deleteDirectory(file);
			}
		}
		return directoryToBeDeleted.delete();
	}
}
