package bpce.yyd.batch.calcul_stats_oracle;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import fr.bpce.yyd.batch.commun.constantes.Constant;

public class IntegrationTest {

	private static ApplicationContext context = null;
	protected static TransactionTemplate transactionTemplate = null;

	@FunctionalInterface
	public interface TransactionCallback {
		void doInTransaction();
	}

	@BeforeClass
	public static void initSpring() {
		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		transactionTemplate = new TransactionTemplate(getTransactionManager());
		initData();

	}

	public static ApplicationContext getContext() {
		return context;
	}

	@Test
	public void launchKO() {
		JobExecution jobExec = null;
		try {
			jobExec = lauchBatch();
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(jobExec);
		assertEquals(ExitStatus.FAILED, jobExec.getExitStatus());
		String errorMess = jobExec.getAllFailureExceptions().get(0).getMessage();
		assertTrue(errorMess.contains("Function \"SYS_CONTEXT\" not found"));
	}

	private static void initData() {

		doInTransaction(() -> {

			EntityManager entityManager = getEntityManager();
			Query queryDrop = entityManager.createNativeQuery("drop table all_tables if exists");
			queryDrop.executeUpdate();
			Query queryCreate = entityManager
					.createNativeQuery("CREATE TABLE all_tables (  ID NUMBER(19,0) AUTO_INCREMENT,"
							+ "  TABLE_NAME  VARCHAR2(5000), TYPE  VARCHAR2(120))");
			queryCreate.executeUpdate();
		});
	}

	public static void doInTransaction(final TransactionCallback checker) {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				checker.doInTransaction();
			}
		});
	}

	public static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	public static EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	public JobExecution lauchBatch() throws Exception {
		Job job = (Job) context.getBean(Constant.JOB_CALCUL_STATS_ORACLE);
		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		JobParameters jobParameters = new JobParametersBuilder().addLong("guid", guid).toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

}
