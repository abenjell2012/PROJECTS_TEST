package bpce.yyd.batch.calcul_stats_oracle.tu;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

import bpce.yyd.batch.calcul_stats_oracle.task.CalculStatsTasklet;
import fr.bpce.yyd.batch.commun.utils.CalculStatsUtils;

@RunWith(PowerMockRunner.class)
@PrepareForTest(value = { CalculStatsUtils.class })
public class CalculStatsTaskletTest {

	@Mock
	private JdbcTemplate jdbcTemplate;

	@InjectMocks
	private CalculStatsTasklet calculStatsTasklet;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testExecuteTasklet() throws Exception {
		PowerMockito.mockStatic(CalculStatsUtils.class);
		StepContribution contribution = Mockito.mock(StepContribution.class);
		ChunkContext chunkContext = Mockito.mock(ChunkContext.class);
		Mockito.when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.eq(String.class)))
				.thenReturn(Arrays.asList("EVENEMENT", "IDENTITE_TIERS", "TIERS", "COMPLEMENT_EVENEMENT"));
		RepeatStatus status = calculStatsTasklet.execute(contribution, chunkContext);
		PowerMockito.verifyStatic(CalculStatsUtils.class, times(4));
		CalculStatsUtils.calculStatTable(Mockito.any(JdbcTemplate.class), Mockito.anyString(), Mockito.eq(4));
		assertEquals(RepeatStatus.FINISHED, status);
	}

}
