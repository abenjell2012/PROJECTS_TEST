package bpce.yyd.batch.calcul_stats_oracle.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import lombok.extern.slf4j.Slf4j;

/**
 * launcher class
 *
 * @author benjelloun
 *
 */
@Slf4j
public class Launcher {

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public void runBatch() {

		log.info("Debut BATCH NDOD : CALCUL STATS ORACLE");

		Job job = (Job) getApplicationContext().getBean(Constant.JOB_CALCUL_STATS_ORACLE);
		JobLauncher jobLauncher = null;
		try {
			jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");
		} catch (IllegalStateException e) {
			logAndExit(e);
		}

		Long guid = java.util.UUID.randomUUID().getMostSignificantBits();
		JobParameters jobParameters = new JobParametersBuilder().addLong("guid", guid).toJobParameters();
		if (jobLauncher != null) {
			runBatch(job, jobLauncher, jobParameters);
		}

		log.info("Fin BATCH NDOD : CALCUL STATS ORACLE");

	}

	private void runBatch(Job job, JobLauncher jobLauncher, JobParameters jobParameters) {
		JobExecution execution = null;

		try {
			execution = jobLauncher.run(job, jobParameters);
		} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
				| NullPointerException | JobParametersInvalidException e) {
			logAndExit(e);
		} finally {
			finaliserTraitement(batchStatus(execution));
		}

	}

	private void logAndExit(Exception err) {
		log.error("Erreur inattendue : " + err.getMessage(), err);
		exitWithErrorCode(1);
	}

	public static void main(String[] args) {

		PropertyConfigurator
				.configure(ClassLoader.getSystemClassLoader().getResource("log4j-calcul-stats-oracle.properties"));
		Launcher launcher = new Launcher();
		launcher.runBatch();
	}
}