package bpce.yyd.batch.calcul_stats_oracle.task;

import java.util.Iterator;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import fr.bpce.yyd.batch.commun.utils.CalculStatsUtils;
import lombok.extern.slf4j.Slf4j;

/**
 * Tasklet
 *
 * @author HANIA Michael
 *
 */

@Slf4j
public class CalculStatsTasklet implements Tasklet {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String TABLES_NDOD_QUERY = "select table_name from all_tables where owner = (select sys_context('userenv','current_schema') from dual)";

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		List<String> listTables = jdbcTemplate.queryForList(TABLES_NDOD_QUERY, String.class);

		log.info("calcul stats Oracle pour <" + listTables.size() + "> table(s)");

		for (Iterator<String> iterator = listTables.iterator(); iterator.hasNext();) {
			String table = iterator.next();
			log.info("Debut calcul stats Oracle <" + table + ">");

			CalculStatsUtils.calculStatTable(jdbcTemplate, table, 4);
		}
		log.info("Fin de calcul stats Oracle");

		return RepeatStatus.FINISHED;
	}

}
