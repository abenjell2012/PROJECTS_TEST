package fr.bpce.yyd.batch.check_group_consumer.lauch;

import java.text.MessageFormat;

import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.log4j.PropertyConfigurator;

import fr.bpce.yyd.batch.check_group_consumer.kafka.GroupConsumer;
import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Launcher {

	public static void main(String[] args) {
		try {
			PropertyConfigurator
					.configure(ClassLoader.getSystemClassLoader().getResource("log4j-group-consumer.properties"));

			String param = args[0];
			String envKafka = ConfigManager.getProperty("kafka.env");
			String groupIdSuffix = ConfigManager.getProperty("kafka.group_id_suffix");

			if ("trt-evt".equals(param)) {
				// Vérifier le topic traitement-evenement
				GroupConsumer groupConsumerTrtEvt = new GroupConsumer();
				String topicNameTrtEvt = ConfigManager.getProperty("kafka.topic.calcul_liste");
				String topicTrtEvt = MessageFormat.format("BF_{0}_{1}", envKafka, topicNameTrtEvt);
				String groupIdTrtEvtPrefix = ConfigManager.getProperty("kafka.group_id_trt_evt");
				String groupIdTrtEvt = MessageFormat.format("{0}{1}", groupIdTrtEvtPrefix, groupIdSuffix);
				KafkaConsumer<String, String> consumerTrtEvt = groupConsumerTrtEvt.getConsumer(groupIdTrtEvt);
				long lagTrtEvt = groupConsumerTrtEvt.getLagTopic(consumerTrtEvt, topicTrtEvt);
				exitCode(lagTrtEvt > 0 ? 1 : 0);

			} else if ("compteur".equals(param)) {
				// Vérifier le topic Compteur
				GroupConsumer groupConsumerCompteur = new GroupConsumer();
				String topicNameCompteur = ConfigManager.getProperty("kafka.topic.compteurs_liste");
				String topicCompteur = MessageFormat.format("BF_{0}_{1}", envKafka, topicNameCompteur);
				String groupIdCompteurPrefix = ConfigManager.getProperty("kafka.group_id_compteur");
				String groupIdCompteur = MessageFormat.format("{0}{1}", groupIdCompteurPrefix, groupIdSuffix);
				KafkaConsumer<String, String> consumerCompteur = groupConsumerCompteur.getConsumer(groupIdCompteur);
				long lagCompteur = groupConsumerCompteur.getLagTopic(consumerCompteur, topicCompteur);
				exitCode(lagCompteur > 0 ? 1 : 0);
			} else {
				exitCode(-1);
			}
		} catch (UnknownPropertyException | InvalidInitialisationException e) {
			log.warn("erreur : " + e.getMessage());
		}
	}

	/**
	 * Fait en sorte que le code de sortie de la JVM soit 'exitCode', tout en lui
	 * permettant d'aller jusqu'à sa séquence de sortie.
	 *
	 * @param exitCode
	 */
	public static void exitCode(final long exitCode) {
		Runtime.getRuntime().addShutdownHook(new Thread(() -> Runtime.getRuntime().halt((int) exitCode)));
	}
}