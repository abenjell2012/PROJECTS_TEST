package fr.bpce.yyd.batch.check_group_consumer.kafka;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.TopicPartition;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.commun.constantes.Constant;

public class GroupConsumer {
	public static final String KAFKA_SECURITY_PROTOCOL_CONFIG = "security.protocol";
	public static final String KAFKA_SSL_TRUSTSTORE_LOCATION_CONFIG = "ssl.truststore.location";
	public static final String KAFKA_SSL_TRUSTSTORE_PASS_CONFIG = "ssl.truststore.password";
	public static final String KAFKA_SASL_MECHANISM_CONFIG = "sasl.mechanism";
	public static final String KAFKA_SASL_JAAS_CONFIG_CONFIG = "sasl.jaas.config";
	public static final String SASL_SSL = "SASL_SSL";
	public static final String SCRAM_SHA_512 = "SCRAM-SHA-512";

	public KafkaConsumer<String, String> getConsumer(String groupId)
			throws UnknownPropertyException, InvalidInitialisationException {

		String securityActif = ConfigManager.getProperty("kafka.security_actif");
		String bootstrapServersConfig = ConfigManager.getProperty("kafka.bootstrap_servers_config");

		Properties props = new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServersConfig);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
		props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "1");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		if (Boolean.TRUE.equals(Boolean.valueOf(securityActif))) {
			String sslTrustStoreLoc = ConfigManager.getProperty("kafka.ssl_truststore_location");
			String sslTrustStorePass = ConfigManager.getProperty("kafka.ssl_truststore_password");
			String saslConsUser = ConfigManager.getProperty("kafka.sasl_consumer_user");
			String saslConsPass = ConfigManager.getProperty("kafka.sasl_consumer_password");
			props.put(KAFKA_SECURITY_PROTOCOL_CONFIG, SASL_SSL);
			props.put(KAFKA_SSL_TRUSTSTORE_LOCATION_CONFIG, sslTrustStoreLoc);
			props.put(KAFKA_SSL_TRUSTSTORE_PASS_CONFIG, sslTrustStorePass);
			props.put(KAFKA_SASL_MECHANISM_CONFIG, SCRAM_SHA_512);
			props.put(KAFKA_SASL_JAAS_CONFIG_CONFIG,
					MessageFormat.format(Constant.JAAS_CONFIG_SCRAMLOGIN, saslConsUser, saslConsPass));
		}

		return new KafkaConsumer<>(props);
	}

	public Long getLagTopic(KafkaConsumer<String, String> consumer, String topic) {
		long lag = 0l;
		Map<String, List<PartitionInfo>> topics = consumer.listTopics();
		List<PartitionInfo> partitionInfos = topics.get(topic);
		Collection<TopicPartition> partitions = new ArrayList<>();
		for (PartitionInfo partitionInfo : partitionInfos) {
			TopicPartition partition = new TopicPartition(topic, partitionInfo.partition());
			partitions.add(partition);
		}
		consumer.assign(partitions);

		for (TopicPartition partition : partitions) {
			Map<TopicPartition, Long> endingOffsets = consumer.endOffsets(partitions);
			lag += endingOffsets.get(partition) - consumer.position(partition);
		}
		return lag;
	}
}
