package fr.bpce.yyd.batch.check_group_consumer.ti;

public class TestsLauncher {

}
