package fr.bpce.yyd.batch.commun.service.impl;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.service.ReferenceImportSrvc;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.ArrayList;
import java.util.List;


@Service
@Scope("singleton")
public class ReferenceImportSrvcImpl implements ReferenceImportSrvc {

	private static final String PARAM_TOP_SUPPR = "topSuppr";

	private static final Logger LOGGER = Logger.getLogger(ReferenceImportSrvcImpl.class);

	@Autowired
	private EntityManager entityManager;

	private List<String> codbqList = new ArrayList<>();

	@Override
	public List<String> getCodBqReferenceList() {
		if (codbqList.isEmpty()) {
			LOGGER.info("récupération du référentiel CODE_BQ");
			TypedQuery<String> query = entityManager.createQuery("select codBq from RefBqBfbp where topSuppr=:topSuppr",
					String.class);
			query.setParameter(PARAM_TOP_SUPPR, Constant.FLAG_NON);
			codbqList = query.getResultList();
		}
		return codbqList;

	}

	public void setCodbqList(List<String> codbqList) {
		this.codbqList = codbqList;
	}



}
