package fr.bpce.yyd.batch.commun.mapper;

import fr.bpce.yyd.batch.commun.beans.DataEventLocal;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DataEventLocalMapper implements RowMapper<DataEventLocal> {

	@Override
	public DataEventLocal mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataEventLocal dataEventLocal = new DataEventLocal();
		dataEventLocal.setIdSynthese((rs.getBigDecimal(1) == null) ? null : rs.getLong(1));
		dataEventLocal.setCodeBq(rs.getString(2));
		dataEventLocal.setIdLocal(rs.getString(3));
		dataEventLocal.setCode(rs.getString(4));
		dataEventLocal.setType(rs.getString(5));
		dataEventLocal.setDateDebut(rs.getDate(6));
		dataEventLocal.setDatePhoto(rs.getDate(7));
		dataEventLocal.setDateCloture(rs.getDate(8));
		dataEventLocal.setStatutEvenement(rs.getString(9));
		dataEventLocal.setDateMaj(rs.getDate(10));
		dataEventLocal.setCommentaire(rs.getString(11));
		dataEventLocal.setArriereTech(rs.getBoolean(12));
		dataEventLocal.setArriereLitige(rs.getBoolean(13));
		dataEventLocal.setMontantArriere(rs.getBigDecimal(14));
		dataEventLocal.setIdContrat(rs.getString(15));

		return dataEventLocal;
	}

}
