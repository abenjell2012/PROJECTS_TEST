package fr.bpce.yyd.batch.commun.beans;

import lombok.Data;

@Data
public class DataIDSyntheseTiers {

	private Long idSynthese;

	private Long idSituation;

}
