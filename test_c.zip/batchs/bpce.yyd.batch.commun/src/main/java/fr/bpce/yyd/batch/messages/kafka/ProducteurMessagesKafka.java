package fr.bpce.yyd.batch.messages.kafka;

import java.text.MessageFormat;
import java.util.EnumMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.messages.AbstractProducteurMessages;
import fr.bpce.yyd.batch.commun.messages.Topic;
import fr.bpce.yyd.commun.constantes.Constant;

/**
 * Implementation Kafka du producteur de messages, capable d'écrire sur
 * plusieurs topics des messages, que l'on peut passer comme des objets qui
 * seront sérialisés en JSON (en utilisant Jackson).
 *
 * @author dossantos
 * @author zgud
 *
 */
public class ProducteurMessagesKafka extends AbstractProducteurMessages {

	private static final Logger log = LoggerFactory.getLogger(ProducteurMessagesKafka.class);

	private Map<Topic, Producer<Long, String>> producers = new EnumMap<>(Topic.class);
	private Producer<Long, String> producer = null;

	private Producer<Long, String> getProducer(Topic topic)
			throws UnknownPropertyException, InvalidInitialisationException {
		String bootstrapServersConfig = ConfigManager.getProperty("kafka.bootstrap_servers_config");
		String securityActif = ConfigManager.getProperty("kafka.security_actif");
		String sslTrustStoreLoc = ConfigManager.getProperty("kafka.ssl_truststore_location");
		String sslTrustStorePass = ConfigManager.getProperty("kafka.ssl_truststore_password");
		String saslProdUser = ConfigManager.getProperty("kafka.sasl_producer_user");
		String saslProdPass = ConfigManager.getProperty("kafka.sasl_producer_password");

		return producers.computeIfAbsent(topic, t -> {
			Properties properties = new Properties();
			properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServersConfig);
			properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, LongSerializer.class.getName());
			properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
			if (Boolean.TRUE.equals(Boolean.valueOf(securityActif))) {
				properties.put(Constant.KAFKA_SECURITY_PROTOCOL_CONFIG, Constant.SASL_SSL);
				properties.put(Constant.KAFKA_SSL_TRUSTSTORE_LOCATION_CONFIG, sslTrustStoreLoc);
				properties.put(Constant.KAFKA_SSL_TRUSTSTORE_PASS_CONFIG, sslTrustStorePass);
				properties.put(Constant.KAFKA_SASL_MECHANISM_CONFIG, Constant.SCRAM_SHA_512);
				if (Topic.NOTIF_RMN.equals(topic)) {
					try {
						String saslNotifRmnProdUser = ConfigManager.getProperty("kafka.sasl_notif_rmn_producer_user");
						String saslNotifRmnProdPass = ConfigManager
								.getProperty("kafka.sasl_notif_rmn_producer_password");
						properties.put(Constant.KAFKA_SASL_JAAS_CONFIG_CONFIG, MessageFormat
								.format(Constant.JAAS_CONFIG_SCRAMLOGIN, saslNotifRmnProdUser, saslNotifRmnProdPass));
					} catch (UnknownPropertyException | InvalidInitialisationException e) {
						throw new IllegalStateException("Impossible d'initialiser un producteur kafka", e);
					}
				} else {
					properties.put(Constant.KAFKA_SASL_JAAS_CONFIG_CONFIG,
							MessageFormat.format(Constant.JAAS_CONFIG_SCRAMLOGIN, saslProdUser, saslProdPass));
				}
			}
			return new KafkaProducer<>(properties);
		});
	}

	@Override
	public void envoieMessageJSON(Topic topic, String name, String message) {
		if (producer == null) {
			try {
				producer = getProducer(topic);
			} catch (UnknownPropertyException | InvalidInitialisationException e) {
				throw new IllegalStateException("Impossible d'initialiser un producteur kafka", e);
			}
		}
		String kafkaEnv;
		try {
			kafkaEnv = ConfigManager.getProperty("kafka.env");
		} catch (UnknownPropertyException | InvalidInitialisationException e) {
			throw new IllegalStateException("variable kafka.env obligatoire", e);
		}
		TopicKafka topicK = TopicKafka.fromTopic(topic);
		ProducerRecord<Long, String> enregistrement = null;

		if (topic.equals(Topic.NOTIF_RMN)) {
			Long msgId = UUID.randomUUID().getMostSignificantBits();
			enregistrement = new ProducerRecord<>(topicK.getTopicName(kafkaEnv, name), msgId, message);
			enregistrement.headers().add("CustomHeader-MsgId", msgId.toString().getBytes());
			enregistrement.headers().add("CustomHeader-Provider", "YYD".getBytes());
		} else {
			enregistrement = new ProducerRecord<>(topicK.getTopicName(kafkaEnv, name), message);
		}

		long time = System.currentTimeMillis();
		try {
			RecordMetadata metadata = producer.send(enregistrement).get();
			if (log.isInfoEnabled()) {
				log.info(
						"Envoyé enregistrement(key=[{}] value=[{}]) meta(partition=[{}], offset=[{}]) tempsEnvoiMEssage=[{}] topic=[{}]\n",
						enregistrement.key(), enregistrement.value(), metadata.partition(), metadata.offset(),
						(System.currentTimeMillis() - time), topicK.getTopicName(kafkaEnv, name));
			}
			producer.flush();
		} catch (ExecutionException e) {
			log.error("Message : {} \n {}", enregistrement, e.getMessage());
		} catch (InterruptedException e) {
			log.error("InterruptedException : {} \n {}", enregistrement, e.getMessage());
			// sonar correction
			Thread.currentThread().interrupt();

		} finally {
			producer.flush();
			producer.close();
		}

	}

	@Override
	public void arretProducteur(Topic topic) {
		Producer<Long, String> currentProducer = producers.get(topic);
		if (currentProducer != null) {
			currentProducer.close();
		}
	}

}
