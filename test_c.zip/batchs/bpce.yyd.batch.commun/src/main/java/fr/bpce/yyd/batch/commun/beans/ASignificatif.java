package fr.bpce.yyd.batch.commun.beans;

import java.sql.Date;
import java.time.LocalDate;

import fr.bpce.yyd.commun.converters.LocalDatePersistenceConverter;
import lombok.Data;

@Data
public class ASignificatif {

	private LocalDate dateDebut;

	private LocalDate dateFin;

	private Long idTiers;

	public ASignificatif(Date dateDebut, Date dateFin, Long idTiers) {
		LocalDatePersistenceConverter convertisseur = new LocalDatePersistenceConverter();
		this.dateDebut = convertisseur.convertToEntityAttribute(dateDebut);
		this.dateFin = convertisseur.convertToEntityAttribute(dateFin);
		this.idTiers = idTiers;
	}

}
