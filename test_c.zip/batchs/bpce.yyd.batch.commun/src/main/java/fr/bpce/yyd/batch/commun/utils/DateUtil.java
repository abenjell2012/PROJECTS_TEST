package fr.bpce.yyd.batch.commun.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.util.Assert;

import fr.bpce.yyd.batch.commun.constantes.Constant;

public class DateUtil {

	public static final boolean isDatesOverlaps(LocalDate start1, LocalDate end1, LocalDate start2, LocalDate end2) {

		// les dates de débuts ne peuvent pas être nulles
		if (start1 == null || start2 == null) {
			throw new IllegalArgumentException("les dates start1, start2 ne peuvent pas être NULL");
		}
		// 2 intervalles infini [starti- infini [ => chevauchement
		if (end1 == null && end2 == null) {
			return true;
		}
		// premier intervalle infini
		if (end1 == null) {
			return end2.compareTo(start1) > 0;
		}
		// deuxième intervalle infini
		if (end2 == null) {
			return start2.compareTo(end1) < 0;
		}
		return start1.compareTo(end2) < 0 && start2.compareTo(end1) < 0;

	}

	public static Pair<Boolean, LocalDate> isFormatDateValide(String dateString, DateTimeFormatter formater) {

		LocalDate dateParse = null;
		try {
			dateParse = LocalDate.parse(dateString, formater);
		} catch (DateTimeParseException e) {
			return new ImmutablePair<>(false, null);
		}
		return new ImmutablePair<>(true, dateParse);
	}

	public static boolean isFormatDateValid(String dateString, DateTimeFormatter formater) {
		try {
			LocalDate.parse(dateString, formater);
		} catch (DateTimeParseException e) {
			return false;
		}
		return true;
	}

	public static LocalDate parseDate(String dateStr) {
		return LocalDate.parse(dateStr, Constant.YYYYMMDD_FORMATTER);
	}

	public static void main(String[] args) {
		LocalDate date1 = LocalDate.of(2019, 5, 1);
		LocalDate date2 = LocalDate.of(2019, 6, 1);
		LocalDate date3 = LocalDate.of(2019, 5, 3);
		LocalDate date4 = LocalDate.of(2019, 7, 1);

		boolean res1 = isDatesOverlaps(date1, date2, date3, date4);

		Assert.isTrue(res1);

		LocalDate date5 = LocalDate.of(2019, 5, 01);
		LocalDate date6 = LocalDate.of(2019, 6, 01);
		LocalDate date7 = LocalDate.of(2019, 7, 03);
		LocalDate date8 = LocalDate.of(2019, 8, 01);

		boolean res2 = isDatesOverlaps(date5, date6, date7, date8);

		Assert.isTrue(!res2);

		LocalDate date9 = LocalDate.of(2019, 5, 01);
		LocalDate date10 = LocalDate.of(2019, 6, 01);
		LocalDate date11 = LocalDate.of(2019, 6, 01);
		LocalDate date12 = LocalDate.of(2019, 8, 01);

		boolean res3 = isDatesOverlaps(date9, date10, date11, date12);

		Assert.isTrue(!res3);

		LocalDate date13 = LocalDate.of(2019, 10, 01);
		LocalDate date14 = LocalDate.of(2019, 12, 01);
		LocalDate date15 = LocalDate.of(2019, 4, 01);
		LocalDate date16 = LocalDate.of(2019, 10, 01);

		boolean res4 = isDatesOverlaps(date13, date14, date15, date16);

		Assert.isTrue(!res4);

		LocalDate date17 = LocalDate.of(2019, 05, 01);
		LocalDate date18 = LocalDate.of(2019, 05, 23);
		LocalDate date19 = LocalDate.of(2019, 05, 24);
		LocalDate date20 = null;

		boolean res5 = isDatesOverlaps(date17, date18, date19, date20);

		Assert.isTrue(!res5);

		LocalDate date21 = LocalDate.of(2019, 05, 24);
		LocalDate date22 = null;
		LocalDate date23 = LocalDate.of(2019, 05, 01);
		LocalDate date24 = LocalDate.of(2019, 05, 23);

		boolean res6 = isDatesOverlaps(date21, date22, date23, date24);

		Assert.isTrue(!res6);

	}

}
