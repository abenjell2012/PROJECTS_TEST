package fr.bpce.yyd.batch.commun.service.impl;


import fr.bpce.yyd.batch.commun.service.FunctionnalCheckerSrvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@Scope("singleton")
public class FunctionnalCheckerSrvcImpl implements FunctionnalCheckerSrvc {

	@Autowired
	private ReferenceImportSrvcImpl referenceImportSrvcImpl;


	/**
	 * Teste l'existence du paramètre codBq comme attribut codBq de la table de
	 * référence REF_BQ_BFBP.
	 *
	 * @param codBq
	 * @return
	 */
	@Override
	public boolean isCodeBanqueValide(String codBq) {
		List<String> codeEtablissements = referenceImportSrvcImpl.getCodBqReferenceList();
		return codeEtablissements.contains(codBq);
	}

	public void setReferenceImportSrvcImpl(ReferenceImportSrvcImpl referenceImportSrvcImpl) {
		this.referenceImportSrvcImpl = referenceImportSrvcImpl;
	}

}
