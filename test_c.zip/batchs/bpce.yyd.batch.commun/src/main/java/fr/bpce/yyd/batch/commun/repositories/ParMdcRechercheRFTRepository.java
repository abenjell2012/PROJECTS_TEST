package fr.bpce.yyd.batch.commun.repositories;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.model.ParMdcRechercheRft;

@Repository
public class ParMdcRechercheRFTRepository {

	private EntityManager entityManager;

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Retourne la liste de code banque de recherche RFT
	 *
	 * @param codeBanqueTiers
	 * @return
	 */
	public Map<String, ParMdcRechercheRft> findBqSearchRft() {
		Query query = entityManager.createNamedQuery("banque.search.rft");
		Map<String, ParMdcRechercheRft> ret = new HashMap<>();

		for (Object line : query.getResultList()) {
			Object[] lineAsArray = (Object[]) line;
			ParMdcRechercheRft parMdcRechercheRft = new ParMdcRechercheRft();
			parMdcRechercheRft.setCodeBqTiers((String) lineAsArray[0]);
			parMdcRechercheRft.setCodeBqRechercheRft((String) lineAsArray[1]);

			ret.put((String) lineAsArray[0], parMdcRechercheRft);
		}
		return ret;
	}
}