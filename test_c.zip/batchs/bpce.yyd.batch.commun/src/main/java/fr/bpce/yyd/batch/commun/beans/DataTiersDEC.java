package fr.bpce.yyd.batch.commun.beans;

import lombok.Data;

@Data
public class DataTiersDEC {

	public String TiersId;

}
