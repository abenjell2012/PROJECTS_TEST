package fr.bpce.yyd.batch.commun.exception;

/**
 * Exception technique, comme tra�ant une erreur dans un appel de service � JBoss.
 *
 */
public class TechnicalException extends BatchException {

  private static final long serialVersionUID = -5106230975815047073L;

  public TechnicalException(String message) {
    super(message);
  }

  public TechnicalException(String message, Throwable initial) {
    super(message, initial);
  }
}
