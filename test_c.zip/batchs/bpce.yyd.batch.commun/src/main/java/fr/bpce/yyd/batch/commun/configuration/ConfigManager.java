package fr.bpce.yyd.batch.commun.configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;

public class ConfigManager {

	private static Properties properties = null;

	/**
	 * Nom du fichier de configuration par défaut.
	 */
	private static final String NOM_FICHIER_CONFIGURATION = "config.properties";
	private static final String MSG_NON_DISPONIBLE = " non disponible";

	private ConfigManager() {
		// Tout est statique. Cette classe n'est pas � instancier.
	}

	public static final void initConfigurationFile() throws InvalidInitialisationException {
		if (properties == null) {
			URL url = ClassLoader.getSystemClassLoader().getResource(NOM_FICHIER_CONFIGURATION);
			if (null == url) {
				throw new InvalidInitialisationException(
						"Fichier de configuration " + NOM_FICHIER_CONFIGURATION + MSG_NON_DISPONIBLE);
			}
			String filename = url.getPath();
			initConfigFile(filename);
		}
	}

	private static void initConfigFile(String filename) throws InvalidInitialisationException {
		if (filename == null || !new File(filename).exists()) {
			throw new InvalidInitialisationException("Fichier de configuration " + filename + MSG_NON_DISPONIBLE);
		}
		try {
			Properties props = new Properties();
			InputStream input = new FileInputStream(filename);
			props.load(input);
			input.close();
			properties = props;
		} catch (IOException ioe) {
			throw new InvalidInitialisationException(
					"Erreur en lecture du fichier de configuration " + filename + MSG_NON_DISPONIBLE, ioe);
		}
	}

	public static String getProperty(String key) throws UnknownPropertyException, InvalidInitialisationException {
		initConfigurationFile();
		String value = properties.getProperty(key);
		if (value == null) {
			throw new UnknownPropertyException("Propriété inconnue: " + key);
		}
		return value;
	}

	public static int getIntProperty(String key) throws UnknownPropertyException, InvalidInitialisationException {
		return Integer.parseInt(getProperty(key));
	}
}