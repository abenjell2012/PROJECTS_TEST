package fr.bpce.yyd.batch.commun.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import fr.bpce.yyd.commun.model.reference.RefPerimetreNotation;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.commun.model.AuditCalcul;
import fr.bpce.yyd.commun.model.AuditFichiers;
import fr.bpce.yyd.commun.model.AuditLignesImport;
import fr.bpce.yyd.commun.model.AuditRestitutionIncident;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ComplementEvenement;
import fr.bpce.yyd.commun.model.ComplementImpaye;
import fr.bpce.yyd.commun.model.Declencheur;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.Evenement;
import fr.bpce.yyd.commun.model.EvenementCalcule;
import fr.bpce.yyd.commun.model.EvtExistMdcNotFull;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.ImportEvenementSir;
import fr.bpce.yyd.commun.model.IncidentTiers;
import fr.bpce.yyd.commun.model.ParMdcSeg;
import fr.bpce.yyd.commun.model.RestCliDecl;
import fr.bpce.yyd.commun.model.RestDeclLastSynth;
import fr.bpce.yyd.commun.model.StatutHistorise;
import fr.bpce.yyd.commun.model.StatutSbv;
import fr.bpce.yyd.commun.model.SyntheseIncident;
import fr.bpce.yyd.commun.model.Tiers;
import fr.bpce.yyd.commun.model.TiersRFT;
import fr.bpce.yyd.commun.model.reference.ParGravite;
import fr.bpce.yyd.commun.model.reference.RefEvtNdod;
import fr.bpce.yyd.commun.model.restitution.RestAssociateRftSiren;
import fr.bpce.yyd.commun.model.restitution.RestRejetTiersSynthese;
import fr.bpce.yyd.commun.model.restitution.RestSeqLastSyntheseQ;
import fr.bpce.yyd.commun.model.restitution.RestSynthEvtLocauxStatus;
import fr.bpce.yyd.commun.model.restitution.RestSynthEvtLocauxStatusMensuelle;
import fr.bpce.yyd.commun.model.restitution.RestSynthEvtMDCStatus;
import fr.bpce.yyd.commun.model.restitution.RestSynthEvtMDCStatusMensuelle;
import fr.bpce.yyd.commun.model.restitution.RestSynthTierLocalStatus;
import fr.bpce.yyd.commun.model.restitution.RestTiersIdRft;
import fr.bpce.yyd.commun.model.restitution.RestTiersLocal;
import fr.bpce.yyd.commun.model.restitution.RestTiersSiren;
import fr.bpce.yyd.commun.model.restitution.SyntheseTiersMensuelle;
import fr.bpce.yyd.commun.model.restitution.rmn.RmnSituationDefaut;

public class AbstractTestIntegration {

	protected static ApplicationContext context = null;
	protected static TransactionTemplate transactionTemplate = null;

	@FunctionalInterface
	public interface TransactionCallback {
		void doInTransaction();
	}

	protected static void initSpring() throws IOException, NoSuchFieldException, IllegalAccessException {
		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		transactionTemplate = new TransactionTemplate(getTransactionManager());
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		Properties properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);

	}

	protected static ApplicationContext getContext() {
		return context;
	}

	protected static void doInTransaction(final TransactionCallback checker) {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				checker.doInTransaction();
			}
		});
	}

	protected static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	protected static EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	protected static void deleteAllTables() {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {

				// TABLES DE CALCUL
				deleteEntityData(AuditCalcul.class);
				deleteEntityData(StatutHistorise.class);
				deleteEntityData(ComplementArriere.class);
				deleteEntityData(ElementsDeCalcul.class);
				deleteEntityData(ComplementImpaye.class);
				deleteEntityData(EvenementCalcule.class);
				deleteEntityData(ParGravite.class);

				// Tables INCIDENTs
				deleteEntityData(AuditRestitutionIncident.class);
				deleteEntityData(IncidentTiers.class);
				deleteEntityData(SyntheseIncident.class);

				// TABLES DE LA COLLECTE
				deleteEntityData(AuditLignesImport.class);
				deleteEntityData(ComplementEvenement.class);
				deleteEntityData(Evenement.class);
				deleteEntityData(IdentiteTiers.class);
				deleteEntityData(Tiers.class);
				deleteEntityData(AuditFichiers.class);
				deleteEntityData(TiersRFT.class);
				deleteEntityData(ImportEvenementSir.class);
				deleteEntityData(EvtExistMdcNotFull.class);
				deleteEntityData(StatutSbv.class);

				// DECLENCHEUR
				deleteEntityData(Declencheur.class);
				deleteEntityData(RestCliDecl.class);
				deleteEntityData(RestDeclLastSynth.class);

				// SYNTHESE QUOT
				deleteEntityData(RestSynthEvtLocauxStatus.class);
				deleteEntityData(RestSynthEvtMDCStatus.class);
				deleteEntityData(RestSynthTierLocalStatus.class);
				// SYNTHESE MENS
				deleteEntityData(RestSynthEvtLocauxStatusMensuelle.class);
				deleteEntityData(RestSynthEvtMDCStatusMensuelle.class);
				deleteEntityData(SyntheseTiersMensuelle.class);
				// SYNTHESE TIERS ID_LOCAL
				deleteEntityData(RestTiersLocal.class);
				deleteEntityData(RestAssociateRftSiren.class);
				deleteEntityData(RestTiersIdRft.class);
				deleteEntityData(RestTiersSiren.class);

				// Restitution_RMN
				deleteEntityData(RmnSituationDefaut.class);

				// REF
				deleteEntityData(RefEvtNdod.class);
				deleteEntityData(RestSeqLastSyntheseQ.class);
				deleteEntityData(RestRejetTiersSynthese.class);

				// REF
				deleteEntityData(RefEvtNdod.class);
				deleteEntityData(RefPerimetreNotation.class);
				// ParMdcSeg
				deleteEntityData(ParMdcSeg.class);

				// Spring batch
				deleteTable("BATCH_JOB_EXECUTION_CONTEXT");
				deleteTable("BATCH_JOB_EXECUTION_PARAMS");
				deleteTable("BATCH_STEP_EXECUTION_CONTEXT");
				deleteTable("BATCH_STEP_EXECUTION");
				deleteTable("BATCH_JOB_EXECUTION");
				deleteTable("BATCH_JOB_INSTANCE");

			}
		});
	}

	protected static void deleteEntityData(Class<?> entityClass) {
		EntityManager entityManager = getEntityManager();
		Query delQuery = entityManager.createQuery("delete from " + entityClass.getSimpleName());
		delQuery.executeUpdate();
	}

	protected static void deleteTable(String table) {
		EntityManager entityManager = getEntityManager();
		Query delQuery = entityManager.createNativeQuery("delete from " + table);
		delQuery.executeUpdate();
	}

}
