package fr.bpce.yyd.batch.commun.utils;

import static fr.bpce.yyd.batch.commun.constantes.Constant.CHAR_ESPACE;
import static fr.bpce.yyd.batch.commun.constantes.Constant.CHAR_MOINS;
import static fr.bpce.yyd.batch.commun.constantes.Constant.CHAR_PLUS;
import static fr.bpce.yyd.batch.commun.constantes.Constant.CHAR_ZERO;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;

import fr.bpce.yyd.batch.commun.beans.DataEvenement;
import fr.bpce.yyd.batch.commun.beans.DetailTiersInfo;
import fr.bpce.yyd.commun.constantes.Constant;

public class RestitSyntheseUtils {

	private static final String QUERY_TIERS_SDA = "select st.id from statut_tiers st "
			+ "inner join identite_tiers i on i.tiers_id = st.tiers_id and i.date_fin is null "
			+ "inner join tiers t on t.id = i.tiers_id and t.id_rft is null "
			+ "where i.code_bq = ? and i.id_local = ? and st.statut = 'SAIN' and st.date_fin is null and st.motif = 'SDA' "
			+ "union all select st.id from statut_tiers st inner join tiers t on t.id = st.tiers_id "
			+ "inner join tiers_rft r on r.id_federal = t.id_rft and r.date_import = (select max(date_import) from tiers_rft) "
			+ "where r.code_banque = ? and r.id_local = ? and st.statut = 'SAIN' and st.date_fin is null and st.motif = 'SDA'";

	private RestitSyntheseUtils() {
	}

	/**
	 * méthode pour homogénéiser l'enqueue de tous les fichiers de restitution/
	 *
	 * @param codeBanque          : codeBanque du fichier
	 * @param                     size: le nombre de ligne du fichier
	 * @param dateConstitutionFic : date de constitution du fichier
	 * @return
	 */
	public static String generateEnqueueFic(String codeBanque, int size, String dateConstitutionFic) {

		StringBuilder enqueueBuilder = new StringBuilder();
		enqueueBuilder.append("*9");
		enqueueBuilder.append(dateConstitutionFic);
		enqueueBuilder.append(codeBanque);
		enqueueBuilder.append("MDC");
		enqueueBuilder.append("001+");
		enqueueBuilder.append(StringUtils.leftPad(Integer.toString(size), 14, CHAR_ZERO));

		return enqueueBuilder.toString();
	}

	public static String generateEnteteFic(String codeBanque, String dateConstitutionFic) {

		StringBuilder enteteBuilder = new StringBuilder();
		enteteBuilder.append("*1");
		enteteBuilder.append(dateConstitutionFic);
		enteteBuilder.append(codeBanque);
		enteteBuilder.append("MDC");
		enteteBuilder.append("001");

		return enteteBuilder.toString();
	}

	public static String generateDetailFicTiers(DetailTiersInfo detailTiers) {
		// longueurs
		// 15,8,10,5,50,4,2,2,8,4,500,1,8,1,1,1,3,8,3,30,18,18,18,18,8,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
		StringBuilder line = new StringBuilder();
		line.append(convertToFixedLength(detailTiers.getIdSituation(), 15));
		line.append(formatDateToYYYYDDMM(detailTiers.getDatePhoto()));
		line.append(convertToFixedLength(detailTiers.getIdFederal(), 10));
		line.append(convertToFixedLength(detailTiers.getCodeBanque(), 5));
		line.append(convertToFixedLength(detailTiers.getIdLocal(), 50));
		line.append(convertToFixedLength(detailTiers.getCodeSegment(), 4));
		line.append(convertToFixedLength(detailTiers.getStatutEff(), 2));
		line.append(convertToFixedLength(detailTiers.getPalierEff(), 2));
		line.append(formatDateToYYYYDDMM(detailTiers.getDateMajStatutEff()));
		line.append(convertToFixedLength(detailTiers.getOrigineStatutEff(), 4));
		line.append(convertToFixedLength(detailTiers.getCommentaireForcage(), 500));
		line.append(detailTiers.getTopPP());
		line.append(formatDateToYYYYDDMM(detailTiers.getDatePrevFinPP()));
		line.append(detailTiers.getTopF());
		line.append(detailTiers.getTopA());
		line.append(detailTiers.getTopAS());
		line.append(convertToFixedLength(detailTiers.getPalierAS(), 3));
		line.append(formatDateToYYYYDDMM(detailTiers.getDateMetierEvtEntreeDefautCalcule()));
		line.append(convertToFixedLength(detailTiers.getCodeEvtEntreeDefautCalcule(), 3));
		line.append(convertToFixedLength(detailTiers.getIdEvtEntreeDefaut(), 30));
		line.append(CHAR_PLUS + convertToFixedLength(detailTiers.getMontantTotalImx(), 17));
		line.append(CHAR_PLUS + convertToFixedLength(detailTiers.getMontantTotalDax(), 17));
		line.append(CHAR_PLUS + convertToFixedLength(detailTiers.getMontantTotalArrieres(), 17));
		line.append(convertMontantEncours(detailTiers.getMontantEngaConsolide()));
		line.append(formatDateToYYYYDDMM(detailTiers.getDarDonneeEngaConsolide()));
		line.append(detailTiers.getWarning1p1());
		line.append(detailTiers.getWarning1p2());
		line.append(detailTiers.getWarning1p3());
		line.append(detailTiers.getWarning1p4());
		line.append(detailTiers.getWarning2());
		line.append(detailTiers.getWarning3());
		line.append(detailTiers.getWarning4());
		line.append(detailTiers.getWarning5p1());
		line.append(detailTiers.getWarning5p2());
		line.append(detailTiers.getWarning5p3());
		line.append(detailTiers.getWarning6());
		line.append(detailTiers.getWarning7());
		line.append(detailTiers.getWarning8());
		line.append(detailTiers.getWarning9());
		line.append(detailTiers.getWarning10());

		return line.toString();
	}

	private static String convertMontantEncours(BigDecimal montantEngaConsolide) {
		char prefixSign = CHAR_PLUS;
		if (montantEngaConsolide == null) {
			return prefixSign + StringUtils.leftPad("0", 17, CHAR_ZERO);
		}
		// cas ou le montant est négatif => prendre la valeur absolue
		if (montantEngaConsolide.signum() < 0) {
			montantEngaConsolide = montantEngaConsolide.abs();
			prefixSign = CHAR_MOINS;
		}
		// gestion des chiffres apres virgules
		BigDecimal bg = montantEngaConsolide.setScale(2, RoundingMode.HALF_UP);
		long valeurEntiere = bg.multiply(new BigDecimal(100)).longValue();
		return prefixSign + StringUtils.leftPad(String.valueOf(valeurEntiere), 17, CHAR_ZERO);

	}

	public static String generateDetailFicEvents(DataEvenement dataEvenement) {

		StringBuilder line = new StringBuilder();
		line.append(convertToFixedLength(dataEvenement.getIdRft(), 10));
		line.append(convertToFixedLength(dataEvenement.getCodeBanque(), 5));
		line.append(convertToFixedLength(dataEvenement.getIdLocal(), 50));
		line.append(convertToFixedLength(dataEvenement.getIdEvent(), 30));
		line.append(convertToFixedLength(dataEvenement.getCode(), 3));
		line.append(convertToFixedLength(dataEvenement.getSousCode(), 4));
		line.append(convertCommentaire(dataEvenement.getCommentaire(), 200));
		line.append(convertToFixedLength(dataEvenement.getCodeBanqueE(), 5));
		line.append(convertToFixedLength(dataEvenement.getStatut(), 3));
		line.append(formatDateSqlToYYYYDDMM(dataEvenement.getDateDebut()));
		line.append(formatDateSqlToYYYYDDMM(dataEvenement.getDatePhoto()));
		line.append(formatDateSqlToYYYYDDMM(dataEvenement.getDateCloture()));
		line.append(convertToBoolean(dataEvenement.getTopTech()));
		line.append(convertToBoolean(dataEvenement.getTopLitige()));
		line.append(convertToFixedLength(dataEvenement.getIdContrat(), 50));
		line.append(CHAR_PLUS + convertToFixedLength(dataEvenement.getMontant(), 17));
		line.append(convertToFixedLength(dataEvenement.getOrigineContagion(), 10));
		line.append(convertToFixedLength("", 86));

		return line.toString();
	}

	private static String formatDateSqlToYYYYDDMM(Date date) {
		if (date == null) {
			return "        ";
		}
		return formatDateToYYYYDDMM(date.toLocalDate());
	}

	private static String convertToBoolean(BigDecimal top) {
		if (top == null) {
			return " ";
		}
		return (top.compareTo(BigDecimal.ZERO) > 0) ? "O" : "N";
	}

	public static BigDecimal getNotNullBigDecimal(BigDecimal bg) {
		return bg != null ? bg : BigDecimal.ZERO;
	}

	public static String convertToFixedLength(String str, int taille) {
		if (str == null) {
			return StringUtils.rightPad("", taille, CHAR_ESPACE);
		}
		return StringUtils.rightPad(str, taille, CHAR_ESPACE);
	}

	private static String convertCommentaire(String comm, int taille) {
		if (comm == null) {
			return StringUtils.rightPad("", taille, CHAR_ESPACE);
		}
		// supprimer les caractères incompatible UTF-8, indispensable pour que les
		// fichiers générés soient lisibles
		comm = comm.replaceAll("[^a-zA-Z0-9éèàçâô&%:=(){}\\[\\],;+\\?\\+\\-!_./\\s+]", " ");

		return StringUtils.rightPad(comm, taille, CHAR_ESPACE);
	}

	public static String convertToFixedLength(BigDecimal value, int taille) {
		String objectStr = "0";
		if (value == null) {
			return StringUtils.leftPad(objectStr, taille, CHAR_ZERO);
		}
		// gestion des chiffres apres virgules
		BigDecimal bg = value.setScale(2, RoundingMode.HALF_UP);
		long valeurEntiere = bg.multiply(new BigDecimal(100)).longValue();
		return StringUtils.leftPad(String.valueOf(valeurEntiere), taille, CHAR_ZERO);
	}

	public static String formatDateToYYYYDDMM(LocalDate localDate) {
		if (localDate == null) {
			return "        ";
		}
		return localDate.format(DateTimeFormatter.BASIC_ISO_DATE);
	}

	public static double round(Double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = BigDecimal.valueOf(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

	public static String generateFileName(String patternFichier, String typeFic, String codeBanque,
			String environnement) {

		if ("PRD".equalsIgnoreCase(environnement) || "PROD".equalsIgnoreCase(environnement)) {
			environnement = "PROD";
		} else {
			environnement = "RCT";
		}

		return MessageFormat.format(patternFichier, typeFic, codeBanque, environnement,
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMdd-HHmmss")));
	}

	public static String trouveOrigineStatutEffectif(String origSTQ, String statutEffectif, String codeBqSDA,
			String codeBq, String idLocal, JdbcTemplate jdbcTemplate) {
		String ret = origSTQ;
		if (Constant.ORIGINE_STC.equals(origSTQ) && Constant.STATUT_ND.equals(statutEffectif)
				&& Constant.MOTIF_SDA_OUI.equals(codeBqSDA)) {
			List<String> res = jdbcTemplate.queryForList(QUERY_TIERS_SDA, String.class, codeBq, idLocal, codeBq,
					idLocal);
			if (!res.isEmpty()) {
				ret = Constant.MOTIF_SDA;
			}
		}
		return ret;
	}
}
