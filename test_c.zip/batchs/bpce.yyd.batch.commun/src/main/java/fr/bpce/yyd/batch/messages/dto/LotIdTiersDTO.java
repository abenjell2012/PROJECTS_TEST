package fr.bpce.yyd.batch.messages.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import fr.bpce.yyd.batch.commun.mapper.LocalDateDeserializer;
import fr.bpce.yyd.batch.commun.mapper.LocalDateSerializer;

/**
 * Objet de transport destiné à passer un lot d'identifiants Tiers à traiter.
 *
 * @author zgud
 *
 */
public class LotIdTiersDTO implements Serializable {

	private static final long serialVersionUID = -1755189334435951191L;

	private List<Long> idsTiers = new ArrayList<>();

	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate dateCalcul;
	private Long guid;

	public List<Long> getIdsTiers() {
		return idsTiers;
	}

	public boolean addIdTiers(Long id) {
		return idsTiers.add(id);
	}

	public LocalDate getDateCalcul() {
		return dateCalcul;
	}

	public void setDateCalcul(LocalDate dateCalcul) {
		this.dateCalcul = dateCalcul;
	}

	public Long getGuid() {
		return guid;
	}

	public void setGuid(Long guid) {
		this.guid = guid;
	}

}
