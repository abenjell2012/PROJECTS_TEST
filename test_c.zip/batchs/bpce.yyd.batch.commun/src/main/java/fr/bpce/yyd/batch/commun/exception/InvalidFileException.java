package fr.bpce.yyd.batch.commun.exception;

/**
 * Erreur IO dans le d�placement d'un fichier, autre que FileNotFound.
 *
 * @author fzgud
 *
 */
public class InvalidFileException extends TechnicalException {

  private static final long serialVersionUID = -529775785757726971L;

  public InvalidFileException(String message) {
    super(message);
  }
}
