package fr.bpce.yyd.batch.commun.utils;

import static fr.bpce.yyd.batch.commun.constantes.Constant.FLAG_NON;
import static fr.bpce.yyd.batch.commun.constantes.Constant.FLAG_OUI;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.zip.GZIPOutputStream;

import org.apache.log4j.Logger;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;

public class FileCommunUtils {

	private static final Logger LOGGER = Logger.getLogger(FileCommunUtils.class);

	private FileCommunUtils() {
	}

	/**
	 * @param path
	 * @return void : création du repertoire s'il n'existe pas déja
	 */
	public static void checkRepertoire(String path) {
		if (!Paths.get(path).toFile().exists()) {
			new File(path).mkdirs();
		}
	}

	/**
	 * le flag est valide s'il est égal à 'O' ou 'N'
	 *
	 * @param flag
	 * @return
	 */
	public static boolean isFlagValide(String flag) {
		return FLAG_OUI.equals(flag) || FLAG_NON.equals(flag);
	}

	public static String getExtension(String fichier) {
		String extension = "";
		int lastIndex = fichier.lastIndexOf('.');
		if (lastIndex >= 0) {
			extension = fichier.substring(lastIndex + 1);
		}
		return extension;
	}

	public static String removeFileExtension(String simpleFileName) {
		int indexPoint = simpleFileName.lastIndexOf('.');
		if (indexPoint > 0) {
			return simpleFileName.substring(0, indexPoint);
		}
		return simpleFileName;
	}

	/**
	 * déplace le fichier dans le répertoire destDirPath, en gardant le même nom
	 *
	 * @param filePath
	 * @param destDirPath
	 * @return
	 * @throws IOException
	 */
	public static Path moveFileToDir(Path filePath, Path destDirPath) throws IOException {
		return Files.move(filePath, destDirPath.resolve(filePath.getFileName()), StandardCopyOption.REPLACE_EXISTING);
	}

	public static BatchStatus batchStatus(JobExecution execution) {
		return execution == null ? BatchStatus.UNKNOWN : execution.getStatus();
	}

	public static void exitWithErrorCode(final int errorCode) {
		Runtime.getRuntime().addShutdownHook(new Thread(() -> Runtime.getRuntime().halt(errorCode)));
		System.exit(errorCode);
	}

	public static Path compressAndDeleteFile (Path fileToCompress) throws IOException {

		if (fileToCompress.toFile().exists()) {
			compressToGZIP(fileToCompress.toFile().toString(), fileToCompress.toFile().toString() + ".gz");
			Files.delete(fileToCompress);
			return Paths.get(fileToCompress.toFile().toString() + ".gz");
		}
		throw new IOException(INVALID_FILE_PATH + fileToCompress.toFile().toString());
	}

	public static void compressToGZIP(String input, String output) throws IOException {

		try (GZIPOutputStream out = new GZIPOutputStream(new FileOutputStream(new File(output)))) {
			try (FileInputStream in = new FileInputStream(new File(input))) {
				byte[] buffer = new byte[1024];
				int len;
				while ((len = in.read(buffer)) != -1) {
					out.write(buffer, 0, len);
				}
			}
		}
	}

	public static void finaliserTraitement(BatchStatus statut) {
		if (statut == BatchStatus.COMPLETED) {
			LOGGER.info("Fin traitement de batch : OK");
			exitWithErrorCode(0);
		} else {
			LOGGER.info("Fin traitement de batch : KO");
			exitWithErrorCode(1);
		}
	}

	public static Path moveFileReplaceExist(Path filePath, Path destDirPath) throws IOException {
		return Files.move(filePath, destDirPath, StandardCopyOption.REPLACE_EXISTING);
	}

	private static final String INVALID_FILE_PATH = "invalid file path ";

	public static String sanitizePathImport(String filename) throws IOException {
		if (filename.startsWith("/appli")) {
			Path p = Paths.get(filename);
			return p.normalize().toString();
		}
		throw new IOException(INVALID_FILE_PATH + filename);
	}

	public static String sanitizePathRft(String filename) throws IOException {
		if (filename.startsWith("/data") || filename.startsWith("/appli")) {
			Path p = Paths.get(filename);
			return p.normalize().toString();
		}
		throw new IOException(INVALID_FILE_PATH + filename);
	}
}
