package fr.bpce.yyd.batch.commun.utils;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import fr.bpce.yyd.batch.commun.beans.ASignificatif;
import fr.bpce.yyd.commun.constantes.Constant;

public final class CalculSyntheseTiersUtils {

	private CalculSyntheseTiersUtils() {
	}

	public static final String QUERY_SELECT_AS = "select ev.* from evenement_calcule ev "
			+ "where ev.code ='AS' and ev.tiers_id = ? and (ev.DATE_DEBUT != ev.DATE_FIN or ev.DATE_FIN is null) and ((ev.DATE_DEBUT >= ? and ev.DATE_DEBUT <= ?) "
			+ "or (ev.DATE_FIN > ? and ev.DATE_FIN < ?)) order by ev.DATE_DEBUT asc";

	private static final String QUERY_SELECT_PARAM_MDC_SEG = "select par.valeur_param from PAR_MDC_SEG par "
			+ "where par.code_param = 'DELAI_RAZ_PP' and par.code_segment = ? and par.DATE_DEBUT <= ?  "
			+ "and (par.DATE_FIN is null or par.DATE_FIN > ?)";

	private static final String QUERY_SELECT_TIERS_ID_BY_IDLOCAL_CODE_BANQUE = "select i.tiers_id from identite_tiers i where i.code_bq = ? and i.id_local = ? and i.date_fin is null ";

	private static final String QUERY_SELECT_LAST_MNT_ENG_BRUT_BIL = "select MNT_ENG_BRUT_BIL from encours_tiers "
			+ "inner join (" + "SELECT tiers_id, max(id) as max_id, MAX(date_photo) AS max_date_photo "
			+ "FROM encours_tiers where date_photo <= ?" + "GROUP BY tiers_id "
			+ ") encours_tiers_max on encours_tiers_max.tiers_id = encours_tiers.tiers_id "
			+ "and encours_tiers_max.max_date_photo = encours_tiers.date_photo "
			+ "and encours_tiers_max.max_id = encours_tiers.id where encours_tiers.tiers_id = ? ";

	private static final String QUERY_SELECT_LAST_MNT_TOTAL_IMX_OU_DAX = "select sum(nvl(c.montant_arriere,0)) as MONTANT_TOTAL "
			+ "from identite_tiers i inner join identite_tiers i2 on i.id_local = i2.id_local and i.code_bq = i2.code_bq "
			+ "inner join evenement e on e.identite_initiale_id = i2.id and e.code = ? 	"
			+ "inner join COMPLEMENT_EVENEMENT c on  (c.evenement_id = e.id and c.statut_evenement = 'ACT' AND c.date_fin is null AND ARRIERE_LITIGE = 0 "
			+ "AND ARRIERE_TECH = 0 AND date_photo <= ? ) where i.date_fin is null and  i.tiers_id = ?";

	private static final String QUERY_SELECT_LAST_DATE_PHOTO_ENCOURS = "select max(e.date_photo) as DATE_PHOTO_ENCOURS "
			+ "	from encours_tiers e where date_Photo <=  ?  and tiers_id = ?";

	public static Long findTiersId(String codeBanque, String idlocal, JdbcTemplate jdbcTemplate) {

		List<Long> idtiers = jdbcTemplate.query(QUERY_SELECT_TIERS_ID_BY_IDLOCAL_CODE_BANQUE,
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {
						ps.setString(1, codeBanque);
						ps.setString(2, idlocal);
					}
				}, (rs, rowNum) -> rs.getLong("TIERS_ID")

		);

		if (!idtiers.isEmpty())
			return idtiers.get(0);

		return null;
	}

	public static Long calculCompteurPP(Long tiersId, LocalDate datePP, LocalDate dateCalcul, String codeSegment,
			JdbcTemplate jdbcTemplate) {

		if (tiersId == null)
			return null;

		List<ASignificatif> listAS = rechercheArriereSignificatifEntreDeuxDate(tiersId, datePP, dateCalcul,
				jdbcTemplate);

		long delaiRemiseAZeroCompteurPP = nbJoursASRazDecomptePP(codeSegment, dateCalcul, jdbcTemplate);

		long compteurPP = ChronoUnit.DAYS.between(datePP, dateCalcul) + 1;

		for (ASignificatif as : listAS) {
			LocalDate dateFin = as.getDateFin();
			LocalDate dateDeb = as.getDateDebut();
			if (dateFin == null || dateFin.isAfter(dateCalcul)) {
				dateFin = dateCalcul;
			}

			if (dateDeb.isBefore(datePP)) {
				dateDeb = datePP;
			}

			long duree = ChronoUnit.DAYS.between(dateDeb, dateFin) + 1;

			if (duree <= delaiRemiseAZeroCompteurPP) {
				compteurPP -= duree;
			} else {
				compteurPP = ChronoUnit.DAYS.between(dateFin, dateCalcul) + 1;
			}
		}
		return compteurPP;
	}

	private static long nbJoursASRazDecomptePP(String codeSegment, LocalDate dateCalcul, JdbcTemplate jdbcTemplate) {

		// find by date and segment sinon find by date and *
		Long nbJourRAZ = findASRazDeComptePP(codeSegment, dateCalcul, jdbcTemplate);
		if (nbJourRAZ == null) {
			nbJourRAZ = findASRazDeComptePP(Constant.ANY, dateCalcul, jdbcTemplate);
		}
		return nbJourRAZ != null ? nbJourRAZ : 30;
	}

	private static Long findASRazDeComptePP(String codeSegment, LocalDate dateCalcul, JdbcTemplate jdbcTemplate) {

		List<Long> list = jdbcTemplate.query(QUERY_SELECT_PARAM_MDC_SEG, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, codeSegment);
				ps.setDate(2, Date.valueOf(dateCalcul));
				ps.setDate(3, Date.valueOf(dateCalcul));

			}
		}, (rs, rowNum) -> rs.getLong("VALEUR_PARAM")

		);
		return list.isEmpty() ? null : list.get(0);

	}

	private static List<ASignificatif> rechercheArriereSignificatifEntreDeuxDate(Long tiersId, LocalDate datePP,
			LocalDate dateCalcul, JdbcTemplate jdbcTemplate) {

		return jdbcTemplate.query(QUERY_SELECT_AS, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setLong(1, tiersId);
				ps.setDate(2, Date.valueOf(datePP));
				ps.setDate(3, Date.valueOf(dateCalcul));
				ps.setDate(4, Date.valueOf(datePP));
				ps.setDate(5, Date.valueOf(dateCalcul));
			}
		}, (rs, rowNum) -> new ASignificatif(rs.getDate("DATE_DEBUT"), rs.getDate("DATE_FIN"), rs.getLong("TIERS_ID"))

		);
	}

	public static BigDecimal rechercheEncoursTiersADate(Long idTiers, LocalDate dateCalcul, JdbcTemplate jdbcTemplate) {

		List<Object> list = jdbcTemplate.query(QUERY_SELECT_LAST_MNT_ENG_BRUT_BIL, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setDate(1, Date.valueOf(dateCalcul));
				ps.setLong(2, idTiers);

			}
		}, (rs, rowNum) -> rs.getBigDecimal("MNT_ENG_BRUT_BIL")

		);
		if (list.isEmpty())
			return null;
		else
			return (BigDecimal) list.get(0);
	};

	public static BigDecimal rechercheMontantTotalArriereiersADate(String code, Long idTiers, LocalDate dateCalcul,
			JdbcTemplate jdbcTemplate) {

		List<Object> list = jdbcTemplate.query(QUERY_SELECT_LAST_MNT_TOTAL_IMX_OU_DAX, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, code);
				ps.setDate(2, Date.valueOf(dateCalcul));
				ps.setLong(3, idTiers);

			}
		}, (rs, rowNum) -> rs.getBigDecimal("MONTANT_TOTAL")

		);
		if (list.isEmpty())
			return null;
		else
			return (BigDecimal) list.get(0);

	};

	public static Date rechercheDatePhotoEncours(Long idTiers, LocalDate dateCalcul, JdbcTemplate jdbcTemplate) {

		List<Object> list = jdbcTemplate.query(QUERY_SELECT_LAST_DATE_PHOTO_ENCOURS, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setDate(1, Date.valueOf(dateCalcul));
				ps.setLong(2, idTiers);

			}
		}, (rs, rowNum) -> rs.getDate("DATE_PHOTO_ENCOURS")

		);
		if (list.isEmpty())
			return null;
		else
			return (Date) list.get(0);

	};

	public static Date calculDatePrevisionnelleFinPP(LocalDate datePhoto, Boolean topF, Long compteurPP) {
		// si topF = false alors : datePP + 90 - compteurPP
		// sinon datePP + 365 - compteurPP
		if (Boolean.TRUE.equals(topF)) {
			return Date.valueOf(datePhoto.plusDays(365 - compteurPP));
		} else {
			return Date.valueOf(datePhoto.plusDays(90 - compteurPP));
		}
	}

	public static Long calculCompteurAS(LocalDate dateAS, LocalDate dateCalcul) {
		// dateCalcul - dateAS
		return ChronoUnit.DAYS.between(dateAS, dateCalcul) + 1;
	}

	public static Long calculCompteurA(LocalDate dateA, LocalDate dateCalcul) {
		// dateCalcul - dateA
		return ChronoUnit.DAYS.between(dateA, dateCalcul) + 1;
	}

	public static Boolean calculWarningAR0(String oldPalierAs, String palierAs) {
		// palierAS = AR0 et palierAS != old palier AS
		return Objects.equals("AR0", palierAs) && !Objects.equals(oldPalierAs, palierAs);
	}

	public static Boolean calculWarningAR1(String oldPalierAs, String palierAs) {
		// palierAS = AR1 et palierAS != old palier AS
		return Objects.equals("AR1", palierAs) && !Objects.equals(oldPalierAs, palierAs);
	}

	public static Boolean calculWarningAR2(String oldPalierAs, String palierAs) {
		// palierAS = AR2 et palierAS != old palier AS
		return Objects.equals("AR2", palierAs) && !Objects.equals(oldPalierAs, palierAs);
	}

	public static Boolean calculWarningAR3(String oldPalierAs, String palierAs) {
		// palierAS = AR3 et palierAS != old palier AS
		return Objects.equals("AR3", palierAs) && !Objects.equals(oldPalierAs, palierAs);
	}

	public static Boolean calculWarningForbearance(boolean oldTopF, boolean topF) {
		// si topF = vrai ET old topF = false
		return topF && !oldTopF;
	}

	public static Boolean calculWarningDefaut(String oldStatutEffectif, String statutEffectif) {
		// si statutEffectif = 'D' ET oldStatutEffectif != statutEffectif
		return "D".equals(statutEffectif) && !Objects.equals("D", oldStatutEffectif);
	}

	public static Boolean calculWarningRX(String oldPalierEffectif, String palierEffectif) {
		// si palierEffectif = 'RX' ET oldPalierEffectif != RX
		return "RX".equals(palierEffectif) && !Objects.equals("RX", oldPalierEffectif);
	}

	public static Boolean calculWarningDX(String oldPalierEffectif, String palierEffectif) {
		// si palierEffectif = 'DX' ET oldPalierEffectif != DX
		return "DX".equals(palierEffectif) && !Objects.equals("DX", oldPalierEffectif);
	}

	public static Boolean calculWarningCX(String oldPalierEffectif, String palierEffectif) {
		// si palierEffectif = 'CX' ET oldPalierEffectif != CX
		return "CX".equals(palierEffectif) && !Objects.equals("CX", oldPalierEffectif);
	}

	public static Boolean calculWarningPP(boolean oldtopPP, boolean topPP) {
		// si topPP = 1 ET old topPP = 0
		return topPP && !Objects.equals(true, oldtopPP);
	}

	public static Boolean calculWarningPPWithAS(boolean topPP, boolean topAs, boolean oldTopAs, boolean oldPhoto) {
		// si topPP = 1 ET topAs = 1 ET oldphoto = 1 et old top as = 0
		return oldPhoto && topPP && topAs && !oldTopAs;
	}

	public static Boolean calculWarningSain(String oldStatutEffectif, String statutEffectif) {
		// si statutEffectif = 'ND' ET oldStatutEffectif = 'D'
		return "ND".equals(statutEffectif) && Objects.equals("D", oldStatutEffectif);
	}

	public static Boolean calculWarningPPWithF(String statutEffectif, boolean warning2, boolean topF,
			boolean warning8) {
		// si statutEffectif = 'ND' ET warning2 = 1 ou warning8 = 1 et topF = 1
		return ("ND".equals(statutEffectif) && warning2) || (warning8 && topF);
	}

	public static Long checkCompteur(Long compteur) {
		if (compteur > 9999l) {
			return 9999l;
		}
		return compteur;
	}
}
