package fr.bpce.yyd.batch.commun.beans;

import lombok.Data;

@Data
public class DataTiersOrphelin {

	private String idLocal;
	private String codeBanque;

}
