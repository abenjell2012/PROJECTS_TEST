package fr.bpce.yyd.batch.messages.kafka;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.mapper.MapperFactory;
import fr.bpce.yyd.batch.commun.messages.ConsommateurMessages;
import fr.bpce.yyd.batch.commun.messages.Topic;

/**
 * Encapsulation d'un consummer Kafka.
 *
 * @author zgud
 */
public class ConsommateurMessagesKafka implements ConsommateurMessages {

	private final Logger log = LoggerFactory.getLogger(ConsommateurMessagesKafka.class);

	private final Map<Topic, KafkaConsumer<String, String>> consumers = new EnumMap<>(Topic.class);
	private final ObjectMapper mapper = MapperFactory.getMapper();

	/**
	 * Démarre le service qui va lire en boucle les messages sur le topic et les
	 * faire traiter par le consommateur.
	 *
	 * @param consommateur objet implémentant le traitement des messages reçus et
	 *                     désérialisés en objets de type C.
	 */
	@Override
	public <C> void demarre(final Topic topic, String name, final Class<C> classeMessage,
			final Consommateur<C> consommateur) {

		Thread consumerThread = new Thread(() -> demarreConsumer(topic, name, classeMessage, consommateur));
		consumerThread.start();
	}

	private <C> void demarreConsumer(final Topic topic, String name, final Class<C> classeMessage,
			final Consommateur<C> consommateur) {
		while (true) {
			ConsumerRecords<String, String> records = getConsumer(topic, name).poll(Duration.ofMillis(100));
			for (ConsumerRecord<String, String> record : records) {
				try {
					C objetDuMessage = mapper.readValue(record.value(), classeMessage);
					consommateur.consomme(objetDuMessage);
				} catch (JsonParseException | JsonMappingException ex) {
					log.warn("Erreur d'analyse en lecture d'un " + classeMessage.getSimpleName(), ex);
				} catch (IOException ioex) {
					log.warn("IO erreur en lecture d'un " + classeMessage.getSimpleName(), ioex);
				} catch (Exception e) {
					log.warn("Erreur en traitement d'un " + classeMessage.getSimpleName(), e);
				}
			}
		}
	}

	private KafkaConsumer<String, String> getConsumer(Topic topic, String name) {
		return consumers.computeIfAbsent(topic, t -> {
			TopicKafka topicK = TopicKafka.fromTopic(t);
			String kafkaEnv;
			try {
				kafkaEnv = ConfigManager.getProperty("kafka.env");
			} catch (UnknownPropertyException | InvalidInitialisationException e) {
				throw new IllegalStateException("variable kafka.env obligatoire", e);
			}
			Properties props = new Properties();
			props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
			props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
			props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
			props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
					"org.apache.kafka.common.serialization.StringDeserializer");
			props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
					"org.apache.kafka.common.serialization.StringDeserializer");
			props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "1");
			KafkaConsumer<String, String> konsumer = new KafkaConsumer<>(props);
			konsumer.subscribe(Arrays.asList(topicK.getTopicName(kafkaEnv, name)));
			return konsumer;
		});
	}

	public ObjectMapper getMapper() {
		return mapper;
	}
}
