package fr.bpce.yyd.batch.commun.messages;

public enum Topic {
	CALCUL_LISTE, COMPTEURS_LISTE,CLOTURE_LISTE, NOTIF_RMN
}
