package fr.bpce.yyd.batch.commun.exception;

/**
 * Superclasse des exceptions g�r�es et/ou g�n�r�es dans les batchs.
 *
 * @author fzgud
 *
 */
public abstract class BatchException extends Exception {

  private static final long serialVersionUID = -7164953382556713L;

  public BatchException(String message) {
    super(message);
  }

  public BatchException(String message, Throwable throwable) {
    super(message, throwable);
  }
}
