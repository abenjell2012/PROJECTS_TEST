package fr.bpce.yyd.batch.commun.beans;

import java.math.BigDecimal;
import java.sql.Date;

import lombok.Data;

@Data
public class DataEvenement {

	private String idRft;

	private String codeBanque;

	private String idLocal;

	private String idEvent;

	private String code;

	private String sousCode;

	private String commentaire;

	private String codeBanqueE;

	private String statut;

	private Date dateDebut;

	private Date dateCloture;

	private Date datePhoto;

	private BigDecimal topTech;

	private BigDecimal topLitige;

	private String idContrat;

	private BigDecimal montant;

	private String categorieSegment;

	private String origineContagion;

}
