package fr.bpce.yyd.batch.commun.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fr.bpce.yyd.batch.commun.beans.DataEvenement;
import fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils;

public class DataEvenementRowMapper implements RowMapper<fr.bpce.yyd.batch.commun.beans.DataEvenement> {

	@Override
	public DataEvenement mapRow(ResultSet rs, int rowNum) throws SQLException {

		DataEvenement dataEvt = new DataEvenement();
		dataEvt.setIdRft(rs.getString(1));
		dataEvt.setCodeBanque(rs.getString(2));
		dataEvt.setIdLocal(rs.getString(3));
		dataEvt.setCodeBanqueE(rs.getString(4));
		dataEvt.setIdEvent(rs.getString(5));
		dataEvt.setCode(rs.getString(6));
		dataEvt.setSousCode(rs.getString(7));
		dataEvt.setDateDebut(rs.getDate(8));
		dataEvt.setDatePhoto(rs.getDate(9));
		dataEvt.setDateCloture(rs.getDate(10));
		dataEvt.setStatut(rs.getString(11));
		dataEvt.setCommentaire(rs.getString(12));
		dataEvt.setTopTech(rs.getBigDecimal(13));
		dataEvt.setTopLitige(rs.getBigDecimal(14));
		dataEvt.setMontant(RestitSyntheseUtils.getNotNullBigDecimal(rs.getBigDecimal(15)));
		dataEvt.setIdContrat(rs.getString(16));
		dataEvt.setCategorieSegment(rs.getString(17));
		dataEvt.setOrigineContagion(rs.getString(19));

		return dataEvt;
	}

}
