package fr.bpce.yyd.batch.commun.beans;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class DataEventLocal {

	private Long idSynthese;

	private String codeBq;

	private String idLocal;

	private String code;

	private String type;

	private Date dateDebut;

	private Date datePhoto;

	private Date dateCloture;

	private String statutEvenement;

	private Date dateMaj;

	private String commentaire;

	private Boolean arriereTech;

	private Boolean arriereLitige;

	private BigDecimal montantArriere;

	private String idContrat;

	private Timestamp dateGenerationEvt;

	// pour mensuel
	private Date dar;

}
