package fr.bpce.yyd.batch.commun.messages;

public interface ProducteurMessages {

	/**
	 * Envoi de l'objet message, sous sa forme JSON, sur le topic donné.
	 *
	 * @param topic
	 * @param name
	 * @param message
	 */
	public <C> void envoieMessage(Topic topic, String name, C message);

	/**
	 * Envoi d'un message déjà sous forme JSON sur le topic donné.
	 *
	 * @param topic
	 * @paramn name
	 * @param message
	 */
	public void envoieMessageJSON(Topic topic, String name, String message);

	/**
	 * Blocage du producteur le temps que les messages actuellements en cours
	 * d'envoi aient été effectivement envoyés.
	 *
	 * @param topic
	 */
	public void arretProducteur(Topic topic);

}
