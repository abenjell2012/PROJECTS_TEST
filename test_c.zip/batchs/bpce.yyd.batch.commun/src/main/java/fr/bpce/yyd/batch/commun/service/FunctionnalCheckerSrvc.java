package fr.bpce.yyd.batch.commun.service;

public interface FunctionnalCheckerSrvc {

	boolean isCodeBanqueValide(String codBq);

}
