package fr.bpce.yyd.batch.commun.repositories;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fr.bpce.yyd.commun.enums.CodeParamMdc;

@Repository
public class ParMdcRepository {

	private EntityManager entityManager;

	@Autowired
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Retourne la liste de code banque de recherche RFT
	 *
	 * @param codeBanqueTiers
	 * @return
	 */
	public LocalDate findDateCalculCourante() {
		Query query = entityManager
				.createNativeQuery("select valeur_param from par_mdc_seg where code_param = :codeParam");
		query.setParameter("codeParam", CodeParamMdc.DATE_CALCUL_COURANTE.name());
		@SuppressWarnings("unchecked")
		List<String> results = query.getResultList();
		if (!results.isEmpty()) {
			String dateCalculCouranteStr = results.get(0);
			return LocalDate.parse(dateCalculCouranteStr, DateTimeFormatter.BASIC_ISO_DATE);
		}
		return null;
	}
}