package fr.bpce.yyd.batch.commun.exception;

public class InvalidInitialisationException extends BatchException {

  private static final long serialVersionUID = 8711506027244701760L;

  public InvalidInitialisationException(String msg) {
    super(msg);
  }

  public InvalidInitialisationException(String msg, Throwable t) {
    super(msg, t);
  }
}
