package fr.bpce.yyd.batch.commun.utils;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;

public class SpringBatchUtil {

	private SpringBatchUtil() {

	}

	public static StepExecution getStepExecution(ChunkContext chunkContext) {
		return chunkContext.getStepContext().getStepExecution();

	}

	public static void setStepExitMessage(ChunkContext chunkContext, String exitMessage) {
		StepExecution stepExecution = getStepExecution(chunkContext);
		stepExecution.setExitStatus(new ExitStatus(stepExecution.getExitStatus().getExitCode(), exitMessage));

	}

	public static Long getJobExecutionId(ChunkContext chunkContext) {
		return chunkContext.getStepContext().getStepExecution().getJobExecutionId();

	}

	public static void putObjectInJobExecutionContext(ChunkContext chunkContext, String cle, Object valeur) {
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(cle, valeur);
	}

	public static Object getObjectFromJobExecutionContext(ChunkContext chunkContext, String cle) {
		return chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get(cle);
	}

}
