package fr.bpce.yyd.batch.messages.kafka;

import java.text.MessageFormat;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.messages.Topic;

/**
 * Topic façon Kafka.
 *
 * Doit présenter les mêmes élements que l'enum Topic du projet commun.
 *
 * @author zgud
 *
 */
public enum TopicKafka {

	CALCUL_LISTE(Constant.PATTERN_TOPIC), CLOTURE_LISTE(Constant.PATTERN_TOPIC),
	COMPTEURS_LISTE(Constant.PATTERN_TOPIC), NOTIF_RMN(Constant.PATTERN_TOPIC);

	private final String topicName;

	private TopicKafka(String topicName) {
		this.topicName = topicName;
	}

	public String getTopicName(String env, String name) {
		return MessageFormat.format(topicName, env, name);
	}

	public static TopicKafka fromTopic(Topic topic) {
		return valueOf(topic.name());
	}
}
