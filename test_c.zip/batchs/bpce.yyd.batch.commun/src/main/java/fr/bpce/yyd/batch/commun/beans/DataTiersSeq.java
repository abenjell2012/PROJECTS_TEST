package fr.bpce.yyd.batch.commun.beans;

import lombok.Data;

@Data
public class DataTiersSeq {

	private String idLocal;
	private String codeBanque;
	private String idFederal;
	private long tiersId;
	private String commentaire;

	public DataTiersSeq(String idLocal, String codeBanque, String idFederal, long tiersId) {
		this.idLocal = idLocal;
		this.codeBanque = codeBanque;
		this.idFederal = idFederal;
		this.tiersId = tiersId;
	}

	public DataTiersSeq() {
		super();
	}

}
