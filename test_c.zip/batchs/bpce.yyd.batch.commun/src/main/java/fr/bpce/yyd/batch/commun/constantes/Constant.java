package fr.bpce.yyd.batch.commun.constantes;

import java.time.format.DateTimeFormatter;

public class Constant {

	private Constant() {
		// classe de constantes non instanciable
	}

	public static final String PATTERN_TOPIC = "BF_{0}_{1}";

	// Separator
	public static final String FILE_SEPARATOR_VIRGULE = ",";
	public static final String FILE_SEPARATOR = "|";
	public static final String SEP_POINT_VIRGULE = ";";
	public static final String SEP_DIESE = "#";
	public static final char CHAR_POINT_VIRGULE = ';';
	public static final char CHAR_ESPACE = ' ';
	public static final char CHAR_ZERO = '0';
	public static final char CHAR_PLUS = '+';
	public static final char CHAR_MOINS = '-';

	public static final String FORMAT_DATE = "yyyyMMdd";
	public static final String FORMAT_DATE_DDMMYYYY = "ddMMyyyy";

	public static final String TYPE_LIGNE_ENTETE = "*1";
	public static final String TYPE_LIGNE_ENQUEUE = "*9";
	public static final String SEPERATEUR_LIGNES = "\n";
	public static final String SEPERATEUR_FICHIER = "/";
	public static final Long NB_JOURS_INIT = 91L;

	// Expression réguliere pour la nomenclaure du fichier
	public static final String REG_NDOD_EVT_FILE = "^(NDOD_EVT_DELTA)_(\\d{5})_([a-zA-Z0-9]+)_(\\d{6}-\\d{6})((?i)(\\.txt))$";
	public static final String REG_NDOD_EVT_INIT_FILE = "^(NDOD_EVT_INIT1)_(\\d{5})_([a-zA-Z0-9]+)_(\\d{6}-\\d{6})((?i)(\\.txt))$";
	public static final String REG_NDOD_EVT_MENSUEL_FILE = "^(NDOD_EVT_FULL)_(\\d{5})_([a-zA-Z0-9]+)_(\\d{6}-\\d{6})((?i)(\\.txt))$";
	public static final String REG_NDOD_EVT_CONTAGION_FILE = "^(NDOD_EVT_CON)_(99999)_([a-zA-Z0-9]+)_(\\d{6}-\\d{6})((?i)(\\.txt))$";

	// JOB SPRING BATCH EVENEMENTS
	public static final String JOB_IMPORT_EVT = "IMPORT_EVT";

	// JOB SPRING BATCH SITUATION
	public static final String JOB_SITUATION_TIERS = "situation_tiers";

	// JOB SPRING BATCH DECLENCHEUR
	public static final String JOB_DECLENCHEUR = "declencheur";

	// JOB SPRING BATCH SYNTHESE_INCIDENT
	public static final String JOB_SYNTHESE_INCIDENT = "SYNTHESE_INCIDENT";

	// JOB SPRING BATCH STOCK SITUATION
	public static final String JOB_STOCK_SITUATION_TIERS = "stock_situation_tiers";

	// JOB SPRING BATCH RESTITUTION_SITUATION_DEFAUT_RMN
	public static final String JOB_RESTITUTION_SITUATION_DEFAUT_RMN = "SYNTHESE_DEFAUT_RMN";

	// JOB SPRING BATCH FLUX INCIDENT DEFAUT RMN
	public static final String JOB_FLUX_INCIDENT_DEFAUT  = "FLUX_INCIDENT_DEFAUT";

	// JOB SPRING BATCH SYNTHESE TIERS quotidienne
	public static final String JOB_SYNTHESE_TIERS_QUOTIDIENNE = "synthese_tiers_quotidiennee";

	// JOB SPRING BATCH SYNTHESE TIERS mensuelle
	public static final String JOB_SYNTHESE_TIERS_MENSUELLE = "synthese_tiers_mensuelle";

	// BATCH COMPTEUR
	public static final String JOB_COMPTEUR = "COMPTEUR";

	// BATCH SIMULATEUR NOTIF
	public static final String JOB_SIMULATEUR_NOTIF = "SIMULATEUR_NOTIF";

	// BATCH CALCUL AFTER NOTIF
	public static final String JOB_CALCUL = "calcul_after_notif";

	// BATCH TRAITEMENT EVENEMENT
	public static final String JOB_TRAITEMENT_EVTS = "BATCH_TRAITEMENT_EVENEMENTS";

	// JOB SPRING BATCH IMPORT RFT
	public static final String JOB_IMPORT_RFT = "IMPORT_RFT";
	public static final String REG_NDOD_RFT_FILE_Q = "^NDOD_P_REF_TIERS_(\\d{8})\\.dat$";
	public static final String REG_NDOD_RFT_FILE_M = "^NDOD_P_REF_TIERS_(\\d{8})_(M)\\.dat$";

	// JOB SPRING BATCH FORCAGE SBV
	public static final String JOB_FORCAGE_SBV = "FORCAGE_SBV";
	public static final String ENTETE_FIC_SBV = "Identifiant local;Code Banque;Id RFT;Siren;Date de début;Date de fin;Statut Forcé;Palier de défaut;Codification Motif;Commentaire";
	public static final String ENTETE_FIC_REJET_SBV = "Identifiant local;Code Banque;Id RFT;Siren;Numéro de ligne rejetée;Motif de rejet";
	// fichier forcage statut sbv
	public static final String REG_NDOD_FORCAGE_SBV_FILE = "^SBV_FICHIER_FORCAGE_(\\d{8})\\.csv$";
	// fichier rejet statut sbv
	public static final String REJET_FORCAGE_SBV_FILE = "SBV_FICHIER_REJ_FORCAGE_{0}.csv";

	public static final String JOB_FLUX_QUOTIDIEN = "FLUX_QUOTIDIEN";
	public static final String JOB_FLUX_MENSUEL = "FLUX_MENSUEL";

	// JOB CALCUL STATS ORACLE
	public static final String JOB_CALCUL_STATS_ORACLE = "calcul_stats_oracle";

	// JOB CALCUL TIERS
	public static final String JOB_CALCUL_TIERS = "calcul_tiers";

	//
	public static final String CHAMP_EMPTY = "";
	public static final String CHAMP_ETOILE = "*";

	// NUMERO DE VERSION FICHIER IMPORT EVT
	public static final String NUM_VERS_IMPORT_EVT = "001";

	// CODE APPLI
	public static final String CODE_APPLI = "MDC";

	public static final String SRC_EVT_SIR = "SIR";
	public static final String SRC_EVT_RMN = "RMN";
	public static final String CODE_FAM_EVT_CON = "CON";

	public static final String FLAG_OUI = "O";
	public static final String FLAG_NON = "N";

	public static final String EXT_ZIP = "zip";
	public static final String EXT_GZ = "gz";

	public static final DateTimeFormatter DATE_TIME_FORMATTER_1 = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");
	public static final DateTimeFormatter DATE_TIME_FORMATTER_2 = DateTimeFormatter.ofPattern("ddMMyyyy_HHmmss");
	public static final DateTimeFormatter YYYYMMDD_FORMATTER = DateTimeFormatter.ofPattern(FORMAT_DATE);
	public static final DateTimeFormatter DDMMYYYY_FORMATTER = DateTimeFormatter.ofPattern(FORMAT_DATE_DDMMYYYY);

	public static final String JOB_EVENEMENT_QUOTIDIEN = "evenement_quotidien";

	public static final String JOB_EVENEMENT_MENSUEL = "evenement_mensuel";
}
