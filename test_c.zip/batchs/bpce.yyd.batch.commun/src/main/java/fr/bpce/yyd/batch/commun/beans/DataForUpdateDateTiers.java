package fr.bpce.yyd.batch.commun.beans;

import java.sql.Date;

import lombok.Getter;

@Getter
public class DataForUpdateDateTiers {

	private Date dateFin;
	private Long idTiers;

	public DataForUpdateDateTiers(Date dateFin, Long idTiers) {
		super();
		this.dateFin = dateFin;
		this.idTiers = idTiers;
	}

}
