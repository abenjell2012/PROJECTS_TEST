package fr.bpce.yyd.batch.commun.beans;

import lombok.Data;

@Data
public class DataEventOrphelin {
	private Long id;
	private String idRft;

	public DataEventOrphelin(Long id, String idRft) {
		super();
		this.id = id;
		this.idRft = idRft;
	}

}
