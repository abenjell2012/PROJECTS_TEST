package fr.bpce.yyd.batch.commun.messages;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import fr.bpce.yyd.batch.commun.mapper.MapperFactory;

/**
 * Implementation abstraite du producteur de messages, qui centralise la
 * sérialisation JSON (en utilisant Jackson).
 *
 * @author zgud
 *
 */
public abstract class AbstractProducteurMessages implements ProducteurMessages {

	private static final Logger log = LoggerFactory.getLogger(AbstractProducteurMessages.class);

	private ObjectMapper mapper = MapperFactory.getMapper();

	@Override
	public <C> void envoieMessage(Topic topic, String name, C objetAEnvoyer) {

		try {
			String message = mapper.writeValueAsString(objetAEnvoyer);
			envoieMessageJSON(topic, name, message);
		} catch (JsonProcessingException exp) {
			log.error("Message : {} \n {}", objetAEnvoyer, exp.getMessage());
		}
	}

}
