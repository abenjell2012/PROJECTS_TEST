package fr.bpce.yyd.batch.commun.utils;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;

import lombok.extern.log4j.Log4j;

@Log4j
public class CalculStatsUtils {

	private static final String STATS_SQL = "call PKG_TECH_GES_PARTITION.stats_table(?,?)";

	private CalculStatsUtils() {
		// Utility classe are not meant to be instantiated
	}

	public static void calculStatTable(JdbcTemplate jdbcTemplate, String table, int degre) {

		try {
			CallableStatement callableSt = null;
			try {
				Connection con = jdbcTemplate.getDataSource().getConnection();
				if (con == null) {
					log.error("Cannot check default schema - no Connection from DatabaseMetaData");
				} else {
					callableSt = con.prepareCall(STATS_SQL);
					callableSt.setString(1, table);
					callableSt.setInt(2, degre);
					callableSt.executeUpdate();
				}
			} finally {
				closeCallableStmt(callableSt);
			}
		} catch (SQLException ex) {
			log.error("CalculStatsUtils - Exception encountered during default schema lookup", ex);

		}

	}

	protected static void closeCallableStmt(CallableStatement stmt) {
		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
