package fr.bpce.yyd.batch.commun.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;

@Service
@Scope("singleton")
public class ReferenceSrvcImpl {

	private static final Logger LOGGER = Logger.getLogger(ReferenceSrvcImpl.class);

	@Autowired
	private EntityManager entityManager;

	private List<RefImpactEvtMdc> refImpactEvtMdcList = new ArrayList<>();

	@PostConstruct
	private void initializeRefImpactList() {
		LOGGER.info("récupération du référentiel REF_IMPACT_EVT_MDC");
		TypedQuery<RefImpactEvtMdc> query = entityManager
				.createQuery("select ref from RefImpactEvtMdc ref ", RefImpactEvtMdc.class);
		refImpactEvtMdcList = query.getResultList();
	}

	private List<RefImpactEvtMdc> getRefImpactEvtMdcList() {
		return refImpactEvtMdcList;
	}

	public String findImpactEvenement(String codEvt, String catSegment, LocalDate dateDemande) {
		List<RefImpactEvtMdc> refImpactList = getRefImpactEvtMdcList();
		// filter par rapport à la date de demande
		List<RefImpactEvtMdc> refImpactListADAte = refImpactList.stream()
				.filter(ref -> (ref.getDateDebut().compareTo(dateDemande) <= 0
						&& (ref.getDateFin() == null || ref.getDateFin().compareTo(dateDemande) > 0)))
				.collect(Collectors.toList());
		// filrer par rapport à codeEvt et catSegment
		RefImpactEvtMdc refImpactEvtMdc = refImpactListADAte.stream()
				.filter(ref -> ref.getCodEvt().equals(codEvt) && ref.getCategorieSegment().equals(catSegment))
				.findFirst().orElse(null);
		// filter par catSegment = TOUS_AUTRES si le résultat est nulle
		if (refImpactEvtMdc == null) {
			refImpactEvtMdc = refImpactListADAte.stream().filter(
					ref -> ref.getCodEvt().equals(codEvt) && ref.getCategorieSegment().equals(Constant.TOUS_AUTRES))
					.findFirst().orElse(null);
		}

		return refImpactEvtMdc == null ? null : refImpactEvtMdc.getImpact();
	}

	public boolean isEventUtpNow(String codEvt, String catSegment) {
		return "D".equals(findImpactEvenement(codEvt, catSegment, LocalDate.now()));
	}

}
