package fr.bpce.yyd.batch.commun.beans;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Data;

@Data
public class DetailTiersInfo {

	private String idSituation;
	private LocalDate datePhoto;
	private String idFederal;
	private String codeBanque;
	private String idLocal;
	private String codeSegment;
	private String statutEff;
	private String palierEff;
	private LocalDate dateMajStatutEff;
	private String origineStatutEff;
	private String commentaireForcage;
	private char topPP;
	private LocalDate datePrevFinPP;
	private char topF;
	private char topA;
	private char topAS;
	private String palierAS;
	private LocalDate dateMetierEvtEntreeDefautCalcule;
	private String codeEvtEntreeDefautCalcule;
	private String idEvtEntreeDefaut;
	private BigDecimal montantTotalImx;
	private BigDecimal montantTotalDax;
	private BigDecimal montantTotalArrieres;
	private BigDecimal montantEngaConsolide;
	private LocalDate darDonneeEngaConsolide;
	private char warning1p1;
	private char warning1p2;
	private char warning1p3;
	private char warning1p4;
	private char warning2;
	private char warning3;
	private char warning4;
	private char warning5p1;
	private char warning5p2;
	private char warning5p3;
	private char warning6;
	private char warning7;
	private char warning8;
	private char warning9;
	private char warning10;

}
