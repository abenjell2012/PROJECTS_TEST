package fr.bpce.yyd.batch.commun.exception;

public class UnknownPropertyException extends BatchException {

  private static final long serialVersionUID = 7991727116599428134L;

  public UnknownPropertyException(String msg) {
    super(msg);
  }
}
