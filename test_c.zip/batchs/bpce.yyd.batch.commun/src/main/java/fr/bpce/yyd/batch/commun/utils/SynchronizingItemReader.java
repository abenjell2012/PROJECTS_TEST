package fr.bpce.yyd.batch.commun.utils;


import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;

/**
 * Thread-safe reader that permits to synchronise the read.<br/>
 */
public class SynchronizingItemReader<T> implements ItemReader<T>, ItemStream {

	private ItemReader<T> delegate;

	@Override
	public synchronized T read() throws Exception {
		return delegate.read();
	}

	@Override
	public void close() {
		if (this.delegate instanceof ItemStream) {
			((ItemStream) this.delegate).close();
		}
	}

	@Override
	public void open(ExecutionContext context) {
		if (this.delegate instanceof ItemStream) {
			((ItemStream) this.delegate).open(context);
		}
	}

	@Override
	public void update(ExecutionContext context) {
		if (this.delegate instanceof ItemStream) {
			((ItemStream) this.delegate).update(context);
		}
	}

	public ItemReader<T> getDelegate() {
		return delegate;
	}

	public void setDelegate(ItemReader<T> delegate) {
		this.delegate = delegate;
	}
}