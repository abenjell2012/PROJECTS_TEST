package fr.bpce.yyd.batch.commun.listener;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

/**
 *
 *
 * @author benjelloun
 *
 */
public class ExitMessageJobListener implements JobExecutionListener {

	@Override
	public void afterJob(JobExecution jobExec) {
		if (jobExec.getExitStatus().getExitCode().equals(ExitStatus.FAILED.getExitCode())) {
			if (jobExec.getAllFailureExceptions() != null && !jobExec.getAllFailureExceptions().isEmpty()) {
				StringBuilder messageBuilder = new StringBuilder("");
				for (Throwable throwable : jobExec.getAllFailureExceptions()) {
					messageBuilder.append(
							ExceptionUtils.getRootCauseMessage(throwable) + " - " + throwable.getMessage() + "\n");
				}
				jobExec.setExitStatus(new ExitStatus(jobExec.getExitStatus().getExitCode(), messageBuilder.toString()));
			}
		} else if (jobExec.getExitStatus().getExitCode().equals(ExitStatus.STOPPED.getExitCode())) {
			jobExec.setExitStatus(new ExitStatus(jobExec.getExitStatus().getExitCode(), "Job arrêté"));
		}
	}

	@Override
	public void beforeJob(JobExecution arg0) {
		// do nothing
	}

}
