package fr.bpce.yyd.batch.commun.service;

import java.util.List;

public interface ReferenceImportSrvc {

	List<String> getCodBqReferenceList();
}
