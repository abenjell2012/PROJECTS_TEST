package fr.bpce.yyd.batch.commun.processor;

import java.util.Arrays;
import java.util.List;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.beans.DataEvenement;
import fr.bpce.yyd.batch.commun.service.ReferenceSrvcImpl;

@Service("evtFiltreProcessor")
public class EvenementFiltreProcessor implements ItemProcessor<DataEvenement, DataEvenement> {

	private static final List<String> EVTS_A_RESTITUER = Arrays.asList("IF", "PP", "AR0", "AR1", "AR2", "AR3", "IMX",
			"DAX", "F");

	@Autowired
	private ReferenceSrvcImpl refSrvcImpl;

	@Override
	public DataEvenement process(DataEvenement evt) throws Exception {

		String codeEvt = evt.getCode().trim();

		if (EVTS_A_RESTITUER.contains(codeEvt)) {
			return evt;
		}

		if (evt.getCategorieSegment() == null || refSrvcImpl.isEventUtpNow(codeEvt, evt.getCategorieSegment())) {
			return evt;
		}

		// filtrage (En retournant null,le bean evt n'est pas envoyé au
		// writer)
		return null;
	}

}
