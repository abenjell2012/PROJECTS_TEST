package fr.bpce.yyd.batch.commun.beans;

import java.sql.Date;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class DataEventMDC {

	private Long idSynthese;

	private Long idEvt;

	private Date dateDebut;

	private String codeEvt;

	private String statut;

	private Date dateEffet;

	private Date dateCloture;

	private Timestamp dateGenerationMdc;

	private String origineContagion;

	// pour mensuel
	private Date dar;

}
