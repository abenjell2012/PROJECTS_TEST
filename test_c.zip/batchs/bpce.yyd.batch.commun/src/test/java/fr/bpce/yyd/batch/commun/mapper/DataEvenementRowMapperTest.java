package fr.bpce.yyd.batch.commun.mapper;

import fr.bpce.yyd.batch.commun.beans.DataEvenement;
import org.junit.Test;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class DataEvenementRowMapperTest {


    DataEvenementRowMapper mapper = new DataEvenementRowMapper();

    @Test
    public void testMapRow() throws SQLException {
        ResultSet inputRs = mock(ResultSet.class);
        when(inputRs.getString(6)).thenReturn("code1");
        DataEvenement result = mapper.mapRow(inputRs, 6);
        assertEquals("code1", result.getCode());
    }


}
