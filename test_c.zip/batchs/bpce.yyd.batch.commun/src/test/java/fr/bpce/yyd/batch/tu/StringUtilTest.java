package fr.bpce.yyd.batch.tu;

import static fr.bpce.yyd.batch.commun.utils.StringUtil.isEmpty;
import static fr.bpce.yyd.batch.commun.utils.StringUtil.isSizeExceeded;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class StringUtilTest {
	@Test
	public void testIsEmpty() throws Exception {
		String chaine = "";
		Boolean str = isEmpty(chaine);
		assertTrue(str);
	}

	@Test
	public void testIsNotEmpty() throws Exception {
		String chaine = "ff";
		Boolean str = isEmpty(chaine);
		assertFalse(str);
	}

	@Test
	public void testisSizeExceeded() throws Exception {
		String champ = "tototiti";
		int taille = 3;
		Boolean str = isSizeExceeded(champ, taille);
		assertTrue(str);
	}

	@Test
	public void testisNotSizeExceeded() throws Exception {
		String champ = "toto";
		int taille = 4;
		Boolean str = isSizeExceeded(champ, taille);
		assertFalse(str);
	}
}
