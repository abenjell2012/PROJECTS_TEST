package fr.bpce.yyd.batch.commun.mapper;

import fr.bpce.yyd.batch.commun.beans.DataEvenement;
import fr.bpce.yyd.batch.commun.beans.DataEventLocal;
import org.junit.Test;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class DataEventLocalMapperTest {


    DataEventLocalMapper mapper = new DataEventLocalMapper();

    @Test
    public void testMapRow() throws SQLException {
        ResultSet inputRs = mock(ResultSet.class);
        when(inputRs.getString(4)).thenReturn("codeEventLocal");
        DataEventLocal result = mapper.mapRow(inputRs, 4);
        assertEquals("codeEventLocal", result.getCode());
    }


}
