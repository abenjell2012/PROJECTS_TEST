package fr.bpce.yyd.batch.tu;

import static fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils.convertToFixedLength;
import static fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils.generateDetailFicEvents;
import static fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils.generateEnqueueFic;
import static fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils.generateEnteteFic;
import static fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils.getNotNullBigDecimal;
import static fr.bpce.yyd.batch.commun.utils.RestitSyntheseUtils.round;
import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.Date;

import org.junit.Test;

import fr.bpce.yyd.batch.commun.beans.DataEvenement;

public class RestitSyntheseUtilsTest {
	@Test
	public void testgenerateEnqueuFic() throws Exception {
		String codeBanque = "10107";
		int size = 1;
		String dateConstitutionFic = "20210514";

		String ef = generateEnqueueFic(codeBanque, size, dateConstitutionFic);
		assertEquals("*92021051410107MDC001+00000000000001", ef);
	}

	@Test
	public void testgenerateEnteteFic() throws Exception {
		String codeBanque = "10107";

		String dateConstitutionFic = "20210514";

		String et = generateEnteteFic(codeBanque, dateConstitutionFic);
		assertEquals("*12021051410107MDC001", et);
	}

	/*
	 * @Test public void testgenerateDetailFicTiers() throws Exception {
	 * DetailTiersInfo dt = new DetailTiersInfo(); dt.setIdSituation("1234567");
	 * dt.setDatePhoto(LocalDate.of(2018, 12, 12));
	 * dt.setIdFederal("1234567893110");
	 * 
	 * dt.setCodeBanque("10807"); dt.setIdLocal("ID-TIERS-LOCAL-0001");
	 * dt.setCodeSegment("AR0"); dt.setStatutEff("ACT"); dt.setPalierEff("O");
	 * dt.setDateMajStatutEff(LocalDate.of(2018, 12, 10));
	 * dt.setOrigineStatutEff("DAX");
	 * dt.setCommentaireForcage("Premier dépassement"); dt.setTopPP('O');
	 * dt.setTopA('N'); dt.setTopAS('N');
	 * 
	 * dt.setIdEvtEntreeDefaut("ID-EVT-LOCAL-001");
	 * dt.setCodeEvtEntreeDefautCalcule("ACT");
	 * dt.setDateMetierEvtEntreeDefautCalcule(LocalDate.of(2018, 12, 10));
	 * dt.setWarning10('N'); dt.setWarning9('N'); dt.setWarning8('N');
	 * dt.setWarning7('N'); dt.setWarning6('N');
	 * 
	 * dt.setStatutEff("DAX");
	 * dt.setMontantTotalDax(BigDecimal.valueOf(+00000000000005000));
	 * dt.setIdSituation("ID-CONTRAT-001");
	 * 
	 * dt.setWarning1p1('N'); dt.setWarning1p2('N'); dt.setWarning1p3('N');
	 * dt.setWarning1p4('N'); dt.setWarning2('N'); dt.setWarning3('N');
	 * dt.setWarning4('N'); dt.setWarning5p1('N'); dt.setWarning5p2('N');
	 * dt.setWarning5p3('N');
	 * 
	 * String detail = generateDetailFicTiers(dt); assertEquals(detail,
	 * "ID-CONTRAT-001 20181212123456789311010807ID-TIERS-LOCAL-0001                               AR0 DAXO 20181210DAX Premier dépassement                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 O        "
	 * ); }
	 */

	@Test
	public void testgenerateDetailFicEvents() throws Exception {
		DataEvenement de = new DataEvenement();
		de.setIdRft("ID-RFT-1");
		de.setCodeBanque("10107");
		de.setIdLocal("IDLOC1");
		de.setIdEvent("44391527");
		de.setCode("DAX");
		de.setSousCode("TITI");
		de.setCommentaire("Premier depassement");
		de.setStatut("ACT");
		de.setDateDebut(Date.valueOf("2021-05-14"));
		de.setDateCloture(Date.valueOf("2021-07-14"));
		de.setTopTech(BigDecimal.valueOf(0));
		de.setTopLitige(BigDecimal.valueOf(0));
		de.setIdContrat("ID-CONT-1");
		de.setMontant(BigDecimal.valueOf(00000000000005000));
		String me = generateDetailFicEvents(de);
		assertEquals(
				"ID-RFT-1  10107IDLOC1                                            44391527                      DAXTITIPremier depassement                                                                                                                                                                                          ACT20210514        20210714NNID-CONT-1                                         +00000000000256000                                                                                                ",
				me);
	}

	@Test
	public void testgetNotNullBigDecimal() throws Exception {
		BigDecimal bg = null;
		BigDecimal bd = getNotNullBigDecimal(bg);
		assertEquals(BigDecimal.valueOf(0), bd);
	}

	@Test
	public void testconvertToFixedLengthNull() throws Exception {
		String str = null;
		int taille = 10;
		String fl = convertToFixedLength(str, taille);
		assertEquals("          ", fl);
	}

	@Test
	public void testconvertToFixedLength() throws Exception {
		String str = "toto";
		int taille = 10;
		String fl = convertToFixedLength(str, taille);
		assertEquals("toto      ", fl);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRound() throws IllegalArgumentException {
		Double value = 7d;
		int places = -1;
		round(value, places);
	}
}
