package fr.bpce.yyd.batch.tu;

import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculCompteurA;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculCompteurAS;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculDatePrevisionnelleFinPP;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningAR0;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningAR1;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningAR2;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningAR3;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningCX;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningDX;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningDefaut;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningForbearance;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningPP;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningPPWithAS;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningPPWithF;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningRX;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.calculWarningSain;
import static fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils.checkCompteur;
import static org.junit.Assert.*;

import java.sql.Date;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import fr.bpce.yyd.batch.commun.utils.CalculSyntheseTiersUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

@RunWith(MockitoJUnitRunner.class)
public class CalculSyntheseTiersUtilsTest {

	@Mock
	private JdbcTemplate jdbcTemplate;

	@Test
	public void testFindTiersIdCasNominal()  {

		List<Long> idtiers = new ArrayList<>();
		idtiers.add(2L);

		Mockito.when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(PreparedStatementSetter.class),Mockito.any(RowMapper.class))).thenReturn(idtiers);

		long value = CalculSyntheseTiersUtils.findTiersId("10107","IDLOC1",jdbcTemplate);

		assertEquals(2L,value);

	}

	@Test
	public void testFindTiersIdCasNull()  {

		List<Long> idtiers = new ArrayList<>();

		Mockito.when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(PreparedStatementSetter.class),Mockito.any(RowMapper.class))).thenReturn(idtiers);

		assertNull(CalculSyntheseTiersUtils.findTiersId("10107","IDLOC1",jdbcTemplate));

	}

	@Test
	public void testCalculDatePrevisionnelleFinPPCasNominal() throws Exception {

		LocalDate datePP = LocalDate.of(2020, 1, 1);
		Boolean topF = false;

		Date date = calculDatePrevisionnelleFinPP(datePP, topF, 45L);

		assertEquals(date, Date.valueOf(LocalDate.of(2020, 2, 15)));

	}

	@Test
	public void testCalculDatePrevisionnelleFinPPCas365j() throws Exception {

		LocalDate datePP = LocalDate.of(2020, 1, 1);
		Boolean topF = true;

		Date date = calculDatePrevisionnelleFinPP(datePP, topF, 45L);

		assertEquals(date, Date.valueOf(LocalDate.of(2020, 11, 16)));

	}

	@Test
	public void testCalculCompteurAs() throws Exception {
		LocalDate dateAS = LocalDate.of(2021, 4, 10);
		LocalDate dateCalcul = LocalDate.of(2021, 5, 10);

		Long cp = calculCompteurAS(dateAS, dateCalcul);
		assertEquals(Long.valueOf(31), cp);

	}

	@Test
	public void testCalculDateA() throws Exception {
		LocalDate dateA = LocalDate.of(2021, 4, 10);
		LocalDate dateCalcul = LocalDate.of(2021, 5, 10);

		Long cp = calculCompteurA(dateA, dateCalcul);
		assertEquals(Long.valueOf(31), cp);

	}

	@Test
	public void testcalculWarningAR0() throws Exception {

		String oldPalierAs = "AR1";
		String palierAs = "AR0";

		boolean data = calculWarningAR0(oldPalierAs, palierAs);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningAR0Null() throws Exception {

		String oldPalierAs = null;
		String palierAs = null;

		boolean data = calculWarningAR0(oldPalierAs, palierAs);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningAR0False() throws Exception {

		String oldPalierAs = "AR0";
		String palierAs = "AR0";

		boolean data = calculWarningAR0(oldPalierAs, palierAs);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningAR1() throws Exception {

		String oldPalierAs = "AR0";
		String palierAs = "AR1";

		boolean data = calculWarningAR1(oldPalierAs, palierAs);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningAR1False() throws Exception {

		String oldPalierAs = "AR1";
		String palierAs = "AR1";

		boolean data = calculWarningAR1(oldPalierAs, palierAs);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningAR1Null() throws Exception {

		String oldPalierAs = null;
		String palierAs = null;

		boolean data = calculWarningAR1(oldPalierAs, palierAs);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningAR2() throws Exception {

		String oldPalierAs = "AR0";
		String palierAs = "AR2";

		boolean data = calculWarningAR2(oldPalierAs, palierAs);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningAR2Null() throws Exception {

		String oldPalierAs = null;
		String palierAs = null;

		boolean data = calculWarningAR2(oldPalierAs, palierAs);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningAR2False() throws Exception {

		String oldPalierAs = "AR2";
		String palierAs = "AR2";

		boolean data = calculWarningAR2(oldPalierAs, palierAs);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningAR3() throws Exception {

		String oldPalierAs = "AR0";
		String palierAs = "AR3";

		boolean data = calculWarningAR3(oldPalierAs, palierAs);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningAR3Null() throws Exception {

		String oldPalierAs = null;
		String palierAs = null;

		boolean data = calculWarningAR3(oldPalierAs, palierAs);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningAR3False() throws Exception {

		String oldPalierAs = "AR3";
		String palierAs = "AR3";

		boolean data = calculWarningAR3(oldPalierAs, palierAs);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningForbearance() throws Exception {

		boolean oldTopF = false;
		boolean topF = true;

		boolean data = calculWarningForbearance(oldTopF, topF);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningForbearanceEquals() throws Exception {

		boolean oldTopF = true;
		boolean topF = true;

		boolean data = calculWarningForbearance(oldTopF, topF);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningForbearanceFalse() throws Exception {

		boolean oldTopF = true;
		boolean topF = false;

		boolean data = calculWarningForbearance(oldTopF, topF);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningDefaut() throws Exception {

		String oldStatutEffectif = "RX";
		String statutEffectif = "D";
		boolean data = calculWarningDefaut(oldStatutEffectif, statutEffectif);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningDefautEquals() throws Exception {

		String oldStatutEffectif = "D";
		String statutEffectif = "D";
		boolean data = calculWarningDefaut(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningDefautNull() throws Exception {

		String oldStatutEffectif = null;
		String statutEffectif = null;
		boolean data = calculWarningDefaut(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningRX() throws Exception {

		String oldStatutEffectif = "D";
		String statutEffectif = "RX";
		boolean data = calculWarningRX(oldStatutEffectif, statutEffectif);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningRXNull() throws Exception {

		String oldStatutEffectif = null;
		String statutEffectif = null;
		boolean data = calculWarningRX(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningRXEquals() throws Exception {

		String oldStatutEffectif = "RX";
		String statutEffectif = "RX";
		boolean data = calculWarningRX(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningDX() throws Exception {

		String oldStatutEffectif = "RD";
		String statutEffectif = "DX";
		boolean data = calculWarningDX(oldStatutEffectif, statutEffectif);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningDXNull() throws Exception {

		String oldStatutEffectif = null;
		String statutEffectif = null;
		boolean data = calculWarningDX(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningDXEquals() throws Exception {

		String oldStatutEffectif = "DX";
		String statutEffectif = "DX";
		boolean data = calculWarningDX(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningCX() throws Exception {

		String oldStatutEffectif = "RD";
		String statutEffectif = "CX";
		boolean data = calculWarningCX(oldStatutEffectif, statutEffectif);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningCXNull() throws Exception {

		String oldStatutEffectif = null;
		String statutEffectif = null;
		boolean data = calculWarningCX(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningCXEquals() throws Exception {

		String oldStatutEffectif = "CX";
		String statutEffectif = "CX";
		boolean data = calculWarningCX(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningPP() throws Exception {

		boolean oldtopPP = false;
		boolean topPP = true;
		boolean data = calculWarningPP(oldtopPP, topPP);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningPPEquals() throws Exception {

		boolean oldtopPP = true;
		boolean topPP = true;
		boolean data = calculWarningPP(oldtopPP, topPP);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningPPFalse() throws Exception {

		boolean oldtopPP = true;
		boolean topPP = false;
		boolean data = calculWarningPP(oldtopPP, topPP);
		assertFalse(data);

	}

	@Test
	public void testalculWarningPPWithAS() throws Exception {

		boolean topPP = true;
		boolean topAs = true;
		boolean oldTopAs = false;
		boolean oldPhoto = true;
		boolean data = calculWarningPPWithAS(topPP, topAs, oldTopAs, oldPhoto);
		assertTrue(data);

	}

	@Test
	public void testalculWarningPPWithASEquals() throws Exception {

		boolean topPP = true;
		boolean topAs = true;
		boolean oldTopAs = true;
		boolean oldPhoto = true;
		boolean data = calculWarningPPWithAS(topPP, topAs, oldTopAs, oldPhoto);
		assertFalse(data);

	}

	@Test
	public void testalculWarningPPWithASFalse() throws Exception {

		boolean topPP = false;
		boolean topAs = false;
		boolean oldTopAs = true;
		boolean oldPhoto = false;
		boolean data = calculWarningPPWithAS(topPP, topAs, oldTopAs, oldPhoto);
		assertFalse(data);

	}

	@Test
	public void testalculWarningPPWithASFalseEtPP() throws Exception {

		boolean topPP = true;
		boolean topAs = false;
		boolean oldTopAs = true;
		boolean oldPhoto = false;
		boolean data = calculWarningPPWithAS(topPP, topAs, oldTopAs, oldPhoto);
		assertFalse(data);

	}

	@Test
	public void testalculWarningPPWithASFalseEtAs() throws Exception {

		boolean topPP = false;
		boolean topAs = true;
		boolean oldTopAs = false;
		boolean oldPhoto = true;
		boolean data = calculWarningPPWithAS(topPP, topAs, oldTopAs, oldPhoto);
		assertFalse(data);

	}

	@Test
	public void testalculWarningPPWithASFalseAll() throws Exception {

		boolean topPP = true;
		boolean topAs = false;
		boolean oldTopAs = false;
		boolean oldPhoto = true;
		boolean data = calculWarningPPWithAS(topPP, topAs, oldTopAs, oldPhoto);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningSain() throws Exception {

		String oldStatutEffectif = "D";
		String statutEffectif = "ND";
		boolean data = calculWarningSain(oldStatutEffectif, statutEffectif);
		assertTrue(data);

	}

	@Test
	public void testcalculWarningSainNull() throws Exception {

		String oldStatutEffectif = null;
		String statutEffectif = null;
		boolean data = calculWarningSain(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningSainEquals() throws Exception {

		String oldStatutEffectif = "ND";
		String statutEffectif = "ND";
		boolean data = calculWarningSain(oldStatutEffectif, statutEffectif);
		assertFalse(data);

	}

	@Test
	public void testcalculWarningPPWithF() throws Exception {
		String statutEffectif = "ND";
		boolean warning2 = true;
		boolean topF = true;
		boolean warning8 = true;
		boolean data = calculWarningPPWithF(statutEffectif, warning2, topF, warning8);
		assertTrue(data);
	}

	@Test
	public void testcalculWarningPPWithFFalse() throws Exception {
		String statutEffectif = "ND";
		boolean warning2 = false;
		boolean topF = false;
		boolean warning8 = false;
		boolean data = calculWarningPPWithF(statutEffectif, warning2, topF, warning8);
		assertFalse(data);
	}

	@Test
	public void testcalculWarningPPWithFEtDefaut() throws Exception {
		String statutEffectif = "D";
		boolean warning2 = true;
		boolean topF = false;
		boolean warning8 = true;
		boolean data = calculWarningPPWithF(statutEffectif, warning2, topF, warning8);
		assertFalse(data);
	}

	@Test
	public void testcalculWarningPPWithFEtNull() throws Exception {
		String statutEffectif = null;
		boolean warning2 = true;
		boolean topF = true;
		boolean warning8 = true;
		boolean data = calculWarningPPWithF(statutEffectif, warning2, topF, warning8);
		assertTrue(data);
	}

	@Test
	public void testcheckCompteurSup9999l() throws Exception {
		long compteur = 1000000l;

		long data = checkCompteur(compteur);
		assertEquals(9999l, data);
	}

	@Test
	public void testcheckCompteurInf9999l() throws Exception {
		long compteur = 777l;
		long data = checkCompteur(compteur);
		assertEquals(777l, data);
	}

}
