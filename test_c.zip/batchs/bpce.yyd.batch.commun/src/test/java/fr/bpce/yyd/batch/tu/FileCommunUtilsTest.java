package fr.bpce.yyd.batch.tu;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.compressAndDeleteFile;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.checkRepertoire;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.getExtension;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.isFlagValide;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.removeFileExtension;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.compressAndDeleteFile;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

public class FileCommunUtilsTest {

	File file ;

	/* This folder and the files created in it will be deleted after
	 * tests are run, even in the event of failures or exceptions.
	 */
	@Rule
	public TemporaryFolder folder = new TemporaryFolder();

	/* executed before every test: create temporary files */
	@Before
	public void setUp() {
		try {
			file = folder.newFile( "testfile1.txt" );
		}
		catch( IOException ioe ) {
			System.err.println("error creating temporary test file in " + this.getClass().getSimpleName() );
		}
	}

	@Test
	public void testCompressAndDeleteFileOK() throws IOException {
		Path compressAndDeleteFile = compressAndDeleteFile(file.toPath());
		assertNotNull(compressAndDeleteFile);
		assertEquals(file.toString()+".gz",compressAndDeleteFile.toFile().toString());
	}

	@Test ( expected = IOException.class)
	public void testCompressAndDeleteFileKO() throws IOException {
		File fileKO = new File(( "testfile2.txt" )) ;
		Path compressAndDeleteFile = compressAndDeleteFile(fileKO.toPath());

	}

	@Test
	public void TestcheckRepertoire() throws Exception {
		String path = "Git";
		checkRepertoire(path);

	}

	@Test
	public void testisDatesOverlaps() throws Exception {
		String flag = "O";

		Boolean O = isFlagValide(flag);

		assertEquals(true, O);

	}

	@Test
	public void testisDatesOverlapsN() throws Exception {
		String flag = "N";

		Boolean O = isFlagValide(flag);

		assertEquals(true, O);

	}

	@Test
	public void testisDatesOverlapsF() throws Exception {
		String flag = "h";

		Boolean O = isFlagValide(flag);

		assertEquals(false, O);

	}

	@Test
	public void testgetExtension() throws Exception {
		String fichier = "h.h";

		String exist = getExtension(fichier);

		assertEquals("h", exist);

	}

	@Test
	public void testgetSansExtension() throws Exception {
		String fichier = "";

		String exist = getExtension(fichier);

		assertEquals("", exist);

	}

	@Test
	public void testremoveFileExtension() throws Exception {
		String fichier = "h.h";

		String exist = removeFileExtension(fichier);

		assertEquals("h", exist);

	}

	@Test
	public void testremoveFileSansExtension() throws Exception {
		String fichier = "";

		String exist = removeFileExtension(fichier);

		assertEquals("", exist);

	}

	@Test
	public void testbatchStatusNull() throws Exception {
		JobExecution execution = null;

		BatchStatus bs = batchStatus(execution);
		assertEquals(BatchStatus.UNKNOWN, bs);

	}

}
