package fr.bpce.yyd.batch.commun.mapper;

import fr.bpce.yyd.batch.commun.beans.DataEventMDC;
import org.junit.Test;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class DataEventMdcMapperTest {


    DataEventMdcMapper mapper = new DataEventMdcMapper();

    @Test
    public void testMapRow() throws SQLException {
        ResultSet inputRs = mock(ResultSet.class);
        when(inputRs.getString(4)).thenReturn("codeEventMDC");
        DataEventMDC result = mapper.mapRow(inputRs, 4);
        assertEquals("codeEventMDC", result.getCodeEvt());
    }


}
