package fr.bpce.yyd.batch.tu;

import static fr.bpce.yyd.batch.commun.utils.DateUtil.isDatesOverlaps;
import static fr.bpce.yyd.batch.commun.utils.DateUtil.isFormatDateValid;
import static fr.bpce.yyd.batch.commun.utils.DateUtil.isFormatDateValide;
import static fr.bpce.yyd.batch.commun.utils.DateUtil.parseDate;
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Test;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.utils.DateUtil;

public class DateUtilTest {

	@Test
	public void testisDatesOverlapsEndNull() throws Exception {

		LocalDate start1 = LocalDate.of(2021, 04, 12);
		LocalDate end1 = null;
		LocalDate start2 = LocalDate.of(2021, 04, 20);
		LocalDate end2 = null;
		Boolean date = isDatesOverlaps(start1, end1, start2, end2);

		assertEquals(true, date);

	}

	@Test
	public void testisDatesOverlapsEnd1Null() throws Exception {

		LocalDate start1 = LocalDate.of(2021, 04, 12);
		LocalDate end1 = null;
		LocalDate start2 = LocalDate.of(2021, 04, 20);
		LocalDate end2 = LocalDate.of(2021, 05, 20);
		Boolean date = isDatesOverlaps(start1, end1, start2, end2);

		assertEquals(true, date);

	}

	@Test
	public void testisDatesOverlapsEnd2Null() throws Exception {

		LocalDate start1 = LocalDate.of(2021, 04, 12);
		LocalDate end1 = LocalDate.of(2021, 05, 12);
		LocalDate start2 = LocalDate.of(2021, 04, 20);
		LocalDate end2 = null;
		Boolean date = isDatesOverlaps(start1, end1, start2, end2);

		assertEquals(true, date);

	}

	@Test
	public void testisFormatDateValide() throws Exception {
		String dateString = "20211205";
		DateTimeFormatter formater = Constant.YYYYMMDD_FORMATTER;

		Pair<Boolean, LocalDate> date = isFormatDateValide(dateString, formater);
		assertEquals(ImmutablePair.of(true, LocalDate.of(2021, 12, 05)), date);

	}

	@Test
	public void testisFormatDateValidef() throws Exception {
		String dateString = "2021-1205";
		DateTimeFormatter formater = Constant.YYYYMMDD_FORMATTER;

		Pair<Boolean, LocalDate> date = isFormatDateValide(dateString, formater);
		assertEquals(ImmutablePair.of(false, null), date);

	}

	@Test
	public void testisFormatDateValid() throws Exception {
		String dateString = "2021-1205";
		DateTimeFormatter formater = Constant.YYYYMMDD_FORMATTER;

		boolean date = isFormatDateValid(dateString, formater);

		assertEquals(false, date);

	}

	@Test
	public void testisFormatDateValidT() throws Exception {
		String dateString = "20211205";
		DateTimeFormatter formater = Constant.YYYYMMDD_FORMATTER;

		boolean date = isFormatDateValid(dateString, formater);
		assertEquals(true, date);

	}

	@Test
	public void testisDatesOverlapsOk() throws Exception {

		LocalDate start1 = LocalDate.of(2021, 04, 12);
		LocalDate end1 = LocalDate.of(2021, 05, 12);
		LocalDate start2 = LocalDate.of(2021, 04, 20);
		LocalDate end2 = LocalDate.of(2021, 05, 20);
		Boolean date = isDatesOverlaps(start1, end1, start2, end2);

		assertEquals(true, date);

	}

	@Test
	public void testparseDate() throws Exception {
		String dateString = "20211205";

		LocalDate date = parseDate(dateString);
		assertEquals(LocalDate.of(2021, 12, 05), date);

	}

	@Test
	public void testMain() {
		String[] args = { "20210412", "20210512", "20210620", "20210720" };
		DateUtil.main(args);

		LocalDate start1 = LocalDate.of(2021, 04, 12);
		LocalDate end1 = LocalDate.of(2021, 05, 12);
		LocalDate start2 = LocalDate.of(2021, 04, 20);
		LocalDate end2 = null;
		Boolean date = isDatesOverlaps(start1, end1, start2, end2);

		assertEquals(true, date);
		
		LocalDate date5 = LocalDate.of(2019, 5, 01);
		LocalDate date6 = LocalDate.of(2019, 6, 01);
		LocalDate date7 = LocalDate.of(2019, 7, 03);
		LocalDate date8 = LocalDate.of(2019, 8, 01);

		boolean res2 = isDatesOverlaps(date5, date6, date7, date8);

		assertEquals(true, !res2);

		LocalDate date9 = LocalDate.of(2019, 5, 01);
		LocalDate date10 = LocalDate.of(2019, 6, 01);
		LocalDate date11 = LocalDate.of(2019, 6, 01);
		LocalDate date12 = LocalDate.of(2019, 8, 01);

		boolean res3 = isDatesOverlaps(date9, date10, date11, date12);

		assertEquals(true, !res3);
		
		LocalDate date13 = LocalDate.of(2019, 10, 01);
		LocalDate date14 = LocalDate.of(2019, 12, 01);
		LocalDate date15 = LocalDate.of(2019, 4, 01);
		LocalDate date16 = LocalDate.of(2019, 10, 01);

		boolean res4 = isDatesOverlaps(date13, date14, date15, date16);

		assertEquals(true, !res4);

		LocalDate date17 = LocalDate.of(2019, 05, 01);
		LocalDate date18 = LocalDate.of(2019, 05, 23);
		LocalDate date19 = LocalDate.of(2019, 05, 24);
		LocalDate date20 = null;

		boolean res5 = isDatesOverlaps(date17, date18, date19, date20);

		assertEquals(true, !res5);

		LocalDate date21 = LocalDate.of(2019, 05, 24);
		LocalDate date22 = null;
		LocalDate date23 = LocalDate.of(2019, 05, 01);
		LocalDate date24 = LocalDate.of(2019, 05, 23);

		boolean res6 = isDatesOverlaps(date21, date22, date23, date24);

		assertEquals(true, !res6);

	}

}
