package fr.bpce.yyd.batch.tu;

import static fr.bpce.yyd.batch.commun.utils.NumericUtil.arrondir;
import static fr.bpce.yyd.batch.commun.utils.NumericUtil.convertToBigDecimal;
import static fr.bpce.yyd.batch.commun.utils.NumericUtil.isDigit;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

import org.junit.Test;

public class NumericUtilTest {
	@Test
	public void testconvertToBigDecimal() throws Exception {

		Double value = 7.1234567891234567;
		BigDecimal bd = convertToBigDecimal(value);

		assertEquals(BigDecimal.valueOf(7.123456789123456), bd);

	}

	@Test
	public void testconvertToBigDecimalNull() throws Exception {

		Double value = null;
		BigDecimal bd = convertToBigDecimal(value);

		assertEquals(BigDecimal.valueOf(0.00), bd);

	}

	@Test
	public void testArrondir() throws Exception {
		// Arange
		BigDecimal value = BigDecimal.valueOf(50.1239);
		int nbChiffresApresVirgule = 2;
		
		// Act
		BigDecimal bd = arrondir(value, nbChiffresApresVirgule);

		// Assert
		assertEquals(BigDecimal.valueOf(50.12), bd);
	}

	@Test
	public void testisDigit() throws Exception {

		CharSequence cs = "toto";
		boolean t = isDigit(cs);

		assertFalse(t);

	}

	@Test
	public void testisDigitNull() throws Exception {

		CharSequence cs = null;
		boolean t = isDigit(cs);

		assertFalse(t);

	}

	@Test
	public void testisDigitTrue() throws Exception {

		CharSequence cs = "123221223";
		boolean t = isDigit(cs);

		assertTrue(t);

	}

	@Test
	public void testisDigitLenghtNull() throws Exception {

		CharSequence cs = "";
		boolean t = isDigit(cs);

		assertFalse(t);

	}

	@Test
	public void testisDigitT() throws Exception {

		CharSequence cs = "~11345";
		boolean t = isDigit(cs);

		assertFalse(t);

	}
}
