package fr.bpce.yyd.batch.compteur.ti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import javax.persistence.EntityManager;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.messages.kafka.ProducteurMessagesKafka;
import fr.bpce.yyd.commun.model.ArriereSignificatif;
import fr.bpce.yyd.commun.model.ComplementArriere;
import fr.bpce.yyd.commun.model.ElementsDeCalcul;
import fr.bpce.yyd.commun.model.IdentiteTiers;
import fr.bpce.yyd.commun.model.Tiers;

@RunWith(PowerMockRunner.class)
@PrepareForTest(value = { MessagesFactory.class })
public class IntegrationTest {

	private static ApplicationContext context = null;
	protected static TransactionTemplate transactionTemplate = null;

	@FunctionalInterface
	public interface TransactionCallback {
		void doInTransaction();
	}

	@BeforeClass
	public static void initSpring() throws IOException, NoSuchFieldException, SecurityException,
			IllegalArgumentException, IllegalAccessException {
		context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml");
		transactionTemplate = new TransactionTemplate(getTransactionManager());
		URL url = ClassLoader.getSystemClassLoader().getResource("config-ti.properties");
		String filename = url.getPath();
		Properties properties = new Properties();
		InputStream input = new FileInputStream(filename);
		properties.load(input);
		input.close();

		Field propertiesField = ConfigManager.class.getDeclaredField("properties");
		propertiesField.setAccessible(true);
		propertiesField.set(null, properties);
		initData();

	}

	public static ApplicationContext getContext() {
		return context;
	}

	@Test
	public void launchOK() {
		JobExecution jobExec = null;
		// simuler envoi kafka
		ProducteurMessagesKafka producteur = Mockito.mock(ProducteurMessagesKafka.class);
		Mockito.doNothing().when(producteur).envoieMessage(Mockito.any(), Mockito.anyString(), Mockito.anyList());
		// Mock producteur kafka
		PowerMockito.mockStatic(MessagesFactory.class);
		PowerMockito.doReturn(producteur).when(MessagesFactory.class);
		MessagesFactory.getProducteur();

		try {
			jobExec = lauchBatch();
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(jobExec);
		assertEquals(ExitStatus.COMPLETED, jobExec.getExitStatus());
	}

	private static void initData() {

		// evenement_calcul_seq

		doInTransaction(() -> {
			// tiers 1
			Tiers tiers = new Tiers();
			IdentiteTiers ident = new IdentiteTiers();
			ident.setCodeSegment("3200");
			ident.setDateDebut(LocalDate.of(2020, 6, 1));
			tiers.addIdentite(ident);
			getEntityManager().persist(tiers);

			ElementsDeCalcul edc = new ElementsDeCalcul();
			edc.setTiers(tiers);
			getEntityManager().persist(edc);

			ArriereSignificatif as = new ArriereSignificatif();
			as.setTiers(tiers);
			as.setDateDebut(LocalDate.of(2020, 01, 01));
			ComplementArriere complAS = new ComplementArriere();
			complAS.setEntree(edc);
			as.setComplement(complAS);
			getEntityManager().persist(as);

			// tiers 2
			Tiers tiers1 = new Tiers();
			IdentiteTiers id1 = new IdentiteTiers();
			id1.setCodeBanque("10107");
			id1.setIdLocal("1987653");
			id1.setDateDebut(LocalDate.of(2020, 01, 01));
			id1.setDateFin(null);
			id1.setCodeSegment("1010");
			tiers1.addIdentite(id1);
			getEntityManager().persist(tiers1);

			ElementsDeCalcul edc1 = new ElementsDeCalcul();
			edc1.setTiers(tiers1);
			getEntityManager().persist(edc1);

			ArriereSignificatif as1 = new ArriereSignificatif();
			as1.setTiers(tiers1);
			as1.setDateDebut(LocalDate.of(2020, 01, 01));
			ComplementArriere complAS1 = new ComplementArriere();
			complAS1.setEntree(edc1);
			as1.setComplement(complAS1);
			getEntityManager().persist(as1);

		});
	}

	public static void doInTransaction(final TransactionCallback checker) {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				checker.doInTransaction();
			}
		});
	}

	public static JpaTransactionManager getTransactionManager() {
		return (JpaTransactionManager) context.getBean("transactionManager");
	}

	public static EntityManager getEntityManager() {
		return (EntityManager) context.getBean("entityManager");
	}

	public JobExecution lauchBatch() throws Exception {
		Job job = (Job) context.getBean(Constant.JOB_COMPTEUR);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		JobParameters jobParameters = new JobParametersBuilder()
				.addString("date", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
				.addString("dateCalcul", "20200730").addString("nb.tiers.par.lot", "200").toJobParameters();

		return jobLauncher.run(job, jobParameters);

	}

}
