package fr.bpce.yyd.batch.compteur.tu;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import org.h2.tools.SimpleResultSet;
import org.junit.Test;
import org.mockito.Mockito;

import fr.bpce.yyd.batch.compteur.mapper.CompteurRowMapper;

public class CompteurRowMapperTest {

	@Test
	public void testMapperOK() throws SQLException {
		CompteurRowMapper compteurMapper = new CompteurRowMapper();
		SimpleResultSet rs = Mockito.mock(SimpleResultSet.class);
		long idTiersAttendu = 1999L;
		Mockito.when(rs.getLong(1)).thenReturn(idTiersAttendu);
		long idTiers = compteurMapper.mapRow(rs, 1);
		assertNotNull(idTiers);
		assertEquals(idTiersAttendu, idTiers);

	}

}
