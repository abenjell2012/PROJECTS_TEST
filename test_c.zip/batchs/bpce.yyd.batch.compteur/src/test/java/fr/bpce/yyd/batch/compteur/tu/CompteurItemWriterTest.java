package fr.bpce.yyd.batch.compteur.tu;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.commun.messages.Topic;
import fr.bpce.yyd.batch.compteur.writer.CompteurItemWriter;
import fr.bpce.yyd.batch.messages.kafka.ProducteurMessagesKafka;

@RunWith(PowerMockRunner.class)
@PrepareForTest(value = { MessagesFactory.class, ConfigManager.class })
public class CompteurItemWriterTest {

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testWriterOK() throws Exception {
		String cle_topic_calcul = "topicCalcul";
		List<Long> items = Arrays.asList(12L, 23L, 123L, 878L);
		CompteurItemWriter writer = new CompteurItemWriter();
		writer.setParamDateCalcul("20200729");
		// Simuler l'envoi
		ProducteurMessagesKafka producteur = Mockito.mock(ProducteurMessagesKafka.class);
		Mockito.doNothing().when(producteur).envoieMessage(Mockito.eq(Topic.COMPTEURS_LISTE),
				Mockito.eq(cle_topic_calcul), Mockito.eq(items));
		// Mock static ConfigManager
		PowerMockito.mockStatic(ConfigManager.class);
		PowerMockito.doReturn(cle_topic_calcul).when(ConfigManager.class);
		ConfigManager.getProperty("kafka.topic.compteurs_liste");
		PowerMockito.mockStatic(MessagesFactory.class);
		PowerMockito.doReturn(producteur).when(MessagesFactory.class);
		MessagesFactory.getProducteur();

		// ACT
		writer.write(items);
		// VERIFY
		Mockito.verify(producteur).envoieMessage(Mockito.eq(Topic.COMPTEURS_LISTE), Mockito.eq(cle_topic_calcul),
				Mockito.any());

	}

}
