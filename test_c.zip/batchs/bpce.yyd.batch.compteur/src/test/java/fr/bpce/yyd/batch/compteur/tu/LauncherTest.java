package fr.bpce.yyd.batch.compteur.tu;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.utils.FileCommunUtils;
import fr.bpce.yyd.batch.compteur.launch.Launcher;

@RunWith(PowerMockRunner.class)
@PrepareForTest(value = { FileCommunUtils.class, ConfigManager.class })
public class LauncherTest {

	@Mock
	private ApplicationContext context;

	@InjectMocks
	private Launcher launcher;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testRunBatchOK() throws Exception {

		PowerMockito.mockStatic(ConfigManager.class);
		PowerMockito.doReturn("enable").when(ConfigManager.class);
		ConfigManager.getProperty("retro.kafka.statut");

		PowerMockito.mockStatic(FileCommunUtils.class);
		PowerMockito.doNothing().when(FileCommunUtils.class);
		FileCommunUtils.exitWithErrorCode(Mockito.anyInt());
		FileCommunUtils.finaliserTraitement(Mockito.any());

		JobLauncher jobLauncher = mock(SimpleJobLauncher.class);
		JobExecution jobExec = new JobExecution(1L);
		assertNotNull(jobExec);
		jobExec.setStatus(BatchStatus.COMPLETED);

		Mockito.when(context.getBean(Constant.JOB_COMPTEUR)).thenReturn(Mockito.mock(Job.class));
		Mockito.when(context.getBean("jobLauncher")).thenReturn(jobLauncher);
		Mockito.when(jobLauncher.run(Mockito.any(Job.class), Mockito.any(JobParameters.class))).thenReturn(jobExec);

		launcher.runBatch("20190630");
	}

	@Test
	public void testCasException1() throws Exception {
		// mock static
		PowerMockito.mockStatic(FileCommunUtils.class);
		PowerMockito.doNothing().when(FileCommunUtils.class);
		FileCommunUtils.exitWithErrorCode(Mockito.anyInt());

		PowerMockito.mockStatic(ConfigManager.class);
		PowerMockito.doReturn("enable").when(ConfigManager.class);
		ConfigManager.getProperty("retro.kafka.statut");

		Mockito.when(context.getBean(Constant.JOB_COMPTEUR)).thenReturn(Mockito.mock(Job.class));
		Mockito.when(context.getBean("jobLauncher"))
				.thenThrow(new IllegalStateException("erreur lors de la creation du bean jobLauncher "));

		assertNotNull(launcher);
		launcher.runBatch("20190630");

	}

	@Test
	public void testCasException2() throws Exception {

		JobLauncher jobLauncher = mock(SimpleJobLauncher.class);
		JobExecution jobExec = new JobExecution(1L);
		jobExec.setStatus(BatchStatus.COMPLETED);

		PowerMockito.mockStatic(ConfigManager.class);
		PowerMockito.doReturn("enable").when(ConfigManager.class);
		ConfigManager.getProperty("retro.kafka.statut");

		PowerMockito.mockStatic(FileCommunUtils.class);
		PowerMockito.doNothing().when(FileCommunUtils.class);
		FileCommunUtils.exitWithErrorCode(Mockito.anyInt());

		Mockito.when(context.getBean(Constant.JOB_COMPTEUR)).thenReturn(Mockito.mock(Job.class));
		Mockito.when(context.getBean("jobLauncher")).thenReturn(jobLauncher);
		Mockito.when(jobLauncher.run(Mockito.any(Job.class), Mockito.any(JobParameters.class)))
				.thenThrow(new JobParametersInvalidException("parametre du job invalide"));

		assertNotNull(launcher);
		launcher.runBatch("20190630");

	}

	@Test
	public void testDisableJob() throws Exception {

		PowerMockito.mockStatic(ConfigManager.class);
		PowerMockito.doReturn("disable").when(ConfigManager.class);
		ConfigManager.getProperty("retro.kafka.statut");

		assertNotNull(launcher);
		launcher.runBatch("20190630");

	}

	@Test
	public void testCasException3() throws Exception {

		PowerMockito.mockStatic(ConfigManager.class);
		PowerMockito.doThrow(new UnknownPropertyException("propertie unknown")).when(ConfigManager.class);
		ConfigManager.getProperty("retro.kafka.statut");

		PowerMockito.mockStatic(FileCommunUtils.class);
		PowerMockito.doNothing().when(FileCommunUtils.class);
		FileCommunUtils.exitWithErrorCode(Mockito.anyInt());

		assertNotNull(launcher);
		launcher.runBatch("20190630");

	}

	@Test(expected = BeanDefinitionStoreException.class)
	public void testGetAppContext() {
		Launcher launcher = new Launcher();
		launcher.getApplicationContext();
	}

	@Test
	public void testSetAppContext() {
		Launcher launcher = new Launcher();
		launcher.setApplicationContext(new ClassPathXmlApplicationContext("classpath:JobLauncher-context-ti.xml"));
		assertNotNull(launcher.getApplicationContext());
	}

}