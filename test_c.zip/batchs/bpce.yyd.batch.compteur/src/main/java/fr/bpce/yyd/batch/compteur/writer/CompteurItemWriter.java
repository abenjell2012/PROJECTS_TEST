package fr.bpce.yyd.batch.compteur.writer;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.exception.InvalidInitialisationException;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;
import fr.bpce.yyd.batch.commun.messages.MessagesFactory;
import fr.bpce.yyd.batch.commun.messages.ProducteurMessages;
import fr.bpce.yyd.batch.commun.messages.Topic;
import fr.bpce.yyd.batch.messages.dto.LotIdTiersDTO;

@Service
public class CompteurItemWriter implements ItemWriter<Long> {
	private static Logger logger = Logger.getLogger(CompteurItemWriter.class);

	private LocalDate dateCalcul;

	@Override
	public void write(List<? extends Long> items) throws Exception {

		logger.info("Début d'envoi d'un message kafka");
		LotIdTiersDTO lotIds = new LotIdTiersDTO();
		lotIds.setDateCalcul(dateCalcul);
		lotIds.getIdsTiers().addAll(items);
		envoieLotIds(lotIds);
		logger.info("Fin d'envoi du message kafka");

	}

	private void envoieLotIds(LotIdTiersDTO lotIds) throws UnknownPropertyException, InvalidInitialisationException {
		if (!lotIds.getIdsTiers().isEmpty()) {
			String topicName = ConfigManager.getProperty("kafka.topic.compteurs_liste");
			ProducteurMessages producteur = MessagesFactory.getProducteur();
			producteur.envoieMessage(Topic.COMPTEURS_LISTE, topicName, lotIds);
			// Réinitialisation
			lotIds.getIdsTiers().clear();
		}
	}

	public void setParamDateCalcul(String paramDateCalcul) {
		dateCalcul = LocalDate.parse(paramDateCalcul, DateTimeFormatter.BASIC_ISO_DATE);
	}
}
