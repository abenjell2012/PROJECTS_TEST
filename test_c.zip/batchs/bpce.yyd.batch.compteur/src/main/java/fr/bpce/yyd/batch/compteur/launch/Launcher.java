package fr.bpce.yyd.batch.compteur.launch;

import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.batchStatus;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.exitWithErrorCode;
import static fr.bpce.yyd.batch.commun.utils.FileCommunUtils.finaliserTraitement;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.bpce.yyd.batch.commun.configuration.ConfigManager;
import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.commun.exception.UnknownPropertyException;

public class Launcher {

	private static Logger logger = Logger.getLogger(Launcher.class);

	private static final String KAFKA_DISABLE = "disable";

	private ApplicationContext context = null;

	public void setApplicationContext(ApplicationContext newContext) {
		context = newContext;
	}

	public ApplicationContext getApplicationContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("classpath:JobLauncher-context.xml");
		}
		return context;
	}

	public void runBatch(String strDateCalcul) {

		try {
			logger.info("Debut BATCH COMPTEUR");
			if (KAFKA_DISABLE.equals(ConfigManager.getProperty("retro.kafka.statut"))) {
				logger.warn("Traitement interrompu : l'envoie kafka est désactivé");
				return;
			}

			String nbTiersParLot = ConfigManager.getProperty("nb.tiers.liste.batch.compteur");

			Job job = (Job) getApplicationContext().getBean(Constant.JOB_COMPTEUR);
			JobLauncher jobLauncher = (JobLauncher) getApplicationContext().getBean("jobLauncher");

			JobParameters jobParameters = new JobParametersBuilder()
					.addString("date", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
					.addString("dateCalcul", strDateCalcul).addString("nb.tiers.par.lot", nbTiersParLot)
					.toJobParameters();

			runJob(job, jobLauncher, jobParameters);

		} catch (UnknownPropertyException e) {
			logger.error("Erreur de paramètre " + e.getMessage());
			exitWithErrorCode(1);
		} catch (Exception err) {
			logger.error("Erreur inattendue pour le batch compteur " + err.getMessage(), err);
			exitWithErrorCode(1);
		}
	}

	private void runJob(Job job, JobLauncher jobLauncher, JobParameters jobParameters) {
		JobExecution execution = null;
		try {
			execution = jobLauncher.run(job, jobParameters);
		} catch (Exception e) {
			logger.error("Erreur: " + e.getMessage());
			exitWithErrorCode(1);
		} finally {
			finaliserTraitement(batchStatus(execution));
		}
	}

	public static void main(String[] args) {
		PropertyConfigurator.configure(ClassLoader.getSystemClassLoader().getResource("log4j-compteur.properties"));
		// Paramètre (éventuel) : date pour laquelle on calcule.
		// Sinon, ce sera la date du jour.
		String strDateCalcul = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
		if (args.length == 1) {
			String param1 = args[0];
			try {
				LocalDate.parse(param1, DateTimeFormatter.BASIC_ISO_DATE);
				strDateCalcul = param1; // Le format est bon
			} catch (DateTimeParseException dtpe) {
				logger.error("Erreur le format de la date passe en parametre est incorrect " + args[0]);
				exitWithErrorCode(1);
			}
		} else if (args.length > 1) {
			logger.error("Erreur - mauvais paramètres en entrée, on attend pas plus d'1 paramètre");
			exitWithErrorCode(1);
		}

		Launcher launcher = new Launcher();
		launcher.runBatch(strDateCalcul);
	}
}
