package fr.bpce.yyd.batch.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.commun.constantes.Constant;
import fr.bpce.yyd.batch.service.ReferenceImportSrvc;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.reference.RefEvtNdod;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.model.reference.RefSsCodEvt;

@Service
@Scope("singleton")
public class ReferenceImportSrvcImpl implements ReferenceImportSrvc {

	private static final String PARAM_TOP_SUPPR = "topSuppr";

	private static final Logger LOGGER = Logger.getLogger(ReferenceImportSrvcImpl.class);

	@Autowired
	private EntityManager entityManager;

	private List<String> codbqList = new ArrayList<>();
	private List<RefEvtNdod> refEvtList = new ArrayList<>();
	private List<RefCliSeg> refSegmentList = new ArrayList<>();
	private Map<String, List<RefSsCodEvt>> ssCodEvtMap = new HashMap<>();
	private List<RefCliSsClass> refCliSousClassList = new ArrayList<>();
	private List<RefImpactEvtMdc> refImpactEvtMdcList = new ArrayList<>();

	@Override
	public List<String> getCodBqReferenceList() {
		if (codbqList.isEmpty()) {
			LOGGER.info("récupération du référentiel CODE_BQ");
			TypedQuery<String> query = entityManager.createQuery("select codBq from RefBqBfbp where topSuppr=:topSuppr",
					String.class);
			query.setParameter(PARAM_TOP_SUPPR, Constant.FLAG_NON);
			codbqList = query.getResultList();
		}
		return codbqList;

	}

	@Override
	public List<RefEvtNdod> getCodEvtSirReferenceList() {
		if (refEvtList.isEmpty()) {
			LOGGER.info("récupération du référentiel CODE_EVT");
			TypedQuery<RefEvtNdod> query = entityManager.createQuery(
					"select refEvt from RefEvtNdod refEvt where refEvt.sourceEvt=:sourceEvt", RefEvtNdod.class);
			query.setParameter("sourceEvt", Constant.SRC_EVT_SIR);
			refEvtList = query.getResultList();
		}
		return refEvtList;

	}

	@Override
	public Map<String, List<RefSsCodEvt>> getSousCodeEvtReferenceMap() {
		if (ssCodEvtMap.isEmpty()) {
			LOGGER.info("récupération du référentiel SOUS CODE EVENEMENT");
			TypedQuery<RefSsCodEvt> query = entityManager.createQuery("SELECT ref FROM RefSsCodEvt ref",
					RefSsCodEvt.class);
			List<RefSsCodEvt> refSousCodeEvtList = query.getResultList();
			for (RefSsCodEvt refSsCodEvt : refSousCodeEvtList) {
				String cle = refSsCodEvt.getCodeEvt();
				ssCodEvtMap.computeIfAbsent(cle, v -> new ArrayList<RefSsCodEvt>());
				ssCodEvtMap.get(cle).add(refSsCodEvt);
			}
		}
		return ssCodEvtMap;

	}

	@Override
	public List<RefCliSsClass> getRefCliSousClassList() {
		if (refCliSousClassList.isEmpty()) {
			LOGGER.info("récupération du référentiel CODE SEGMENT SOUS CLASS");
			TypedQuery<RefCliSsClass> query = entityManager.createQuery(
					"select refSsClass from RefCliSsClass refSsClass where refSsClass.topSuppr=:topSuppr",
					RefCliSsClass.class);
			query.setParameter(PARAM_TOP_SUPPR, Constant.FLAG_NON);
			refCliSousClassList = query.getResultList();
		}
		return refCliSousClassList;
	}

	@Override
	public List<RefImpactEvtMdc> getRefImpactEvtMdcList() {
		if (refImpactEvtMdcList.isEmpty()) {
			LOGGER.info("récupération du référentiel IMPACT EVT");
			TypedQuery<RefImpactEvtMdc> query = entityManager.createQuery("select ref from RefImpactEvtMdc ref ",
					RefImpactEvtMdc.class);
			refImpactEvtMdcList = query.getResultList();
		}
		return refImpactEvtMdcList;
	}

	@Override
	public List<RefCliSeg> getCodSegReferenceList() {
		if (refSegmentList.isEmpty()) {
			LOGGER.info("récupération du référentiel CODE SEGMENT");
			TypedQuery<RefCliSeg> query = entityManager
					.createQuery("select ref from RefCliSeg ref where ref.topSuppr=:topSuppr", RefCliSeg.class);
			query.setParameter(PARAM_TOP_SUPPR, Constant.FLAG_NON);
			refSegmentList = query.getResultList();
		}
		return refSegmentList;
	}

	public Map<String, List<RefSsCodEvt>> getSsCodEvtMap() {
		return ssCodEvtMap;
	}

	public void setSsCodEvtMap(Map<String, List<RefSsCodEvt>> ssCodEvtMap) {
		this.ssCodEvtMap = ssCodEvtMap;
	}

	public void setCodbqList(List<String> codbqList) {
		this.codbqList = codbqList;
	}

	public void setCodEvtList(List<RefEvtNdod> codEvtList) {
		this.refEvtList = codEvtList;
	}

	public void setRefSegmentList(List<RefCliSeg> refSegmentList) {
		this.refSegmentList = refSegmentList;
	}

}
