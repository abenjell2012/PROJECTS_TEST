package fr.bpce.yyd.batch.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.beans.ImportEvenementAnnuleBean;
import fr.bpce.yyd.batch.beans.ImportEvtCloBean;
import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.repositories.ImportRepository;
import fr.bpce.yyd.batch.service.FunctionnalCheckerSrvc;
import fr.bpce.yyd.commun.constantes.Constant;
import fr.bpce.yyd.commun.model.reference.RefCliSeg;
import fr.bpce.yyd.commun.model.reference.RefCliSsClass;
import fr.bpce.yyd.commun.model.reference.RefEvtNdod;
import fr.bpce.yyd.commun.model.reference.RefImpactEvtMdc;
import fr.bpce.yyd.commun.model.reference.RefSsCodEvt;

@Service
@Scope("singleton")
public class FunctionnalCheckerSrvcImpl implements FunctionnalCheckerSrvc {

	private static Logger logger = Logger.getLogger(FunctionnalCheckerSrvcImpl.class);

	@Autowired
	private ReferenceImportSrvcImpl referenceImportSrvcImpl;

	@Autowired
	private ImportRepository importRepo;

	@Autowired
	private NdodFile ndodFile;

	private Map<String, List<ImportEvenementAnnuleBean>> mapEvenementAnnule = null;

	private List<ImportEvtCloBean> listEvtsClotures;

	/**
	 * Teste l'existence du paramètre codBq comme attribut codBq de la table de
	 * référence REF_BQ_BFBP.
	 *
	 * @param codBq
	 * @return
	 */
	@Override
	public boolean isCodeBanqueValide(String codBq) {
		List<String> codeEtablissements = referenceImportSrvcImpl.getCodBqReferenceList();
		return codeEtablissements.contains(codBq);
	}

	/**
	 * Teste la validité du code événement en paramètre, indépendamment de sa
	 * catégorie de segment (codTypNot).
	 *
	 * @param codEvt
	 * @return
	 */
	@Override
	public boolean isCodeEvementValide(String codEvt, LocalDate dateDemande) {
		List<RefEvtNdod> refEvtNdodList = referenceImportSrvcImpl.getCodEvtSirReferenceList();
		// filter par rapport à la date de demande
		List<RefEvtNdod> refEvtNdodADate = refEvtNdodList.stream()
				.filter(ref -> (ref.getDateDebut().compareTo(dateDemande) <= 0
						&& (ref.getDateFin() == null || ref.getDateFin().compareTo(dateDemande) > 0)))
				.collect(Collectors.toList());

		return refEvtNdodADate.stream().anyMatch(ref -> ref.getCodEvt().equals(codEvt));
	}

	/**
	 * Teste la validité du code segment en paramètre.
	 *
	 * @param codCliSeg
	 * @return
	 */
	@Override
	public boolean isCodeSegmentValide(String codCliSeg) {
		List<RefCliSeg> refCodeSegments = referenceImportSrvcImpl.getCodSegReferenceList();
		return refCodeSegments.stream().anyMatch(refSeg -> refSeg.getCodSegCli().equals(codCliSeg));
	}

	@Override
	public Optional<String> getLibelleSegment(String codCliSeg) {
		List<RefCliSeg> refCodeSegments = referenceImportSrvcImpl.getCodSegReferenceList();
		return refCodeSegments.stream().filter(refSeg -> refSeg.getCodSegCli().equals(codCliSeg))
				.map(RefCliSeg::getLibSegCli).findFirst();
	}

	@Override
	public boolean isSousCodeEvtValide(String ssCodeEvt, String codeEvt, LocalDate dateDemande) {
		Map<String, List<RefSsCodEvt>> ssCodeEvtMap = referenceImportSrvcImpl.getSousCodeEvtReferenceMap();
		List<RefSsCodEvt> ssCodeList = ssCodeEvtMap.get(codeEvt);
		if (ssCodeList != null) {
			// filter par rapport à la date de demande
			List<RefSsCodEvt> refSsCodEvtADate = ssCodeList.stream()
					.filter(ref -> (ref.getDateDebut().compareTo(dateDemande) <= 0
							&& (ref.getDateFin() == null || ref.getDateFin().compareTo(dateDemande) > 0)))
					.collect(Collectors.toList());
			return refSsCodEvtADate.stream().anyMatch(ref -> ref.getSsCodeEvt().equals(ssCodeEvt));
		}
		return true;
	}

	@Override
	public String findCategorieSegment(String segment) {
		List<RefCliSeg> refCliSegList = referenceImportSrvcImpl.getCodSegReferenceList();
		RefCliSeg refCliSeg = refCliSegList.stream().filter(ref -> ref.getCodSegCli().equals(segment)).findFirst()
				.orElse(null);
		if (refCliSeg == null) {
			return null;
		}
		List<RefCliSsClass> refCliSsClassList = referenceImportSrvcImpl.getRefCliSousClassList();
		RefCliSsClass refSsClass = refCliSsClassList.stream()
				.filter(ref -> ref.getCodSsClassCli().equals(refCliSeg.getCodSsClassCli())).findFirst().orElse(null);
		return refSsClass == null ? null : refSsClass.getCodTypNot();
	}

	@Override
	public String findImpactEvenement(String codEvt, String catSegment, LocalDate dateDemande) {
		List<RefImpactEvtMdc> refImpactList = referenceImportSrvcImpl.getRefImpactEvtMdcList();
		// filter par rapport à la date de demande
		List<RefImpactEvtMdc> refImpactListADAte = refImpactList.stream()
				.filter(ref -> (ref.getDateDebut().compareTo(dateDemande) <= 0
						&& (ref.getDateFin() == null || ref.getDateFin().compareTo(dateDemande) > 0)))
				.collect(Collectors.toList());
		// filrer par rapport à codeEvt et catSegment
		RefImpactEvtMdc refImpactEvtMdc = refImpactListADAte.stream()
				.filter(ref -> ref.getCodEvt().equals(codEvt) && ref.getCategorieSegment().equals(catSegment))
				.findFirst().orElse(null);
		// filter par catSegment = TOUS_AUTRES si le résultat est nulle
		if (refImpactEvtMdc == null) {
			refImpactEvtMdc = refImpactListADAte.stream().filter(
					ref -> ref.getCodEvt().equals(codEvt) && ref.getCategorieSegment().equals(Constant.TOUS_AUTRES))
					.findFirst().orElse(null);
		}

		return refImpactEvtMdc == null ? null : refImpactEvtMdc.getImpact();
	}

	@Override
	public boolean isEvementAnnule(String codEvt, String idLocalTiers, String idLocalEvenement, String codeBanque,
			LocalDate dateDebut) {
		if (mapEvenementAnnule == null) {
			mapEvenementAnnule = importRepo.loadEvenementTiersAnnule();
			logger.info("Chargement de la liste des évènements annulés");
		}
		List<ImportEvenementAnnuleBean> listEvenementAnnule = mapEvenementAnnule.get(codeBanque + "-" + idLocalTiers);
		if (listEvenementAnnule != null) {
			return listEvenementAnnule.stream().anyMatch(avtAnn -> avtAnn.getIdEvenementLocal().equals(idLocalEvenement)
					&& avtAnn.getCodeEvenement().equals(codEvt) && avtAnn.getDateDebEvenement().equals(dateDebut));
		}
		return false;
	}

	@Override
	public ImportEvtCloBean chercheEvenementCloture(String codeBanque, String idLocalTiers, String codEvt,
			String idLocalEvenement, LocalDate dateDebut) {
		if (listEvtsClotures == null) {
			listEvtsClotures = importRepo.loadEvenementsTiersClotures(ndodFile.getCodeBqsList());
			logger.info("Chargement de la liste des évènements cloturés");
		}
		if (listEvtsClotures != null && !listEvtsClotures.isEmpty()) {
			Optional<ImportEvtCloBean> eventClo = listEvtsClotures.parallelStream()
					.filter(evtClo -> evtClo.getIdEvenementLocal().equals(idLocalEvenement)
							&& evtClo.getCodeEvenement().equals(codEvt)
							&& evtClo.getDateDebEvenement().equals(dateDebut)
							&& evtClo.getCodeBanque().equals(codeBanque)
							&& evtClo.getIdTiersLocal().equals(idLocalTiers))
					.findFirst();

			return eventClo.orElse(null);
		}
		return null;
	}

	public void setReferenceImportSrvcImpl(ReferenceImportSrvcImpl referenceImportSrvcImpl) {
		this.referenceImportSrvcImpl = referenceImportSrvcImpl;
	}

	public void setImportRepo(ImportRepository importRepo) {
		this.importRepo = importRepo;
	}

	public void setListEvenementAnnule(Map<String, List<ImportEvenementAnnuleBean>> mapEvenementAnnule) {
		this.mapEvenementAnnule = mapEvenementAnnule;
	}

}
