package fr.bpce.yyd.batch.commun.utils;

import java.math.BigDecimal;

public class NumericUtil {

	private NumericUtil() {

	}

	public static BigDecimal convertToBigDecimal(Double value) {
		if (value == null) {
			return BigDecimal.valueOf(0.00d);
		}
		return BigDecimal.valueOf(value);
	}

	public static BigDecimal arrondir(BigDecimal value, int nbChiffresApresVirgule) {
		return value.setScale(nbChiffresApresVirgule, BigDecimal.ROUND_HALF_EVEN);
	}

	public static boolean isDigit(final CharSequence cs) {
		if (cs == null || cs.length() == 0) {
			return false;
		}
		final int sz = cs.length();
		for (int i = 0; i < sz; i++) {
			if (!Character.isDigit(cs.charAt(i))) {
				return false;
			}
		}
		return true;
	}
}
