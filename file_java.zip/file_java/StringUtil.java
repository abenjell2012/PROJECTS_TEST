package fr.bpce.yyd.batch.commun.utils;

public class StringUtil {

	private StringUtil() {
		// Utility class are not meant to be instantiated
	}

	public static boolean isEmpty(String chaine) {
		return chaine == null || chaine.trim().length() == 0;
	}

	public static boolean isSizeExceeded(String champ, int taille) {
		return !isEmpty(champ) && champ.length() > taille;
	}

}
