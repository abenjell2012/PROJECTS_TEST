package fr.bpce.yyd.batch.task;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.bpce.yyd.batch.beans.NdodFile;
import fr.bpce.yyd.batch.repositories.ImportRepository;
import fr.bpce.yyd.commun.enums.Controles;
import fr.bpce.yyd.commun.model.AuditFichiers;

@Service
public class AuditFichierTask implements Tasklet {

	@Autowired
	private ImportRepository importRepo;

	private NdodFile ndodFile;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
		String libelleAudit = Controles.FICOK.getMessage();

		AuditFichiers auditFichier = ndodFile.getAuditFichier();
		auditFichier.setNbLignesRejet(ndodFile.getNbLinesRejet());
		auditFichier.setCodAudit(Controles.FICOK);
		auditFichier.setLibCodAudit(libelleAudit);

		importRepo.update(auditFichier);
		return RepeatStatus.FINISHED;
	}

	public void setNdodFile(NdodFile ndodFile) {
		this.ndodFile = ndodFile;
	}
}
