/**
* Ce package contient les enumérations utilisées par le batch.
**/
package fr.bpce.yyd.batch.sbv.enums;

import java.text.MessageFormat;

public enum ForcageSbvControles {

	// controles techniques
	CT001("Impossible d''ouvrir le fichier [{0}]"), //
	CT002("Nom de fichier invalide. Format attendu [{0}]"), //
	CT003("Le format de la date dans le nom du fichier [{0}] est incorrect. Format attendu [{1}]"), //
	CT004("Le fichier [{0}] est vide"), //
	CT005("La ligne d''entête n''est pas correcte"), //
	CT006("Le format du fichier n''est pas respecté, nombre de colonnes attendues [10], "
			+ "la ligne {0} contient {1} colonne(s)"), //
	CT007("L''identifiant local ne doit pas dépasser {0} caractères"),
	CT008("Le format du code banque est incorrect. Format attendu [5 chiffres]"),
	CT009("L''identifiant RFT ne doit pas dépasser {0} caractères"),
	CT010("Le format de la date de début [{0}] est incorrect. Format attendu [AAAAMMJJ]"),
	CT011("Le format de la date de fin [{0}] est incorrect. Format attendu [AAAAMMJJ]"),
	CT012("La codification motif ne doit pas dépasser {0} caractères"),
	CT013("Le commentaire ne doit pas dépasser {0} caractères"),
	CT014("Impossible de parser la ligne [{0}] du fichier, vérifier l''utilisation des caractères spéciaux"),
	CT015("Le fichier [{0}] ne contient qu''une ligne d''entete"), //

	// controles fonctionelles
	CF001("L''identifiant RFT ou le couple (Identifiant local,Code banque) est obligatoire"),
	CF002("Le code banque [{0}] est inconnu dans le référentiel MDC"), //
	CF003("La date de début est obligatoire"),
	CF004("La date de fin doit être strictement supérieure à la date de début"),
	CF005("Le statut forcé est non valide, statuts attendues [{0}]"),
	CF006("Le palier de défaut est non valide, valeurs attendues [{0}] ou vide"),
	CF007("La date de début doit être inférieure ou égal à la date du jour"),
	// CF008("L''identifiant RFT et le couple (Identifiant local,Code banque) sont
	// renseignés, un seul identifiant est nécessaire"),
	CF009("Le couple (Identifiant local,Code banque) est obligatoire"),
	// CF010("Le palier de défaut est obligatoire pour le statut Défaut"),
	CF011("Tiers en doublon pour cette plage de dates");

	private final String message;

	private ForcageSbvControles(String message) {
		this.message = message;
	}

	public String getMessage(Object... parametres) {
		return MessageFormat.format(message, parametres);
	}

}
